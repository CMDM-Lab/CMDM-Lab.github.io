# CMDM Lab Design System — "Clinical Instrument"

The design system of the **Computational Molecular Design & Metabolomics Laboratory (CMDM Lab)** — Prof. Yufeng Jane Tseng's group in the Department of Computer Science & Information Engineering, National Taiwan University.

This is the **second-generation** system. The lab's live Bootstrap 3 website was fully replaced; the only thing carried over is the logo lockup and its blue, **#B4D6E0**. Everything else derives from the MetaboMAIA frontend's "Clinical Instrument" language, adopted here as the lab's house style.

## Sources

| Source | Contribution |
| --- | --- |
| `uploads/metabomaia-design-system.md` — the MetaboMAIA frontend design system (Tailwind v4, `globals.css` + ratchet tests) | Colour ramps, type stack and scale, 1.15× spacing, flat geometry, layout patterns, the prohibition list. This is the governing document. |
| https://github.com/CMDM-Lab/CMDM-Lab.github.io (branch `master`) | The logo lockups, the lab illustration, tool screenshots, figures, and all real content (people, papers, tools, addresses). |
| https://github.com/CMDM-Lab/lab_website | Not read — the lab's older site. |

Explore those repos (plus the lab's other work under https://github.com/CMDM-Lab) if you have access; reading the real source always beats inferring from this document. Note the *visual* language no longer comes from the website repo — only content and assets do.

## What the lab does

Two pillars, in the lab's own words:

- **Computational Molecular Design** — computer-aided drug design, A.I. for drug discovery.
- **Metabolomics** — biomarker detection, precision medicine.

Public tools live under `*.cmdm.tw`: Virtual Rat, CypRules, Lipidpedia, 3Omics, GC2MS, PITracer, Chromaligner, MetaCore.

---

## The system in one paragraph

Near-white page, hard 1px hairlines, **zero radius**, **zero shadow**, **one signal colour**. It should read like a research instrument or a journal page, not a side project. Separation comes from lines, never from card fills or elevation. Colour is information, not decoration. Every number, identifier, filename and duration is monospace with `tabular-nums` so columns align. Motion is limited to hover colour changes and one pulsing dot. **There is no dark mode** — that is a design decision, not a gap.

---

## VISUAL FOUNDATIONS

### Colour

Five tokens carry the system: `--bg #f7f7f5`, `--surface #eeeeec`, `--text #16181a`, `--accent #8c1d2f`, `--divider #d8dad6`. Everything else is a step on one of three ramps.

**The accent is whitelisted.** `#8c1d2f` may appear only as: primary button fill · active nav item · live pulse dot · positive-value emphasis · the numbers inside kickers and indices · must-fix tags. **Never a large fill or background wash.** The only tinted surface in the whole system is the notice banner at `--accent-100 #f6e8ea`; every other surface is `--bg`, `--surface`, `#fff` or `--neutral-100`.

**The brand blue is also whitelisted.** `#B4D6E0` is the one colour retained from the lab's old identity, sampled from the flask mark. It may appear as: the logo lockup itself · data-visualisation series fills · figure and spectrum plates · `brand`-tone tags for instrument and assay classifications. It is **not** a button fill, not body text, and not a page background — at this lightness it would only mute the page.

Opacity steps are mixed inline rather than tokenised: `color-mix(in srgb, var(--text) 78%, transparent)`. The steps in use are 78% (secondary prose), 54% (meta), 50% (faint), 35% (idle indices).

### Type

| Role | Font | Spec |
| --- | --- | --- |
| Headings / UI | IBM Plex Sans | 500 (600 for small labels), `letter-spacing: -0.02em` |
| Body | IBM Plex Sans | 13px / 1.55 |
| CJK | Noto Sans TC | 400 / 500 |
| Figures, kickers, identifiers, filenames, durations | IBM Plex Mono | 400 / 500 + `tabular-nums` |

Scale: hero `clamp(30px,3.4vw,40px)` · h1 30 · h2 24 · h3 19 · h4 16 · lede 14 · body 13 · small 12 · kicker 9.5–11px uppercase with 0.14–0.2em tracking.

**Body copy never goes below 12px.** The only licence to go smaller is a kicker, and only because it is uppercase monospace. Long prose is justified with `hyphens: auto` at `max-width: 64ch` — **except** technical prose in narrow columns, where CJK justification pulls tokens like `|log₂FC| > 1` apart.

### CJK setting

The lab is bilingual, so Chinese is a first-class case, not a fallback. Chinese text follows a different set of rules — every component that renders prose takes a `cjk` prop that switches to them:

| | Latin | 中文 |
| --- | --- | --- |
| Body size / leading | 13.5px / 1.55 | 14px / 1.8 |
| Measure | 64ch | 38em (~38 characters) |
| Alignment | justified + hyphenated | **ragged right, never justified** |
| Kicker | 9.5–11px mono, UPPERCASE, 0.14em | 12px sans, no case change, 0.08em |
| Heading leading | 1.1–1.3 | 1.3–1.5 |

Why: Chinese has no case, so `text-transform: uppercase` does nothing while 0.14em tracking pulls glyphs apart; justification stretches inter-character spacing and breaks technical tokens; and dense Hanzi needs more leading than 1.55 to stay readable. Numbers, identifiers and filenames stay in IBM Plex Mono in both locales.

Both locales share one flat message dictionary — keep the key sets symmetrical, and keep paper titles, journal names, tool names and degree codes in their original language even on the Chinese page. That is correct academic practice, not an omission.

### Spacing, geometry, elevation

Six spacing steps at 1.15× density: 4.6 / 9.2 / 13.8 / 18.4 / 27.6 / 36.8px. Steps 5 and 7 do not exist, deliberately. Never write a bare pixel value for spacing.

Every radius is `0`. The only circles are real circles — score dots and the pulse dot at `border-radius: 50%`.

**There is no elevation.** Layering is 1px lines: `1px solid #16181a` for nav underlines and section closers, `1px solid #d8dad6` for everything else, `1px solid #e6e7e4` between table rows, `2px solid #16181a` for the single ink-framed emphasis block per page.

Focus is always `outline: 2px solid #8c1d2f; outline-offset: 2px`. Never the browser default, never `outline: none` without a `:focus-visible` replacement.

### Motion

Hover and active colour changes, plus `ds-pulse` (1.4s opacity + scale) on the live dot. No slide-ins, no card lifts, no shadow transitions, no page transitions. The sticky nav's `backdrop-filter: blur(6px)` is the only blur in the system.

### Layout

Page container `max-width: 960px` (or 1180px wide), padding `space-8 / space-6`; prose columns capped at 64ch. **Almost no media queries** — reflow comes from `grid-template-columns: repeat(auto-fit, minmax(260px, 1fr))` and `flex: 1 1 380px` floors. Target widths: desktop 1440, tablet 1024 / 768.

### Mobile

One breakpoint, 768px, and it is a **token override** rather than a set of component branches: a single `@media (max-width:767px)` block in `tokens/layout.css` re-points `--page-pad-*`, `--nav-pad-*`, `--column-gap` and sets `--grid-min-*` to 100%, so every auto-fit grid and container collapses to one column on its own. The type ramp is not scaled per breakpoint.

Two components change shape below it: **SiteNav** swaps itself for **MobileNav** (compact bar + hamburger + full-height hairline drawer, 52px rows, `right` slot pinned to the drawer bottom), and **DataTable** stacks each row into a mono-label/value record instead of scrolling sideways. Tap targets floor at 44px (`--tap-min`). No bottom tab bar, no scrim, no sheets, no elevation. See `guidelines/mobile.html`.

### Prohibitions

| Never | Because |
| --- | --- |
| Dark mode, `prefers-color-scheme: dark` | The system is light-only by design |
| Any radius except a true circle | Flat geometry |
| Any shadow | Elevation is a 1px line |
| Generic Tailwind-style palettes (`slate-`, `blue-`, `red-`…) | Colour comes only from the three ramps |
| Bare hex in component code | Colour comes only from tokens |
| Unlayered CSS rules in the global sheet | Cascade layers make unlayered rules beat every component style — a bare `a { color }` once made a primary button's text match its own fill |
| Large accent fills, accent page washes | The signal colour is information |
| Emoji, filled icon glyphs | Not part of the language |

---

## CONTENT FUNDAMENTALS

The lab's voice is unchanged from its website, and it suits the new visual language well.

**Institutional academic, first-person plural.** The lab writes as "we"/"our" and never addresses the reader as "you". No marketing register, no imperative CTA copy.

> "We develop algorithms and tools to identify and design molecular structures for targeted use."

**Third person for people, always with title.** "Professor Y. Jane Tseng was invited to give a talk at…" — never "Jane", never a bare pronoun as sentence subject.

**News is dated then declarative:** `2018, ` + one full sentence + bracketed sources — `[TechNews]`, `[NTU Spotlight]`, `[CNN health news]`. Square brackets, title-cased outlet, at the end of the sentence.

**Links end in an arrow, not a verb phrase.** In the new language every "read on" affordance is a text link ending in `→` (`Publisher →`, `Open →`, `Research →`). The old `Link >>` pill is retired. Nothing says "Click here" or "Get started".

**Casing.** Sentence case for prose; Title Case for nav items and page titles; mono UPPERCASE for kickers, table heads and tags. Tool names keep their own capitalisation exactly: `Lipidpedia`, `3Omics`, `GC2MS`, `PITracer`, `CypRules`, `MetaCore`, `Virtual Rat`.

**Vocabulary is technical and unabbreviated.** LC/QTOF-MS, GCxGC/TOF-MS, ADMET, QSAR, hERG, 1D ¹H-NMR, CYP2D6. Acronyms expand on first use. Degrees use house shorthand: `PhD, BEBI`, `MS, CSIE`, `Ph.D., Pharmacy`.

**Bilingual.** Chinese-language items keep 「corner brackets」 for talk titles even inside English sentences; the language toggle reads `中文` / `English`. Both locales share one flat message dictionary — keep the key sets symmetrical.

**Emails are obfuscated:** `yjtseng[at]csie.ntu.edu.tw`.

**No emoji anywhere. No exclamation marks** in body copy (only inside quoted talk titles). **Blanks stay blank** — a member with no photo gets no placeholder; an alumnus with no thesis title gets an empty cell.

---

## ICONOGRAPHY

**No icon set came with either source, so Lucide is a flagged substitution.** It is the closest match to the system's geometry: 1.5px stroke, square caps, no fills, no rounded terminals.

- Load from CDN: `https://unpkg.com/lucide@0.454.0/dist/umd/lucide.js`.
- Sizes: 16px inside buttons, 18px standalone. Stroke `currentColor`, weight 1.5.
- **No emoji. No filled glyphs. No unicode dingbats.** The only glyph used iconographically is the literal `→` at the end of a link.
- The old site's **Font Awesome 4** files are still in `assets/font-awesome/` for legacy pages only. Do not use them in new work.
- **Confirm or replace this choice.** If the lab has an icon set, send it and I'll swap Lucide out.

## Brand assets

The wordmark is a lockup: a molecule-filled Erlenmeyer flask forming the `C` of "CMDM", an NMR trace under "Lab", the full lab name in a serif with a green ampersand. **It is black on transparent and only ever sits on white** — it does not read on the accent red.

- `assets/banner.png` — full lockup. `assets/logo.png` — compact, correct for the sticky nav.
- `assets/logo_big2.png`, `assets/logo_original.svg`, `assets/banner_v1–v4.svg` — variants.
- `assets/cmdm_illustration.png`, `assets/molecule.png`, `assets/favicon.ico`.
- Figures and tool screenshots: `research.png`, `research_2.png`, `virtual_rat.png`, `cyprules_1/2.png`, `pitracer.png`, `GC2MSlogo.png`, `LipidPedia.png`, `3omics.png`, `chromaligner.png`, `metacore.png`, `metacore1.png`, `professor.png`, `IMG_0935.JPG`, `2017_future_tech.jpg`.

Figures always sit on a **white plate inside a 1px hairline**, with a mono 11px caption. Nothing bleeds off the page; there is no hero imagery in this system.

---

## Index

| Path | What it is |
| --- | --- |
| `styles.css` | Entry point — `@import`s every token file. Link this one file. |
| `tokens/fonts.css` | IBM Plex Sans / Mono + Noto Sans TC loading, family strings. |
| `tokens/colors.css` | Semantic five, accent / neutral / brand ramps, aliases. |
| `tokens/typography.css` | Type scale, weights, tracking, prose measure. |
| `tokens/spacing.css` | The six-step 1.15× scale. |
| `tokens/borders.css` | Radii (all zero), the 1px rule set, focus ring. |
| `tokens/layout.css` | Container widths, auto-fit minimums, nav metrics. |
| `tokens/base.css` | `@layer ds-base` reset, element defaults, the pulse keyframe. |
| `guidelines/*.html` | 16 foundation specimen cards (Colors, Type, Spacing, Brand). |
| `assets/` | Logos, illustration, figures, tool screenshots, legacy Font Awesome. |
| `ui_kits/lab_site/` | Five-screen bilingual click-through of the lab site — see its README. |
| `templates/lab-page/` | Starting template for a new page in this language. |
| `SKILL.md` | Agent Skills front-matter so this folder works in Claude Code. |
| `HANDOFF.md` | Implementation handoff for a developer building this in a real codebase. |
| `github.md` | Upstream repo association and sync record. |

### Components

**`components/core/`** — **Button**, **Input**, **Tag**, **Kicker**, **Hairline**, **InkPanel**, **PageShell**, **Prose**, **PulseDot**

**`components/navigation/`** — **SiteNav**, **MobileNav**, **Masthead**, **Footer**

**`components/content/`** — **Ledger**, **LedgerItem**, **DataTable**, **ColophonTable**, **ArticleFlow**

Each has a sibling `.d.ts` props contract and a `.prompt.md` usage note.

### Layout patterns

- **Ledger** — the replacement for cards. Auto-fit grid, hairline top on the container, hairline bottom per item, no fills. Right for research directions, tools, people, papers.
- **Two-column article flow** — CSS `columns` + column rule. Reads like a journal; better than side-by-side flex for long prose.
- **Colophon table** — 34% mono label column, value column. Right for specs, stacks, equipment, provenance.
- **Ink panel** — 2px ink frame on white, one per page maximum. The loudest thing available.
- **Masthead** — kicker → ink rule → title → mono subtitle → justified lede. Opens every page.
- **Sticky nav** — blurred near-white, ink bottom rule, two-line brand block left, hairline-underlined links right.

### Deliberately not built

The source document warns against two components the original handoff listed but never shipped: **`.seg`** (an A/B layout switcher that stayed a prototype) and **`.card`** (superseded by hairlines). Neither exists here, and neither should be added.

### Intentional additions

- **PageShell / Prose** — wraps the container and 64ch prose measure the source document specifies in prose but never named.
- **Ledger / LedgerItem** — names the source's "Ledger" pattern as a component pair so the no-fill rule can't drift.
- **PulseDot** — the source describes the pulse as a utility plus a keyframe; here it is one component so the animation can't be copied by hand.

## Open questions for the lab

1. **Icon set** — Lucide is a substitution. Confirm or replace.
2. **Font delivery** — fonts load from Google Fonts. If the lab needs self-hosting or intranet delivery, swap the source but keep the family names.
3. **Accent colour** — `#8c1d2f` comes from MetaboMAIA. If the lab wants a different signal colour, it changes in one token and the whole system follows.
4. **Should `#B4D6E0` do more?** Right now it is deliberately narrow. It could also become the data-viz primary or the chart-grid colour if you want the lab identity more present.
