# MetaboMAIA Design System — 「Clinical Instrument」

> 給 Claude 的設計參考。內容擷取自 `MetaboMAIA/frontend` 的實作現況（`src/app/globals.css`
> 513 行、`src/components/*`、兩支 ratchet 測試），以及設計來源
> `docs/design_handoff_metabomaia_frontend/`（HTML 原型 + `classical-styles.css`）與
> `docs/superpowers/plans/2026-08-05-frontend-clinical-redesign.md` 的 Global Constraints。
>
> 用途：以此視覺語言重構 CMDM 實驗室網站。以下「現況」段落是已上線且有測試守住的事實；
> 「建議升級」段落標明是新專案才要做的改動，不要混淆。

---

## 1. 設計定位

近白底、硬 hairline、**零圓角**、**零陰影**、**單一訊號色**。讀起來要像研究儀器或期刊排版，
不像 side project。具體判準：

- 分隔靠 1px 線，不靠卡片填色或陰影。
- 顏色是資訊，不是裝飾——暗紅只在六個指定位置出現。
- 數字、識別碼、檔名、時長一律等寬字體 + `tabular-nums`，讓欄位對齊。
- 動效只有 hover/active 換色 + 一個 pulse dot。沒有 slide-in、沒有卡片浮起、沒有陰影過場。
- **沒有 dark mode。** 不是還沒做，是設計上排除。

---

## 2. 色彩 token

### 語意層

| token | hex | 用途 |
|---|---|---|
| `--bg` | `#f7f7f5` | 頁面底 |
| `--surface` | `#eeeeec` | 次要按鈕填色、嵌入面板 |
| `--text` | `#16181a` | 正文墨色、硬線 |
| `--accent` | `#8c1d2f` | 訊號色（見下方白名單） |
| `--divider` | `#d8dad6` | hairline、input 邊框 |

### Accent ramp（暗紅）

`100 #f6e8ea` · `200 #eccfd3` · `300 #dba7ae` · `400 #c47c86` · `500 #a8404f` ·
`600 #8c1d2f` · `700 #7a1926` · `800 #5e1420` · `900 #3f0d16`

### Neutral ramp（暖灰）

`100 #f2f2f0` · `200 #e6e7e4` · `300 #d8dad6` · `400 #b9bdb8` · `500 #8b9199` ·
`600 #6b7280` · `700 #3f4a56` · `800 #2a3038` · `900 #16181a`

### 訊號色白名單（重要）

`#8c1d2f` **只准**用於：primary button 填色、active nav item、live pulse dot、
正值數據強調、kicker 與序號裡的數字、must-fix 類 tag。

**永不作大面積填色或背景 wash。** 全站唯一的著色表面是通知橫幅 `#f6e8ea`（`accent-100`）。
其餘表面只有 `--bg` / `--surface` / `#fff` / `neutral-100`。

### 透明度慣例

不另開 token，直接混色：`color-mix(in srgb, var(--color-text) 78%, transparent)`。
實際用過的階：正文次級 78%、meta 54%、faint 50%、序號未啟用 35%。

---

## 3. 字體

| 角色 | 字體 | 規格 |
|---|---|---|
| 標題 / UI | IBM Plex Sans | 500（小標 600），`letter-spacing: -0.02em` |
| 正文 | IBM Plex Sans | 13px / 1.55 |
| CJK fallback | Noto Sans TC | 400 / 500 |
| 數字、kicker、識別碼、檔名、時長 | IBM Plex Mono | 400 / 500 + `tabular-nums` |

Family string：`'IBM Plex Sans','Noto Sans TC',sans-serif` / `'IBM Plex Mono','Noto Sans TC',monospace`

### 字級

`h1 30px`（hero 可 `clamp(30px,3.4vw,40px)`）· `h2 24px`（次級 hero 28px）· `h3 19px` ·
`h4 16px` · 正文 `13px` · small `12px` · kicker `9.5–11px` uppercase `letter-spacing .14–.2em`

**正文絕不低於 12px。** kicker 可到 9.5px，唯一理由是它是大寫等寬標籤。

### 正文排版

長段落用 `text-align: justify` + `hyphens: auto` + `max-width: 64ch`。
**例外**：窄欄的技術正文不要 justify——CJK justify 在窄欄會把 `|log₂FC| > 1`
這類 token 拆開。

---

## 4. 間距 / 圓角 / elevation / focus

**間距**（1.15× 密度，只用這六階，不寫裸數字）：

`--space-1: 4.6px` · `--space-2: 9.2px` · `--space-3: 13.8px` ·
`--space-4: 18.4px` · `--space-6: 27.6px` · `--space-8: 36.8px`

（現況刻意沒有 5 與 7。）

**圓角**：`--radius-sm/md/lg` 全部 `0`。唯一允許的圓形是真正的圓——評分點、pulse dot（`border-radius: 50%` / `rounded-full`）。

**Elevation**：沒有陰影。層次一律 1px 線——
`1px solid #16181a` 給 nav 底線與 section closer；`1px solid #d8dad6` 給其他；
表格列間 `1px solid #e6e7e4`。

**Focus**：全站一律 `outline: 2px solid #8c1d2f; outline-offset: 2px`。
不准用瀏覽器預設，不准 `outline: none` 而不給 `:focus-visible` 替代。

---

## 5. 可直接複製的 CSS 骨架

Tailwind v4，CSS-first，**沒有 `tailwind.config`**。整個 token 層就是這一個檔案。

結構鐵律：**除 `:root` 與 `@theme` 外，每條規則都必須寫在 `@layer` 裡。**
CSS cascade layer 讓任何未分層宣告永遠贏過已分層的，與 selector 特異性無關——
曾有一條裸 `a { color }` 蓋掉 `.btn-primary`，讓 CTA 按鈕文字與底色同色而消失。

```css
@import "tailwindcss";

:root {
  /* 鎖住原生表單 chrome，避免 OS dark mode 讓 checkbox/select 變深色 */
  color-scheme: light;

  --bg: #f7f7f5;
  --surface: #eeeeec;
  --text: #16181a;
  --accent: #8c1d2f;
  --divider: #d8dad6;

  --accent-100: #f6e8ea; --accent-200: #eccfd3; --accent-300: #dba7ae;
  --accent-400: #c47c86; --accent-500: #a8404f; --accent-600: #8c1d2f;
  --accent-700: #7a1926; --accent-800: #5e1420; --accent-900: #3f0d16;

  --neutral-100: #f2f2f0; --neutral-200: #e6e7e4; --neutral-300: #d8dad6;
  --neutral-400: #b9bdb8; --neutral-500: #8b9199; --neutral-600: #6b7280;
  --neutral-700: #3f4a56; --neutral-800: #2a3038; --neutral-900: #16181a;

  --space-1: 4.6px; --space-2: 9.2px; --space-3: 13.8px;
  --space-4: 18.4px; --space-6: 27.6px; --space-8: 36.8px;

  /* flat design: every radius is 0. Kept as documented tokens. */
  --radius-sm: 0; --radius-md: 0; --radius-lg: 0;
}

/* @theme turns each token into a Tailwind utility: bg-bg, text-accent-600,
   border-divider, ... */
@theme inline {
  --color-bg: var(--bg);
  --color-surface: var(--surface);
  --color-text: var(--text);
  --color-accent: var(--accent);
  --color-divider: var(--divider);

  --color-accent-100: var(--accent-100); /* ...200 through 900 likewise */
  --color-neutral-100: var(--neutral-100); /* ...200 through 900 likewise */

  /* next/font attaches these variables via className on <body> */
  --font-sans: var(--font-plex-sans), var(--font-noto-tc), sans-serif;
  --font-mono: var(--font-plex-mono), var(--font-noto-tc), monospace;
}

@layer base {
  * { box-sizing: border-box; }

  body {
    background: var(--color-bg);
    color: var(--color-text);
    font-family: var(--font-sans);
    font-size: 13px;
    line-height: 1.55;
    -webkit-font-smoothing: antialiased;
  }

  h1, h2, h3, h4 { font-weight: 500; letter-spacing: -0.02em; }
  h1 { font-size: 30px; }
  h2 { font-size: 24px; }
  h3 { font-size: 19px; }
  h4 { font-size: 16px; }

  /* Must live in a layer, or it beats .btn-primary's colour. */
  a { color: #8c1d2f; }
  a:hover { color: #5e1420; }

  figcaption {
    font-family: var(--font-mono);
    font-size: 11px;
    color: var(--color-neutral-600);
  }

  button, input, select, textarea { font-family: inherit; }

  :focus { outline: none; }
  :focus-visible { outline: 2px solid #8c1d2f; outline-offset: 2px; }
  ::selection { background: color-mix(in srgb, var(--color-accent) 30%, transparent); }
}

@layer components {
  .btn {
    display: inline-flex; align-items: center; justify-content: center;
    gap: 6px; cursor: pointer;
    text-decoration: none;      /* .btn is also applied to <a>/<Link> */
    line-height: 1.2;
    color: var(--color-text);
    background: transparent;
    border: 1px solid transparent;  /* width+style so variants only set colour */
    border-radius: 0;
    white-space: nowrap;
    font-weight: 500;
    font-size: 12px;
    padding: var(--space-2) calc(var(--space-3) * 1.2);
  }
  .btn svg { display: block; }
  .btn:disabled { opacity: 0.45; cursor: not-allowed; }

  .btn-primary { background: #8c1d2f; color: #fff; border-color: #8c1d2f; }
  .btn-primary:hover { background: #7a1926; color: #fff; }
  .btn-primary:active { background: #5e1420; color: #fff; }

  .btn-secondary { background: #eeeeec; border: 1px solid #d8dad6; }
  .btn-secondary:hover { background: color-mix(in srgb, var(--color-text) 7%, transparent); }
  .btn-secondary:active { background: color-mix(in srgb, var(--color-text) 14%, transparent); }

  .btn-ghost {
    background: transparent; border: none;
    color: var(--color-accent); padding-inline: var(--space-1);
  }
  .btn-ghost:hover { background: color-mix(in srgb, var(--color-accent) 10%, transparent); }
  .btn-ghost:active { background: color-mix(in srgb, var(--color-accent) 18%, transparent); }

  .btn-block { width: 100%; margin-top: var(--space-2); }

  .input {
    font: inherit;              /* inherit the page's 1.55 line-height */
    width: 100%;
    border-radius: 0;
    min-height: 36px;
    border: 1px solid var(--color-divider);
    background: #fff;
    padding: 0 var(--space-2);
    font-size: 13px;            /* matches body copy, never larger than its label */
    caret-color: var(--color-accent);
  }
  .input:hover { border-color: color-mix(in srgb, var(--color-text) 45%, transparent); }
  .input:focus-visible { border-color: var(--color-accent); }
  textarea.input { min-height: 90px; resize: vertical; }

  .table { width: 100%; border-collapse: collapse; font-size: 14px; }
  .table th {
    font-family: var(--font-mono);
    font-size: 9.5px;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    text-align: left;
    padding: var(--space-2);
    border-bottom: 1px solid var(--color-text);   /* ink rule = section boundary */
  }
  .table td {
    font-size: 12.5px;
    padding: var(--space-2);
    border-bottom: 1px solid #e6e7e4;             /* row hairline, one step lighter */
  }
  .table tbody tr:hover { background: var(--color-neutral-100); }

  .tag {
    display: inline-block; border-radius: 0;
    font-family: var(--font-mono);
    font-size: 9.5px; letter-spacing: 0.1em; text-transform: uppercase;
    padding: 2px 6px;
  }
  .tag-accent  { background: var(--color-accent-100); color: var(--color-accent-800); }
  .tag-neutral { background: #e6e7e4; color: #3f4a56; }
  .tag-outline { background: transparent; border: 1px solid var(--color-accent); color: var(--color-accent); }

  .hr { height: 1px; border: 0; margin: var(--space-4) 0; background: var(--color-divider); }
  .hr-ink { background: #16181a; opacity: 0.85; }

  .field { display: flex; flex-direction: column; gap: var(--space-2); }
  .field label { font-size: 12px; color: var(--color-neutral-700); }

  /* Live pulse dot. Size/colour are utilities on the element
     (h-[7px] w-[7px] rounded-full bg-accent-600); only the motion is here. */
  .trace-pulse { animation: mmPulse 1.4s ease-in-out infinite; }
  @keyframes mmPulse {
    0%, 100% { opacity: 0.25; transform: scale(0.8); }
    50%      { opacity: 1;    transform: scale(1.25); }
  }
}
```

---

## 6. 撰寫慣例

```tsx
// 顏色走 @theme 生成的 utility，不寫 hex
className="border-divider text-neutral-500 bg-accent-100 text-text"

// 間距用 arbitrary value 包 CSS 變數（現況全 src 190 處都是這個寫法）
className="mt-[var(--space-4)] gap-[var(--space-2)] px-[var(--space-6)]"

// 字級用 arbitrary px
className="font-mono text-[13.5px] tabular-nums"

// 透明度用 color-mix，不開新 token
className="text-[color-mix(in_srgb,var(--color-text)_78%,transparent)]"
```

**inline style 只在一種情況使用**：該宣告是 layout-critical 且測試要用
jsdom `toHaveStyle` 直接讀（例：`flex: 1 1 380px`、`columns: 2`）。其餘一律 Tailwind class。

**兩個唯一定義外觀的元件**——不要在各處內聯複製它們的樣式：

```tsx
// Kicker：mono uppercase 標籤。size sm=9.5px / md=11px；tone accent / faint
<span className="font-mono uppercase tracking-[0.14em] text-[9.5px] text-accent-700">

// Hairline：全站 elevation 的唯一出口
<hr className="hr" />      // divider hairline
<hr className="hr hr-ink" />  // 墨線，section closer
```

---

## 7. 版面與 responsive

頁面容器：`mx-auto w-full max-w-[960px] px-[var(--space-6)] py-[var(--space-8)]`
（實測用過 960 / 1040 / 1080 / 1180px；正文欄另限 `max-w-[64ch]`）。

**幾乎不用 media query。** 現況全 src 只有 1 處 breakpoint 前綴，`globals.css` 零 `@media`。
改用兩個機制自然回流：

```tsx
// 1. auto-fit grid：欄數由容器寬度決定
className="grid grid-cols-[repeat(auto-fit,minmax(260px,1fr))]"

// 2. flex-wrap + flex-basis 下限：擠不下就換行
style={{ flex: "1 1 380px", minWidth: "min(100%, 380px)" }}
```

目標寬度 desktop 1440、iPad 1024 / 768。

---

## 8. 禁止清單（現況由測試強制）

`src/__tests__/design-tokens.test.ts` 掃全部 `.ts` / `.tsx` / `.css` 原始碼文字，以下任一出現即紅燈：

| 禁止 | 理由 |
|---|---|
| `dark:` 變體 | 沒有 dark mode |
| `prefers-color-scheme: dark` | 同上，CSS 側的同一條規則 |
| `rounded-*`（`rounded-full` 除外） | 圓角全 0，圓形只給真正的圓 |
| `shadow-*`（`shadow-none` 除外） | elevation 是 1px 線 |
| Tailwind 預設色盤（`slate-` `blue-` `red-` `amber-` `emerald-`…） | 顏色只能來自兩條 ramp |
| `.tsx` 內的裸 hex | 顏色只能來自 token；`globals.css` 例外 |
| `globals.css` 裡任何 `@layer` 外的規則 | cascade layer 會讓它永遠贏過元件 class |

搭配 `comment-language.test.ts`：註解不得含 CJK（該 repo 的約定，新專案可自行決定）。

兩支測試都用「**只能縮小的 allowlist**」棘輪：第二條測試會在「檔案已修好卻還留在
allowlist」時紅燈，所以清單無法悄悄變長。

### 現況沒被測試守住的規則（新專案應該補上）

以下四條目前只存在文件裡，實測已經在漂——`src/` 內有 17 處在 `Kicker` 之外
直接寫 <12px 字級，其中數處不是 mono uppercase：

1. 訊號色六處白名單
2. 正文不低於 12px
3. 間距只用 `--space-*`
4. focus ring 一律 2px

---

## 9. 可複用的版面型樣

**Ledger（無填色清單）** — 適合研究方向、成員、論文列表。
`grid-cols-[repeat(auto-fit,minmax(260px,1fr))]`，容器 `border-t border-divider`，
每項 `border-b border-divider`，**沒有卡片填色**。內部結構：
mono accent 羅馬數字 + `h4` 標題 + justified 13.5px 正文 + mono meta 行 + 文字連結（`→` 結尾）。

**雙欄文章流** — 適合 About / 實驗室簡介。
`columns: 2` + `column-gap: 36.8px` + `column-rule: 1px solid var(--color-divider)`，
`text-justify hyphens-auto text-[14px]`。比並排 flex 欄更像期刊排版。

**Colophon 表** — 適合技術棧、設備、資源清單。`.table` 的 `<th>` label / `<td>` value 兩欄，
`th` 佔 `w-[34%] align-top`，整表 `font-variant-numeric: tabular-nums`。

**墨框強調區塊** — 頁面上最響的元素。`border: 2px solid #16181a`、`background: #fff`、
`padding: 27.6px`。內部第一行是 mono 11px uppercase accent 標籤。全頁最多用一次。

**Masthead** — mono uppercase kicker（accent-700）→ 墨線 `.hr-ink` →
`clamp(30px,3.4vw,40px)` 字標 → mono 11px uppercase 副標 → justified 引言。

**Sticky nav** — `sticky top-0`、`background: color-mix(in srgb, #f7f7f5 92%, transparent)`、
`backdrop-filter: blur(6px)`、`border-bottom: 1px solid #16181a`、padding `13.8px 27.6px`。
左側雙行 brand block（20px/500 字標 + mono 9.5px uppercase `letter-spacing .18em` 標語，
`neutral-600`）。中間導覽 13.5px，`border-bottom: 1px solid transparent`，
hover 顯示 accent 線，active 為 accent 色 + `aria-current="page"`。

---

## 10. 建議升級（新專案才做，現況沒有）

1. **字級收進 `@theme`。** 現況 15 種 `text-[Npx]` 散在各檔（13 / 12 / 11 / 13.5 / 9.5 /
   12.5 / 15 / 28 / 20 / 14 / 11.5 / 34 / 19 / 17 / 14.5px）。收成
   `--text-kicker/-small/-body/-lede/-h4…-h1` 後，「正文不低於 12px」才有可能寫成測試。
2. **補 `--space-5` / `--space-7`**（23 / 32.2px），或明確記錄為刻意跳號。
3. **`.seg` 與 `.card` 不要建。** handoff 列了但從未實作——`.seg` 是原型的 A/B 版面切換器，
   刻意不上線；`.card` 被 hairline 取代。照抄 handoff 會做出兩個空殼。
4. **字體載入方式要決定。** 現況走 `next/font/google`；若實驗室網站要 self-host 或走內網，
   得換成本地字檔並保持 `--font-plex-sans` / `--font-plex-mono` / `--font-noto-tc` 這三個
   變數名，`@theme` 才不用改。
5. **i18n**：現況是自製輕量方案——`LocaleContext` 提供 `useT()`、`{name}` 插值、
   localStorage 持久化、effect 內同步 `documentElement.lang`；字典是 flat key 的
   `messages/{zh,en}.ts`，並有一支測試在兩邊 key 不對稱時讓 build 紅燈。
   若實驗室網站需要 SEO friendly 的多語言路由，這裡要改成 next-intl 或 App Router 的
   `[locale]` 分段，token 層不受影響。
