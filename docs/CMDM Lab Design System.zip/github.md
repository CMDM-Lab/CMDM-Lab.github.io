repo: CMDM-Lab/CMDM-Lab.github.io
branch: master

## Last sync

date: 2026-08-22T01:30:00Z

### Updated in this project

- Design system rebuilt on the MetaboMAIA "Clinical Instrument" language; the old Bootstrap 3 / crimson system was removed.
- Only the logo lockup and its blue **#B4D6E0** were carried over from the website repo.
- The website repo is now a source of **content and assets only** — not of visual language.
- 17 components, 15 foundation cards, a five-screen UI kit and one page template rebuilt from scratch.

## Screen map

| Screen | Built from |
| --- | --- |
| `ui_kits/lab_site/OverviewScreen.jsx` | `contents/index.html`, `contents/about.html` (content only) |
| `ui_kits/lab_site/ResearchScreen.jsx` | `contents/research.html` (content only) |
| `ui_kits/lab_site/ToolsScreen.jsx` | `contents/service.html` (content only) |
| `ui_kits/lab_site/PeopleScreen.jsx` | `contents/member.html` (content only) |
| `ui_kits/lab_site/PublicationsScreen.jsx` | `contents/index.html`, `contents/honor.html` (content only) |
| `tokens/*.css` | `uploads/metabomaia-design-system.md` — NOT the website repo |
| `assets/*` | `img/*`, `favicon.ico`, `font-awesome/*` (legacy) |

## Sync history

### 2026-08-22T00:52:13Z

First import. Built a design system directly from the website's Bootstrap 3 CSS (crimson `#DC143C` nav, blue `#0073e6` rules, 3px grey lattice). Superseded the same day by the Clinical Instrument rebuild — a future sync should pull content and asset changes only, never re-derive styling from `css/main.css`.
