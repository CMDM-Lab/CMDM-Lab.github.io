function OverviewScreen({ t, cjk, locale }) {
  const { PageShell, Masthead, Ledger, LedgerItem, Hairline, InkPanel, Kicker, ColophonTable, Prose } = window.CMDMLabDesignSystem_c5432b;
  const m = t.overview;
  return (
    <PageShell width="wide">
      <Masthead hero cjk={cjk} kicker={m.kicker} title={m.title} subtitle={m.subtitle} lede={m.lede} />

      <Hairline style={{ marginTop: 'var(--space-8)' }} />
      <Kicker size="md" cjk={cjk}>{m.pillarsLabel}</Kicker>
      <Ledger style={{ marginTop: 'var(--space-3)' }}>
        {m.pillars.map((p) => (
          <LedgerItem key={p.index} cjk={cjk} index={p.index} title={p.title} body={p.body} meta={p.meta} href="#" linkLabel={p.link} />
        ))}
      </Ledger>

      <Hairline style={{ marginTop: 'var(--space-8)' }} />
      <Kicker size="md" cjk={cjk}>{m.recordLabel}</Kicker>
      <div style={{ display: 'flex', gap: 'var(--space-8)', flexWrap: 'wrap', marginTop: 'var(--space-4)' }}>
        <div style={{ flex: '1 1 380px', minWidth: 'min(100%, 380px)' }}>
          <Prose cjk={cjk} size="lede">
            {m.record.map((para, i) => <p key={i} style={{ margin: 0 }}>{para}</p>)}
          </Prose>
        </div>
        <div style={{ flex: '1 1 320px', minWidth: 'min(100%, 320px)' }}>
          <ColophonTable entries={m.facts} />
        </div>
      </div>

      <div style={{ marginTop: 'var(--space-8)' }}>
        <InkPanel kicker={m.recruitKicker}>
          <p style={{
            margin: 0,
            fontSize: 'var(--text-lede)',
            lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
            maxWidth: cjk ? 'var(--measure-prose-cjk)' : 'var(--measure-prose)',
          }}>
            {m.recruitBody}<a href="mailto:yjtseng@csie.ntu.edu.tw">yjtseng[at]csie.ntu.edu.tw</a>{m.recruitTail}
          </p>
        </InkPanel>
      </div>
    </PageShell>
  );
}

Object.assign(window, { OverviewScreen });
