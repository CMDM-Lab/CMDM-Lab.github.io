function ToolsScreen({ t, cjk, locale }) {
  const { PageShell, Masthead, Ledger, LedgerItem, Tag, Hairline, Kicker, ColophonTable } = window.CMDMLabDesignSystem_c5432b;
  const m = t.tools;
  const L = window.L;
  return (
    <PageShell width="wide">
      <Masthead cjk={cjk} kicker={m.kicker} title={m.title} subtitle={m.subtitle} lede={m.lede} />
      <Hairline style={{ marginTop: 'var(--space-6)' }} />
      <Kicker size="md" cjk={cjk}>{m.listLabel}</Kicker>
      <Ledger style={{ marginTop: 'var(--space-3)' }}>
        {window.DATA.tools.map((tool) => (
          <LedgerItem key={tool.name} cjk={cjk} title={tool.name} body={L(tool.desc, locale)} imageSrc={tool.img}
            meta={`${tool.url.replace(/^https?:\/\//, '').replace(/\/$/, '')} · ${L(tool.kind, locale)}`}
            href={tool.url} linkLabel={m.link}
            tags={[<Tag key="t" tone="brand">{L(tool.tag, locale)}</Tag>]} />
        ))}
      </Ledger>
      <Hairline tone="ink" style={{ marginTop: 'var(--space-8)' }} />
      <Kicker size="md" cjk={cjk}>{m.accessLabel}</Kicker>
      <div style={{ marginTop: 'var(--space-3)', maxWidth: 640 }}>
        <ColophonTable entries={m.access} />
      </div>
    </PageShell>
  );
}

Object.assign(window, { ToolsScreen });
