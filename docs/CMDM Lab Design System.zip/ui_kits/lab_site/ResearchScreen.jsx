function ResearchScreen({ t, cjk, locale }) {
  const { PageShell, Masthead, Ledger, LedgerItem, Tag, Hairline, Kicker } = window.CMDMLabDesignSystem_c5432b;
  const m = t.research;
  const L = window.L;
  return (
    <PageShell width="wide">
      <Masthead cjk={cjk} kicker={m.kicker} title={m.title} subtitle={m.subtitle} lede={m.lede} />
      <Hairline style={{ marginTop: 'var(--space-6)' }} />
      <Kicker size="md" cjk={cjk}>{m.listLabel}</Kicker>
      <Ledger min="var(--grid-min-wide)" style={{ marginTop: 'var(--space-3)' }}>
        {window.DATA.papers.map((p) => (
          <LedgerItem key={p.index} cjk={cjk} index={p.index} title={p.title}
            body={L(p.body, locale)} meta={p.meta} imageSrc={p.img}
            href="#" linkLabel={m.link}
            tags={[<Tag key="t" tone="brand">{L(p.tag, locale)}</Tag>]} />
        ))}
      </Ledger>
    </PageShell>
  );
}

Object.assign(window, { ResearchScreen });
