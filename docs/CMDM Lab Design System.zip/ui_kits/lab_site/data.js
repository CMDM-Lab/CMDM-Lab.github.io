// Content data. Paper and tool NAMES stay in their original language — that is
// correct academic practice — only descriptions, topics and person names localise.
window.DATA = {
  papers: [
    { index: 'I', title: 'Mutagenicity in a Molecule: Identification of Core Structural Features of Mutagenicity Using a Scaffold Analysis', meta: 'PLOS ONE · 2016 · doi:10.1371/journal.pone.0148900', img: '../../assets/research.png',
      body: { en: 'With advances in the development and application of Ames mutagenicity in silico prediction tools, the International Conference on Harmonisation has amended its M7 guideline to reflect the use of such prediction models in early drug safety evaluation.', zh: '隨著 Ames 致突變性電腦模擬預測工具的發展與應用日趨成熟，國際醫藥法規協和會已修訂 M7 指引，納入此類預測模型於早期藥物安全性評估的使用規範。' },
      tag: { en: 'Toxicology', zh: '毒理學' } },
    { index: 'II', title: 'Using the Matrix-Induced Ion Suppression Method for Concentration Normalization in Cellular Metabolomics Studies', meta: 'Analytical Chemistry · 2015', img: '../../assets/research_2.png',
      body: { en: 'Most cellular metabolomics studies control only cell numbers or protein content without adjusting total metabolite concentration, mainly because no effective normalization method existed.', zh: '多數細胞代謝體學研究僅控制細胞數或蛋白質含量，而未校正總代謝物濃度，主因是先前缺乏有效的濃度正規化方法。' },
      tag: { en: 'Metabolomics', zh: '代謝體學' } },
    { index: 'III', title: 'An efficient and robust fatty acid profiling method for plasma metabolomic studies by GC-MS', meta: 'Clinica Chimica Acta · 2016',
      body: { en: 'Targeted metabolomic analysis of fatty acids has linked their dysregulation to many diseases. Five frequently used derivatization methods were compared for robustness and coverage.', zh: '脂肪酸的標的代謝體學分析已將其失調與多種疾病連結。本研究比較五種常用衍生化方法的穩定性與偵測涵蓋率。' },
      tag: { en: 'GC-MS', zh: '氣相質譜' } },
    { index: 'IV', title: 'A portable micro gas chromatography system for volatile compounds detection with 15 ppb sensitivity', meta: 'IEEE MEMS · 2015',
      body: { en: 'Volatile organic compounds in human breath can provide biomarkers for disease. Existing non-invasive equipment struggles with early-stage lung cancer, where abnormal tissue is under 0.5 cm.', zh: '人體呼氣中的揮發性有機化合物可作為疾病生物標記。現有非侵入式儀器難以偵測早期肺癌，因其異常組織小於 0.5 公分。' },
      tag: { en: 'Instrumentation', zh: '儀器開發' } },
    { index: 'V', title: 'Synthesis and inhibitory effects of novel pyrimido-pyrrolo-quinoxalinedione analogues targeting influenza A H1N1 nucleoproteins', meta: 'Eur. J. Med. Chem. · 2015',
      body: { en: 'The influenza nucleoprotein is a single-strand RNA-binding protein at the core of the ribonucleoprotein particle, serving several functions critical to viral replication.', zh: '流感核蛋白為單股 RNA 結合蛋白，位於核糖核蛋白顆粒的核心，承擔多項對病毒複製至關重要的功能。' },
      tag: { en: 'Drug design', zh: '藥物設計' } },
  ],

  tools: [
    { name: 'Virtual Rat', url: 'https://virtualrat.cmdm.tw/', img: '../../assets/virtual_rat.png', tag: 'ADMET',
      kind: { en: 'Web service', zh: '網頁服務' },
      desc: { en: 'Predictions of important ADMET properties, together with the structural reasoning behind each call.', zh: '預測重要的 ADMET 性質，並同時提供模型判斷所依據的結構理由。' } },
    { name: 'CypRules', url: 'http://cyprules.cmdm.tw/', img: '../../assets/cyprules_2.png', tag: 'CYP450',
      kind: { en: 'Web service', zh: '網頁服務' },
      desc: { en: 'Predicts metabolizing Cytochrome P450 inhibition for CYP1A2, CYP2C19, CYP2C9, CYP2D6 and CYP3A4.', zh: '預測細胞色素 P450 代謝酵素的抑制情形，涵蓋 CYP1A2、CYP2C19、CYP2C9、CYP2D6 與 CYP3A4。' } },
    { name: 'Lipidpedia', url: 'http://lipidpedia.cmdm.tw', img: '../../assets/LipidPedia.png', tag: { en: 'Lipidomics', zh: '脂質體學' },
      kind: { en: 'Knowledgebase', zh: '知識庫' },
      desc: { en: 'An encyclopedia of lipids providing associated biomedical information mined from the literature.', zh: '脂質百科全書，透過文獻探勘提供與各脂質相關的生醫資訊。' } },
    { name: '3Omics', url: 'http://3omics.cmdm.tw', img: '../../assets/3omics.png', tag: { en: 'Multi-omics', zh: '多體學整合' },
      kind: { en: 'Web service', zh: '網頁服務' },
      desc: { en: 'One-click visualisation and integration of inter- and intra-transcriptomic, proteomic and metabolomic human data.', zh: '一鍵完成人類轉錄體、蛋白體與代謝體資料的跨體學與體學內整合視覺化。' } },
    { name: 'GC2MS', url: 'http://gc2ms.cmdm.tw/', img: '../../assets/GC2MSlogo.png', tag: 'GCxGC',
      kind: { en: 'Platform', zh: '分析平台' },
      desc: { en: 'An all-inclusive GCxGC/TOF-MS-based data analysis platform.', zh: '基於 GCxGC/TOF-MS 的全流程資料分析平台。' } },
    { name: 'PITracer', url: 'http://pitracer.cmdm.tw/', img: '../../assets/pitracer.png', tag: 'LC-MS',
      kind: { en: 'R package', zh: 'R 套件' },
      desc: { en: 'Pure ion chromatogram extraction for LC/QTOF-MS data.', zh: '從 LC/QTOF-MS 資料中萃取純離子層析圖。' } },
    { name: 'Chromaligner', url: 'http://chromaligner.cmdm.tw/', img: '../../assets/chromaligner.png', tag: { en: 'Alignment', zh: '訊號對位' },
      kind: { en: 'Web service', zh: '網頁服務' },
      desc: { en: 'Chromatogram alignment for comparative runs.', zh: '用於比較性分析的層析圖對位工具。' } },
    { name: 'MetaCore', url: 'http://web.cmdm.tw/metacore_portal/', img: '../../assets/metacore.png', tag: { en: 'Core lab', zh: '核心設施' },
      kind: { en: 'Portal', zh: '入口網站' },
      desc: { en: 'Web portal for the NTU Metabolomics Core Laboratory.', zh: '臺大代謝體學核心實驗室的入口網站。' } },
  ],

  pi: { en: 'Yufeng Jane Tseng', zh: '曾宇鳳' },

  postdocs: [
    { name: { en: 'Bo-Han Su', zh: '蘇伯翰' }, mail: 'suborhang[at]gmail.com',
      interests: { en: 'Computational chemistry and toxicology, cheminformatics, drug design', zh: '計算化學與毒理學、化學資訊學、藥物設計' } },
    { name: { en: 'Tien-Chueh Kuo', zh: '郭天爵' }, mail: 'cot[at]cmdm.csie.ntu.edu.tw',
      interests: { en: 'Biological interpretation in metabolomics, lipidomics workflows', zh: '代謝體學的生物意義解讀、脂質體學分析流程' } },
  ],

  phds: [
    { name: { en: 'Ming-Tsung Hsu', zh: '許明宗' }, mail: 'trams10[at]gmail.com',
      interests: { en: 'Systems biology, cancer biology, extracellular vesicles', zh: '系統生物學、癌症生物學、胞外囊泡' } },
    { name: { en: 'Ying-An Lin (Olivia)', zh: '林盈安' }, mail: 'olivia23lin[at]gmail.com',
      interests: { en: 'Computational chemistry and toxicology, cheminformatics', zh: '計算化學與毒理學、化學資訊學' } },
    { name: { en: 'Yu-Ke Wang', zh: '王于可' }, mail: 'cragger1027[at]gmail.com',
      interests: { en: 'Lung cancer stem cells, animal models, exosomes', zh: '肺癌幹細胞、動物模式、外泌體' } },
    { name: { en: 'Arthur Liu', zh: '劉亞瑟' }, mail: 'meteor260[at]gmail.com', interests: { en: '—', zh: '—' } },
  ],

  msc: [
    { name: { en: 'Yu-Yuan Yang', zh: '楊育源' }, mail: 'adp871111[at]gmail.com' },
    { name: { en: 'Ching-Yao Chang', zh: '張競堯' }, mail: 'myersccy[at]cmdm.csie.ntu.edu.tw' },
    { name: { en: 'Chien Lee', zh: '李健' }, mail: 'chienlee1003[at]cmdm.csie.ntu.edu.tw' },
    { name: { en: 'Yue-Chen Jung', zh: '榮鈺宸' }, mail: 'xholic54000[at]gmail.com' },
    { name: { en: 'Shou-Zhi Lin', zh: '林壽誌' }, mail: 'r10922088[at]ntu.edu.tw' },
    { name: { en: 'Chia-Yu Chang', zh: '張家瑜' }, mail: 'takoko1118[at]gmail.com' },
    { name: { en: 'Bo-Yang Yao', zh: '姚柏陽' }, mail: 'worldmap042288[at]gmail.com' },
    { name: { en: 'Yi-Xuan Zhan', zh: '詹以萱' }, mail: 'marty[at]cmdm.csie.ntu.edu.tw' },
    { name: { en: 'Guang-Cheng Xu', zh: '許光晟' }, mail: 'apple8952047[at]gmail.com' },
    { name: { en: 'Jie-Rui Tian', zh: '田杰睿' }, mail: 'jrtien[at]cmdm.csie.ntu.edu.tw' },
  ],

  // Degrees and thesis titles stay as recorded by the university.
  alumni: [
    { year: '2022', name: { en: 'Pei-Hwa Wang', zh: '王培華' }, degree: 'PhD, BEBI', thesis: { en: 'Cheminformatics, quantum informatics', zh: '化學資訊學、量子資訊學' } },
    { year: '2022', name: { en: 'Jen-Hao Chen', zh: '陳仁豪' }, degree: 'PhD, CS', thesis: { en: 'Cheminformatics, toxicology, computational chemistry, drug design', zh: '化學資訊學、毒理學、計算化學、藥物設計' } },
    { year: '2022', name: { en: 'Yu-Hao Ni', zh: '倪育豪' }, degree: 'MS, BEBI', thesis: { en: 'Construction of mouse brain MRI image', zh: '小鼠腦部磁振影像重建' } },
    { year: '2021', name: { en: 'Ming-Yang Ho', zh: '何明陽' }, degree: 'MS, BEBI', thesis: { en: "Deep learning-based Parkinson's disease evaluation with 3D point cloud and acoustic features", zh: '結合三維點雲與聲學特徵的深度學習帕金森氏症評估系統' } },
    { year: '2019', name: { en: 'Chia-Yu Chang', zh: '張家瑜' }, degree: 'MS, BEBI', thesis: { en: 'Systems biology, computational modelling of cells', zh: '系統生物學、細胞計算模型' } },
    { year: '2018', name: { en: 'Yi Hsiao', zh: '蕭羿' }, degree: 'MS, BEBI', thesis: { en: 'Virtual Rat: a systematic in silico preclinical ADMET prediction', zh: 'Virtual Rat：系統性電腦模擬臨床前 ADMET 預測' } },
    { year: '2017', name: { en: 'Dong-Ming Tsai', zh: '蔡東明' }, degree: 'Ph.D., BEBI', thesis: { en: 'HILIC-LC-MS based metabolomics of peritoneal dialysis effluent', zh: '基於 HILIC-LC-MS 的腹膜透析排液代謝體學研究' } },
    { year: '2015', name: { en: 'Tien-Chueh Kuo', zh: '郭天爵' }, degree: 'Ph.D., BEBI', thesis: { en: 'Metabolomics analysis in systems biology and a lipidomics knowledgebase', zh: '系統生物學中的代謝體學分析與脂質體學知識庫' } },
  ],

  publications: [
    { year: '2018', title: 'LipidPedia: a comprehensive lipid knowledgebase', venue: 'Bioinformatics', authors: 'Kuo TC, Tseng YJ', tag: { en: 'Lipidomics', zh: '脂質體學' } },
    { year: '2017', title: 'GAME: GPU-accelerated mixture elucidator', venue: 'J. Cheminformatics 9(1):50', authors: 'Schurz A, et al.', tag: { en: 'Software', zh: '軟體工具' } },
    { year: '2017', title: 'Trowaglerix venom polypeptides as a novel antithrombotic agent targeting glycoprotein VI', venue: 'Arterioscler. Thromb. Vasc. Biol.', authors: 'Chang CH, et al.', tag: { en: 'Drug design', zh: '藥物設計' } },
    { year: '2016', title: 'Mutagenicity in a molecule: core structural features of mutagenicity via scaffold analysis', venue: 'PLOS ONE 11(2)', authors: 'Hsu KH, et al.', tag: { en: 'Toxicology', zh: '毒理學' } },
    { year: '2016', title: 'An efficient and robust fatty acid profiling method for plasma metabolomic studies by GC-MS', venue: 'Clinica Chimica Acta', authors: 'Tsai DM, et al.', tag: { en: 'GC-MS', zh: '氣相質譜' } },
    { year: '2015', title: 'Matrix-induced ion suppression for concentration normalization in cellular metabolomics', venue: 'Analytical Chemistry', authors: 'Kuo TC, et al.', tag: { en: 'Metabolomics', zh: '代謝體學' } },
    { year: '2015', title: 'Synthesis and inhibitory effects of pyrimido-pyrrolo-quinoxalinedione analogues targeting influenza A H1N1', venue: 'Eur. J. Med. Chem.', authors: 'Tu YS, et al.', tag: { en: 'Drug design', zh: '藥物設計' } },
    { year: '2015', title: 'A portable micro gas chromatography system for volatile compounds detection at 15 ppb', venue: 'IEEE MEMS', authors: 'Wang SY, et al.', tag: { en: 'Instrumentation', zh: '儀器開發' } },
  ],
};

/** Pick a localised value; plain strings pass through untouched. */
window.L = (v, locale) => (v && typeof v === 'object' && !Array.isArray(v) && !v.$$typeof ? (v[locale] ?? v.en) : v);
