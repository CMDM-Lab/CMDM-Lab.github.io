function PeopleScreen({ t, cjk, locale }) {
  const { PageShell, Masthead, Ledger, LedgerItem, DataTable, Hairline, Kicker, ColophonTable } = window.CMDMLabDesignSystem_c5432b;
  const m = t.people;
  const L = window.L;
  const D = window.DATA;

  return (
    <PageShell width="wide">
      <Masthead cjk={cjk} kicker={m.kicker} title={m.title} subtitle={m.subtitle} lede={m.lede} />

      <Hairline tone="ink" style={{ marginTop: 'var(--space-6)' }} />
      <Kicker size="md" cjk={cjk}>{m.piLabel}</Kicker>
      <div style={{ display: 'flex', gap: 'var(--space-6)', flexWrap: 'wrap', marginTop: 'var(--space-4)' }}>
        <div style={{ flex: '0 0 200px', background: 'var(--white)', border: 'var(--border-hairline)', padding: 'var(--space-2)' }}>
          <img src="../../assets/professor.png" alt={L(D.pi, locale)} style={{ display: 'block', width: '100%', height: 'auto' }} />
        </div>
        <div style={{ flex: '1 1 380px', minWidth: 'min(100%, 380px)' }}>
          <h3 style={{ marginBottom: 'var(--space-2)' }}>{L(D.pi, locale)}</h3>
          <p style={{
            fontSize: cjk ? 'var(--text-lede)' : 'var(--font-size-body-lg)',
            lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
            color: 'var(--text-secondary)',
            maxWidth: cjk ? 'var(--measure-prose-cjk)' : 'var(--measure-prose)',
          }}>{m.piBio}</p>
          <div style={{ marginTop: 'var(--space-3)' }}>
            <ColophonTable entries={m.piFacts} />
          </div>
        </div>
      </div>

      <Hairline style={{ marginTop: 'var(--space-8)' }} />
      <Kicker size="md" cjk={cjk}>{m.postdocLabel}</Kicker>
      <Ledger style={{ marginTop: 'var(--space-3)' }}>
        {D.postdocs.map((p) => <LedgerItem key={p.mail} cjk={cjk} title={L(p.name, locale)} body={L(p.interests, locale)} meta={p.mail} />)}
      </Ledger>

      <Hairline style={{ marginTop: 'var(--space-6)' }} />
      <Kicker size="md" cjk={cjk}>{m.phdLabel}</Kicker>
      <Ledger style={{ marginTop: 'var(--space-3)' }}>
        {D.phds.map((p) => <LedgerItem key={p.mail} cjk={cjk} title={L(p.name, locale)} body={L(p.interests, locale)} meta={p.mail} />)}
      </Ledger>

      <Hairline style={{ marginTop: 'var(--space-6)' }} />
      <Kicker size="md" cjk={cjk}>{m.mscLabel}</Kicker>
      <div style={{ marginTop: 'var(--space-3)' }}>
        <DataTable
          columns={[{ key: 'name', label: m.cols.name }, { key: 'mail', label: m.cols.contact }]}
          rows={D.msc.map((p) => ({ name: L(p.name, locale), mail: <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-small)' }}>{p.mail}</span> }))} />
      </div>

      <Hairline tone="ink" style={{ marginTop: 'var(--space-8)' }} />
      <Kicker size="md" cjk={cjk}>{m.alumniLabel}</Kicker>
      <div style={{ marginTop: 'var(--space-3)' }}>
        <DataTable
          columns={[
            { key: 'year', label: m.cols.year, width: '10%' },
            { key: 'name', label: m.cols.name, width: '20%' },
            { key: 'degree', label: m.cols.degree, width: '16%' },
            { key: 'thesis', label: m.cols.thesis },
          ]}
          rows={D.alumni.map((a) => ({
            year: <span style={{ fontFamily: 'var(--font-mono)' }}>{a.year}</span>,
            name: L(a.name, locale),
            degree: <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-small)' }}>{a.degree}</span>,
            thesis: L(a.thesis, locale),
          }))} />
      </div>
    </PageShell>
  );
}

Object.assign(window, { PeopleScreen });
