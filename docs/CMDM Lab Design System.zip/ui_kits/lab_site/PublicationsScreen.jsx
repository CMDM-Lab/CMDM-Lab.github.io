function PublicationsScreen({ t, cjk, locale }) {
  const { PageShell, Masthead, DataTable, Hairline, Kicker, Input, Button, Tag } = window.CMDMLabDesignSystem_c5432b;
  const m = t.publications;
  const L = window.L;
  const [q, setQ] = React.useState('');

  const rows = window.DATA.publications;
  const shown = rows.filter((r) => (r.title + r.venue + r.authors + r.year + L(r.tag, locale)).toLowerCase().includes(q.toLowerCase()));

  return (
    <PageShell width="wide">
      <Masthead cjk={cjk} kicker={m.kicker} title={m.title} subtitle={m.subtitle} lede={m.lede} />

      <Hairline style={{ marginTop: 'var(--space-6)' }} />
      <div style={{ display: 'flex', gap: 'var(--space-2)', alignItems: 'flex-end', flexWrap: 'wrap' }}>
        <div style={{ flex: '1 1 320px' }}>
          <Input label={m.filterLabel} placeholder={m.filterHint} value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Button variant="secondary" onClick={() => setQ('')}>{m.clear}</Button>
        <Button variant="primary">{m.export}</Button>
      </div>

      <div style={{ marginTop: 'var(--space-6)' }}>
        <Kicker size="md" cjk={cjk}>{m.count(shown.length, rows.length)}</Kicker>
        <div style={{ marginTop: 'var(--space-3)' }}>
          <DataTable
            columns={[
              { key: 'year', label: m.cols.year, width: '8%' },
              { key: 'title', label: m.cols.title },
              { key: 'venue', label: m.cols.venue, width: '22%' },
              { key: 'authors', label: m.cols.authors, width: '16%' },
              { key: 'topic', label: m.cols.topic, width: '14%' },
            ]}
            rows={shown.map((r) => ({
              year: <span style={{ fontFamily: 'var(--font-mono)' }}>{r.year}</span>,
              title: r.title,
              venue: <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-small)' }}>{r.venue}</span>,
              authors: <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-small)' }}>{r.authors}</span>,
              topic: <Tag tone="brand">{L(r.tag, locale)}</Tag>,
            }))} />
        </div>
        {shown.length === 0 ? (
          <p style={{ marginTop: 'var(--space-4)', fontSize: 'var(--text-small)', color: 'var(--text-faint)' }}>{m.empty}</p>
        ) : null}
      </div>
    </PageShell>
  );
}

Object.assign(window, { PublicationsScreen });
