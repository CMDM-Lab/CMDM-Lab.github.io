# UI kit — CMDM lab site, Clinical Instrument language

Five screens, click-through via the sticky nav, **bilingual** — the 中文 / English button in the nav is live and the choice persists across reloads. Open `index.html`.

| Screen | What it demonstrates |
| --- | --- |
| `OverviewScreen.jsx` | Hero masthead, two-pillar ledger, article flow + colophon side by side, the one ink panel |
| `ResearchScreen.jsx` | Wide ledger with hairline-framed figure plates and brand tags |
| `ToolsScreen.jsx` | Eight-tool catalogue ledger + an access colophon |
| `PeopleScreen.jsx` | PI block, postdoc/PhD ledgers, member and alumni data tables |
| `PublicationsScreen.jsx` | Live text filter, primary/secondary buttons, five-column data table |

## Notes

- **Localisation.** `messages.js` holds the UI strings for both locales (flat keys, symmetrical key sets); `data.js` holds the content, with only translatable fields split per locale. Paper titles, journal names, tool names and degree codes stay in their original language on the Chinese page — correct academic practice, not an omission.
- **CJK typography.** Passing `cjk` to `Masthead`, `Prose`, `LedgerItem` and `Kicker` switches to 14px / 1.8 leading, a 38em measure, ragged-right alignment, and 12px sans kickers with no uppercasing. See the "CJK setting" card in the Type group.
- Content is the lab's real content, re-set in the new language — **not** a recreation of the old Bootstrap 3 site's layout. The old crimson system has been removed from this project entirely.
- Every screen composes design-system components; nothing is re-implemented locally.
- No media queries: columns reflow through `auto-fit` grids and `flex-basis` floors, per the source system's rule.
- The publication list is abridged (8 of roughly 200 entries) and the member roster is representative.
