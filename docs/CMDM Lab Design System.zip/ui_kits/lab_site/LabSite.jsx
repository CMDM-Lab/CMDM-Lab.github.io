function LabSite() {
  const { SiteNav, Footer, Button, PulseDot } = window.CMDMLabDesignSystem_c5432b;
  const [locale, setLocale] = React.useState(() => localStorage.getItem('cmdm-kit-locale') || 'en');
  const [page, setPage] = React.useState(0);
  const t = window.MESSAGES[locale];
  const cjk = locale === 'zh';

  React.useEffect(() => {
    localStorage.setItem('cmdm-kit-locale', locale);
    document.documentElement.lang = cjk ? 'zh-Hant' : 'en';
  }, [locale, cjk]);

  const SCREENS = [OverviewScreen, ResearchScreen, ToolsScreen, PeopleScreen, PublicationsScreen];
  const Screen = SCREENS[page] || SCREENS[0];

  return (
    <div>
      <SiteNav
        logoSrc="../../assets/logo.png"
        brand={t.brand}
        tagline={t.tagline}
        cjk={cjk}
        menuLabel={t.menuLabel}
        items={t.nav}
        active={t.nav[page]}
        onSelect={(label) => setPage(t.nav.indexOf(label))}
        right={<>
          <PulseDot label={t.status} />
          <Button variant="ghost" onClick={() => setLocale(cjk ? 'en' : 'zh')}>{t.langToggle}</Button>
        </>}
      />
      <Screen t={t} cjk={cjk} locale={locale} go={setPage} />
      <Footer lines={t.footer} label={t.footerLabel} cjk={cjk} />
    </div>
  );
}

Object.assign(window, { LabSite });
