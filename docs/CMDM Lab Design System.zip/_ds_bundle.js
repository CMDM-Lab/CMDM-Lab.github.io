/* @ds-bundle: {"format":4,"namespace":"CMDMLabDesignSystem_c5432b","components":[{"name":"ArticleFlow","sourcePath":"components/content/ArticleFlow.jsx"},{"name":"ColophonTable","sourcePath":"components/content/ColophonTable.jsx"},{"name":"DataTable","sourcePath":"components/content/DataTable.jsx"},{"name":"Ledger","sourcePath":"components/content/Ledger.jsx"},{"name":"LedgerItem","sourcePath":"components/content/LedgerItem.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Hairline","sourcePath":"components/core/Hairline.jsx"},{"name":"InkPanel","sourcePath":"components/core/InkPanel.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Kicker","sourcePath":"components/core/Kicker.jsx"},{"name":"PageShell","sourcePath":"components/core/PageShell.jsx"},{"name":"Prose","sourcePath":"components/core/PageShell.jsx"},{"name":"PulseDot","sourcePath":"components/core/PulseDot.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"Masthead","sourcePath":"components/navigation/Masthead.jsx"},{"name":"SiteNav","sourcePath":"components/navigation/SiteNav.jsx"}],"sourceHashes":{"components/content/ArticleFlow.jsx":"7d91157db74c","components/content/ColophonTable.jsx":"295315ebbc6b","components/content/DataTable.jsx":"ff52e8de5454","components/content/Ledger.jsx":"716bf0d3f5fc","components/content/LedgerItem.jsx":"c85eb3cd2f65","components/core/Button.jsx":"ee1113fcf97a","components/core/Hairline.jsx":"9177a3d7d517","components/core/InkPanel.jsx":"0811e9fd557c","components/core/Input.jsx":"3da7342c8d99","components/core/Kicker.jsx":"2caa703e59f4","components/core/PageShell.jsx":"1e8c7a08b237","components/core/PulseDot.jsx":"736cd6aea8b5","components/core/Tag.jsx":"0176700324a8","components/navigation/Footer.jsx":"1b6e1ddadee5","components/navigation/Masthead.jsx":"e74fab595e06","components/navigation/SiteNav.jsx":"0e2712b09679","ui_kits/lab_site/LabSite.jsx":"303e5b7e55e7","ui_kits/lab_site/OverviewScreen.jsx":"5392ec92aefa","ui_kits/lab_site/PeopleScreen.jsx":"0e40096ce5a8","ui_kits/lab_site/PublicationsScreen.jsx":"d8b3177b6f5b","ui_kits/lab_site/ResearchScreen.jsx":"c181fa812c52","ui_kits/lab_site/ToolsScreen.jsx":"7a5ee5a2c29f","ui_kits/lab_site/data.js":"6517cf6c80c9","ui_kits/lab_site/messages.js":"fd9d5af77408"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CMDMLabDesignSystem_c5432b = window.CMDMLabDesignSystem_c5432b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/ArticleFlow.jsx
try { (() => {
/** Journal two-column article flow with a hairline column rule. */
function ArticleFlow({
  columns = 2,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      columns,
      columnGap: 'var(--column-gap)',
      columnRule: 'var(--border-hairline)',
      fontSize: 'var(--text-lede)',
      lineHeight: 'var(--leading-body)',
      textAlign: 'justify',
      hyphens: 'auto',
      color: 'var(--text-secondary)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { ArticleFlow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ArticleFlow.jsx", error: String((e && e.message) || e) }); }

// components/content/ColophonTable.jsx
try { (() => {
/** Two-column label/value colophon table — tech stack, equipment, resources. */
function ColophonTable({
  entries = [],
  style
}) {
  return /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontVariantNumeric: 'tabular-nums',
      ...style
    }
  }, /*#__PURE__*/React.createElement("tbody", null, entries.map(e => /*#__PURE__*/React.createElement("tr", {
    key: e.label
  }, /*#__PURE__*/React.createElement("th", {
    style: {
      width: '34%',
      verticalAlign: 'top',
      textAlign: 'left',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-kicker-sm)',
      letterSpacing: 'var(--tracking-table-head)',
      textTransform: 'uppercase',
      padding: 'var(--space-2)',
      borderBottom: 'var(--border-row)',
      color: 'var(--neutral-600)',
      fontWeight: 'var(--weight-medium)'
    }
  }, e.label), /*#__PURE__*/React.createElement("td", {
    style: {
      fontSize: 'var(--text-table)',
      padding: 'var(--space-2)',
      borderBottom: 'var(--border-row)',
      color: 'var(--text-secondary)',
      verticalAlign: 'top'
    }
  }, e.value)))));
}
Object.assign(__ds_scope, { ColophonTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ColophonTable.jsx", error: String((e && e.message) || e) }); }

// components/content/DataTable.jsx
try { (() => {
/** Data table: mono uppercase heads over an ink rule, row hairlines, tabular nums. */
function DataTable({
  columns = [],
  rows = [],
  style
}) {
  return /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 'var(--text-lede)',
      fontVariantNumeric: 'tabular-nums',
      ...style
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key || c.label,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-kicker-sm)',
      letterSpacing: 'var(--tracking-table-head)',
      textTransform: 'uppercase',
      textAlign: c.align || 'left',
      padding: 'var(--space-2)',
      borderBottom: 'var(--border-ink)',
      color: 'var(--text)',
      width: c.width,
      fontWeight: 'var(--weight-medium)'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement(Row, {
    key: i,
    row: r,
    columns: columns
  }))));
}
function Row({
  row,
  columns
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("tr", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: hover ? 'var(--neutral-100)' : 'transparent'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key || c.label,
    style: {
      fontSize: 'var(--text-table)',
      padding: 'var(--space-2)',
      borderBottom: 'var(--border-row)',
      textAlign: c.align || 'left',
      verticalAlign: 'top',
      color: 'var(--text-secondary)'
    }
  }, row[c.key])));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/content/Ledger.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Unfilled auto-fit list container. No card fills — hairlines only. */
function Ledger({
  min,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'grid',
      gridTemplateColumns: `repeat(auto-fit, minmax(${min || 'var(--grid-min-ledger)'}, 1fr))`,
      borderTop: 'var(--border-hairline)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Ledger });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Ledger.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VARIANT = {
  primary: {
    background: 'var(--accent-600)',
    color: 'var(--white)',
    borderColor: 'var(--accent-600)'
  },
  secondary: {
    background: 'var(--surface)',
    color: 'var(--text)',
    borderColor: 'var(--divider)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--accent-600)',
    borderColor: 'transparent'
  }
};
const HOVER = {
  primary: {
    background: 'var(--accent-700)'
  },
  secondary: {
    background: 'color-mix(in srgb, var(--text) 7%, transparent)'
  },
  ghost: {
    background: 'color-mix(in srgb, var(--accent) 10%, transparent)'
  }
};
const ACTIVE = {
  primary: {
    background: 'var(--accent-800)'
  },
  secondary: {
    background: 'color-mix(in srgb, var(--text) 14%, transparent)'
  },
  ghost: {
    background: 'color-mix(in srgb, var(--accent) 18%, transparent)'
  }
};

/** Flat, zero-radius button. Three variants only: primary / secondary / ghost. */
function Button({
  variant = 'secondary',
  block = false,
  disabled = false,
  href,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [down, setDown] = React.useState(false);
  const v = VARIANT[variant] || VARIANT.secondary;
  const state = disabled ? null : down ? ACTIVE[variant] : hover ? HOVER[variant] : null;
  const css = {
    display: block ? 'flex' : 'inline-flex',
    width: block ? '100%' : undefined,
    marginTop: block ? 'var(--space-2)' : undefined,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    cursor: disabled ? 'not-allowed' : 'pointer',
    textDecoration: 'none',
    lineHeight: 'var(--leading-tight)',
    borderWidth: 1,
    borderStyle: 'solid',
    borderRadius: 0,
    whiteSpace: 'nowrap',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--weight-medium)',
    fontSize: 'var(--text-small)',
    padding: variant === 'ghost' ? 'var(--space-2) var(--space-1)' : 'var(--btn-pad-y) var(--btn-pad-x)',
    opacity: disabled ? 0.45 : 1,
    ...v,
    ...state,
    ...style
  };
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    disabled: !href ? disabled : undefined,
    style: css,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setDown(false);
    },
    onMouseDown: () => setDown(true),
    onMouseUp: () => setDown(false)
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Hairline.jsx
try { (() => {
/** The system's only elevation device: a 1px rule. `ink` closes a section. */
function Hairline({
  tone = 'divider',
  style
}) {
  const map = {
    divider: 'var(--divider)',
    ink: 'var(--text)',
    row: 'var(--neutral-200)'
  };
  return /*#__PURE__*/React.createElement("hr", {
    style: {
      height: 1,
      border: 0,
      margin: 'var(--space-4) 0',
      background: map[tone] || map.divider,
      opacity: tone === 'ink' ? 0.85 : 1,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Hairline });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Hairline.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Zero-radius text input. Hover darkens the border; focus turns it accent. */
function Input({
  as = 'input',
  label,
  hint,
  style,
  ...rest
}) {
  const Tag = as;
  const [hover, setHover] = React.useState(false);
  const [focus, setFocus] = React.useState(false);
  const field = /*#__PURE__*/React.createElement(Tag, _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      font: 'inherit',
      width: '100%',
      borderRadius: 0,
      minHeight: as === 'textarea' ? 90 : 36,
      resize: as === 'textarea' ? 'vertical' : undefined,
      borderWidth: 1,
      borderStyle: 'solid',
      borderColor: focus ? 'var(--accent-600)' : hover ? 'color-mix(in srgb, var(--text) 45%, transparent)' : 'var(--divider)',
      background: 'var(--white)',
      padding: as === 'textarea' ? 'var(--space-2)' : '0 var(--space-2)',
      fontSize: 'var(--font-size-body)',
      caretColor: 'var(--accent-600)',
      color: 'var(--text)',
      ...style
    }
  }, rest));
  if (!label && !hint) return field;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 'var(--text-small)',
      color: 'var(--neutral-700)'
    }
  }, label) : null, field, hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-kicker)',
      color: 'var(--neutral-600)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Kicker.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Mono uppercase micro-label. The system's only decorative type device. */
function Kicker({
  size = 'sm',
  tone = 'accent',
  cjk = false,
  as = 'span',
  children,
  style,
  ...rest
}) {
  const Tag = as;
  const color = tone === 'faint' ? 'var(--text-faint)' : tone === 'neutral' ? 'var(--neutral-600)' : 'var(--accent-700)';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      fontFamily: cjk ? 'var(--font-sans)' : 'var(--font-mono)',
      fontSize: cjk ? 'var(--text-kicker-cjk)' : size === 'md' ? 'var(--text-kicker)' : 'var(--text-kicker-sm)',
      letterSpacing: cjk ? 'var(--tracking-kicker-cjk)' : 'var(--tracking-kicker)',
      textTransform: cjk ? 'none' : 'uppercase',
      fontWeight: 'var(--weight-medium)',
      color,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Kicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Kicker.jsx", error: String((e && e.message) || e) }); }

// components/content/LedgerItem.jsx
try { (() => {
/** One row of a Ledger: mono index, title, body, meta line, → link. */
function LedgerItem({
  index,
  title,
  body,
  meta,
  href,
  linkLabel = 'Read',
  tags,
  imageSrc,
  justify = false,
  cjk = false,
  style
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("article", {
    style: {
      borderBottom: 'var(--border-hairline)',
      padding: 'var(--space-4) var(--space-6) var(--space-4) 0',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }, index ? /*#__PURE__*/React.createElement(__ds_scope.Kicker, null, index) : null, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontSize: 'var(--text-h4)',
      lineHeight: cjk ? 1.5 : 1.3
    }
  }, title), imageSrc ? /*#__PURE__*/React.createElement("img", {
    src: imageSrc,
    alt: "",
    style: {
      display: 'block',
      width: '100%',
      height: 'auto',
      border: 'var(--border-hairline)',
      marginTop: 'var(--space-1)'
    }
  }) : null, body ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: cjk ? 'var(--text-lede)' : 'var(--font-size-body-lg)',
      lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
      color: 'var(--text-secondary)',
      textAlign: justify && !cjk ? 'justify' : 'left',
      hyphens: justify && !cjk ? 'auto' : undefined
    }
  }, body) : null, tags && tags.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-1)',
      flexWrap: 'wrap'
    }
  }, tags) : null, meta ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-kicker)',
      color: 'var(--text-meta)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, meta) : null, href ? /*#__PURE__*/React.createElement("a", {
    href: href,
    target: "_blank",
    rel: "noreferrer",
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      fontSize: 'var(--text-small)',
      color: hover ? 'var(--accent-800)' : 'var(--accent-600)',
      marginTop: 'auto',
      paddingTop: 'var(--space-2)'
    }
  }, linkLabel, " \u2192") : null);
}
Object.assign(__ds_scope, { LedgerItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/LedgerItem.jsx", error: String((e && e.message) || e) }); }

// components/core/InkPanel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The loudest element on a page: 2px ink frame on white. Use at most once. */
function InkPanel({
  kicker,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      border: 'var(--border-plate)',
      background: 'var(--white)',
      padding: 'var(--space-6)',
      ...style
    }
  }, rest), kicker ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Kicker, {
    size: "md"
  }, kicker)) : null, children);
}
Object.assign(__ds_scope, { InkPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/InkPanel.jsx", error: String((e && e.message) || e) }); }

// components/core/PageShell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Page container: centred, max 960px, space-6/space-8 padding. */
function PageShell({
  width = 'default',
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      margin: '0 auto',
      width: '100%',
      maxWidth: width === 'wide' ? 'var(--page-max-wide)' : 'var(--page-max)',
      padding: 'var(--page-pad-y) var(--page-pad-x)',
      ...style
    }
  }, rest), children);
}

/** Prose column. Latin justifies at 64ch; CJK sets ragged-right at 38em / 1.8. */
function Prose({
  justify = true,
  size = 'body',
  cjk = false,
  children,
  style
}) {
  const doJustify = justify && !cjk;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: cjk ? 'var(--measure-prose-cjk)' : 'var(--measure-prose)',
      fontSize: cjk ? 'var(--text-lede)' : size === 'lede' ? 'var(--text-lede)' : 'var(--font-size-body-lg)',
      lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
      textAlign: doJustify ? 'justify' : 'left',
      hyphens: doJustify ? 'auto' : undefined,
      color: 'var(--text-secondary)',
      display: 'flex',
      flexDirection: 'column',
      gap: cjk ? 'var(--space-4)' : 'var(--space-3)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { PageShell, Prose });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/PageShell.jsx", error: String((e && e.message) || e) }); }

// components/core/PulseDot.jsx
try { (() => {
/** The one piece of motion in the system: a pulsing status dot. */
function PulseDot({
  label,
  size = 7,
  tone = 'accent',
  style
}) {
  const color = tone === 'brand' ? 'var(--brand-500)' : 'var(--accent-600)';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: 'var(--radius-circle)',
      background: color,
      animation: 'ds-pulse 1.4s ease-in-out infinite',
      flex: 'none'
    }
  }), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-kicker-sm)',
      letterSpacing: 'var(--tracking-kicker)',
      textTransform: 'uppercase',
      color: 'var(--neutral-600)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { PulseDot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/PulseDot.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONE = {
  accent: {
    background: 'var(--accent-100)',
    color: 'var(--accent-800)',
    border: '1px solid transparent'
  },
  neutral: {
    background: 'var(--neutral-200)',
    color: 'var(--neutral-700)',
    border: '1px solid transparent'
  },
  outline: {
    background: 'transparent',
    color: 'var(--accent-600)',
    border: '1px solid var(--accent-600)'
  },
  brand: {
    background: 'var(--brand-200)',
    color: 'var(--brand-800)',
    border: '1px solid transparent'
  }
};

/** Mono uppercase tag. Square, tiny, never a pill. */
function Tag({
  tone = 'neutral',
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-block',
      borderRadius: 0,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-kicker-sm)',
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      padding: '2px 6px',
      ...(TONE[tone] || TONE.neutral),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
/** Colophon-style footer: ink rule, mono meta lines, no columns of links. */
function Footer({
  lines = [],
  label = 'Colophon',
  note,
  cjk = false,
  style
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: 'var(--border-ink)',
      padding: 'var(--space-6) var(--nav-pad-x)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Kicker, {
    size: "sm",
    tone: "neutral",
    cjk: cjk
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-3)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-1)'
    }
  }, lines.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-small)',
      color: 'var(--text-meta)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, l))), note ? /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-3)',
      fontSize: 'var(--text-small)',
      color: 'var(--text-faint)'
    }
  }, note) : null);
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Masthead.jsx
try { (() => {
/** Journal-style page masthead: kicker → ink rule → title → subtitle → lede. */
function Masthead({
  kicker,
  title,
  subtitle,
  lede,
  hero = false,
  cjk = false,
  style
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: style
  }, kicker ? /*#__PURE__*/React.createElement(__ds_scope.Kicker, {
    size: "md",
    cjk: cjk
  }, kicker) : null, /*#__PURE__*/React.createElement(__ds_scope.Hairline, {
    tone: "ink",
    style: {
      margin: 'var(--space-2) 0 var(--space-4)'
    }
  }), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: hero ? 'var(--text-h1-hero)' : 'var(--text-h1)',
      lineHeight: cjk ? 1.3 : 1.1
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: cjk ? 'var(--font-sans)' : 'var(--font-mono)',
      fontSize: cjk ? 'var(--text-kicker-cjk)' : 'var(--text-kicker)',
      textTransform: cjk ? 'none' : 'uppercase',
      letterSpacing: cjk ? 'var(--tracking-kicker-cjk)' : 'var(--tracking-kicker)',
      color: 'var(--neutral-600)',
      marginTop: 'var(--space-2)'
    }
  }, subtitle) : null, lede ? /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-4)',
      maxWidth: cjk ? 'var(--measure-prose-cjk)' : 'var(--measure-prose)',
      fontSize: 'var(--text-lede)',
      lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
      textAlign: cjk ? 'left' : 'justify',
      hyphens: cjk ? undefined : 'auto',
      color: 'var(--text-secondary)'
    }
  }, lede) : null);
}
Object.assign(__ds_scope, { Masthead });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Masthead.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SiteNav.jsx
try { (() => {
function NavItem({
  label,
  active,
  onSelect,
  href
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href || '#',
    "aria-current": active ? 'page' : undefined,
    onClick: e => {
      if (onSelect) {
        e.preventDefault();
        onSelect(label);
      }
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      fontSize: 'var(--font-size-body-lg)',
      color: active ? 'var(--accent-600)' : 'var(--text-secondary)',
      textDecoration: 'none',
      paddingBottom: 2,
      borderBottom: `1px solid ${active || hover ? 'var(--accent-600)' : 'transparent'}`
    }
  }, label);
}

/** Sticky site nav: two-line brand block left, hairline-underlined links right. */
function SiteNav({
  brand = 'CMDM Lab',
  tagline = 'Computational Molecular Design & Metabolomics',
  logoSrc,
  items = [],
  active,
  onSelect,
  right,
  cjk = false,
  style
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 10,
      background: 'color-mix(in srgb, var(--bg) 92%, transparent)',
      backdropFilter: 'blur(var(--nav-blur))',
      borderBottom: 'var(--border-ink)',
      padding: 'var(--nav-pad-y) var(--nav-pad-x)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-6)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      flex: 'none'
    }
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "",
    style: {
      height: 30,
      width: 'auto',
      display: 'block'
    }
  }) : null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--tracking-heading)',
      lineHeight: 1.1
    }
  }, brand), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: cjk ? 'var(--font-sans)' : 'var(--font-mono)',
      fontSize: cjk ? 'var(--text-kicker-cjk)' : 'var(--text-kicker-sm)',
      textTransform: cjk ? 'none' : 'uppercase',
      letterSpacing: cjk ? 'var(--tracking-kicker-cjk)' : '0.18em',
      color: 'var(--neutral-600)',
      marginTop: 2
    }
  }, tagline))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      marginLeft: 'auto',
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, items.map(it => /*#__PURE__*/React.createElement(NavItem, {
    key: it.label || it,
    label: it.label || it,
    href: it.href,
    active: (it.label || it) === active,
    onSelect: onSelect
  })), right));
}
Object.assign(__ds_scope, { SiteNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SiteNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lab_site/LabSite.jsx
try { (() => {
function LabSite() {
  const {
    SiteNav,
    Footer,
    Button,
    PulseDot
  } = window.CMDMLabDesignSystem_c5432b;
  const [locale, setLocale] = React.useState(() => localStorage.getItem('cmdm-kit-locale') || 'en');
  const [page, setPage] = React.useState(0);
  const t = window.MESSAGES[locale];
  const cjk = locale === 'zh';
  React.useEffect(() => {
    localStorage.setItem('cmdm-kit-locale', locale);
    document.documentElement.lang = cjk ? 'zh-Hant' : 'en';
  }, [locale, cjk]);
  const SCREENS = [OverviewScreen, ResearchScreen, ToolsScreen, PeopleScreen, PublicationsScreen];
  const Screen = SCREENS[page] || SCREENS[0];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SiteNav, {
    logoSrc: "../../assets/logo.png",
    brand: t.brand,
    tagline: t.tagline,
    cjk: cjk,
    items: t.nav,
    active: t.nav[page],
    onSelect: label => setPage(t.nav.indexOf(label)),
    right: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(PulseDot, {
      label: t.status
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      onClick: () => setLocale(cjk ? 'en' : 'zh')
    }, t.langToggle))
  }), /*#__PURE__*/React.createElement(Screen, {
    t: t,
    cjk: cjk,
    locale: locale,
    go: setPage
  }), /*#__PURE__*/React.createElement(Footer, {
    lines: t.footer,
    label: t.footerLabel,
    cjk: cjk
  }));
}
Object.assign(window, {
  LabSite
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lab_site/LabSite.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lab_site/OverviewScreen.jsx
try { (() => {
function OverviewScreen({
  t,
  cjk,
  locale
}) {
  const {
    PageShell,
    Masthead,
    Ledger,
    LedgerItem,
    Hairline,
    InkPanel,
    Kicker,
    ColophonTable,
    Prose
  } = window.CMDMLabDesignSystem_c5432b;
  const m = t.overview;
  return /*#__PURE__*/React.createElement(PageShell, {
    width: "wide"
  }, /*#__PURE__*/React.createElement(Masthead, {
    hero: true,
    cjk: cjk,
    kicker: m.kicker,
    title: m.title,
    subtitle: m.subtitle,
    lede: m.lede
  }), /*#__PURE__*/React.createElement(Hairline, {
    style: {
      marginTop: 'var(--space-8)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.pillarsLabel), /*#__PURE__*/React.createElement(Ledger, {
    style: {
      marginTop: 'var(--space-3)'
    }
  }, m.pillars.map(p => /*#__PURE__*/React.createElement(LedgerItem, {
    key: p.index,
    cjk: cjk,
    index: p.index,
    title: p.title,
    body: p.body,
    meta: p.meta,
    href: "#",
    linkLabel: p.link
  }))), /*#__PURE__*/React.createElement(Hairline, {
    style: {
      marginTop: 'var(--space-8)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.recordLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-8)',
      flexWrap: 'wrap',
      marginTop: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 380px',
      minWidth: 'min(100%, 380px)'
    }
  }, /*#__PURE__*/React.createElement(Prose, {
    cjk: cjk,
    size: "lede"
  }, m.record.map((para, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    style: {
      margin: 0
    }
  }, para)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 320px',
      minWidth: 'min(100%, 320px)'
    }
  }, /*#__PURE__*/React.createElement(ColophonTable, {
    entries: m.facts
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement(InkPanel, {
    kicker: m.recruitKicker
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--text-lede)',
      lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
      maxWidth: cjk ? 'var(--measure-prose-cjk)' : 'var(--measure-prose)'
    }
  }, m.recruitBody, /*#__PURE__*/React.createElement("a", {
    href: "mailto:yjtseng@csie.ntu.edu.tw"
  }, "yjtseng[at]csie.ntu.edu.tw"), m.recruitTail))));
}
Object.assign(window, {
  OverviewScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lab_site/OverviewScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lab_site/PeopleScreen.jsx
try { (() => {
function PeopleScreen({
  t,
  cjk,
  locale
}) {
  const {
    PageShell,
    Masthead,
    Ledger,
    LedgerItem,
    DataTable,
    Hairline,
    Kicker,
    ColophonTable
  } = window.CMDMLabDesignSystem_c5432b;
  const m = t.people;
  const L = window.L;
  const D = window.DATA;
  return /*#__PURE__*/React.createElement(PageShell, {
    width: "wide"
  }, /*#__PURE__*/React.createElement(Masthead, {
    cjk: cjk,
    kicker: m.kicker,
    title: m.title,
    subtitle: m.subtitle,
    lede: m.lede
  }), /*#__PURE__*/React.createElement(Hairline, {
    tone: "ink",
    style: {
      marginTop: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.piLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      flexWrap: 'wrap',
      marginTop: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '0 0 200px',
      background: 'var(--white)',
      border: 'var(--border-hairline)',
      padding: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/professor.png",
    alt: L(D.pi, locale),
    style: {
      display: 'block',
      width: '100%',
      height: 'auto'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 380px',
      minWidth: 'min(100%, 380px)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      marginBottom: 'var(--space-2)'
    }
  }, L(D.pi, locale)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: cjk ? 'var(--text-lede)' : 'var(--font-size-body-lg)',
      lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
      color: 'var(--text-secondary)',
      maxWidth: cjk ? 'var(--measure-prose-cjk)' : 'var(--measure-prose)'
    }
  }, m.piBio), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(ColophonTable, {
    entries: m.piFacts
  })))), /*#__PURE__*/React.createElement(Hairline, {
    style: {
      marginTop: 'var(--space-8)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.postdocLabel), /*#__PURE__*/React.createElement(Ledger, {
    style: {
      marginTop: 'var(--space-3)'
    }
  }, D.postdocs.map(p => /*#__PURE__*/React.createElement(LedgerItem, {
    key: p.mail,
    cjk: cjk,
    title: L(p.name, locale),
    body: L(p.interests, locale),
    meta: p.mail
  }))), /*#__PURE__*/React.createElement(Hairline, {
    style: {
      marginTop: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.phdLabel), /*#__PURE__*/React.createElement(Ledger, {
    style: {
      marginTop: 'var(--space-3)'
    }
  }, D.phds.map(p => /*#__PURE__*/React.createElement(LedgerItem, {
    key: p.mail,
    cjk: cjk,
    title: L(p.name, locale),
    body: L(p.interests, locale),
    meta: p.mail
  }))), /*#__PURE__*/React.createElement(Hairline, {
    style: {
      marginTop: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.mscLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'name',
      label: m.cols.name
    }, {
      key: 'mail',
      label: m.cols.contact
    }],
    rows: D.msc.map(p => ({
      name: L(p.name, locale),
      mail: /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          fontSize: 'var(--text-small)'
        }
      }, p.mail)
    }))
  })), /*#__PURE__*/React.createElement(Hairline, {
    tone: "ink",
    style: {
      marginTop: 'var(--space-8)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.alumniLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'year',
      label: m.cols.year,
      width: '10%'
    }, {
      key: 'name',
      label: m.cols.name,
      width: '20%'
    }, {
      key: 'degree',
      label: m.cols.degree,
      width: '16%'
    }, {
      key: 'thesis',
      label: m.cols.thesis
    }],
    rows: D.alumni.map(a => ({
      year: /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)'
        }
      }, a.year),
      name: L(a.name, locale),
      degree: /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          fontSize: 'var(--text-small)'
        }
      }, a.degree),
      thesis: L(a.thesis, locale)
    }))
  })));
}
Object.assign(window, {
  PeopleScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lab_site/PeopleScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lab_site/PublicationsScreen.jsx
try { (() => {
function PublicationsScreen({
  t,
  cjk,
  locale
}) {
  const {
    PageShell,
    Masthead,
    DataTable,
    Hairline,
    Kicker,
    Input,
    Button,
    Tag
  } = window.CMDMLabDesignSystem_c5432b;
  const m = t.publications;
  const L = window.L;
  const [q, setQ] = React.useState('');
  const rows = window.DATA.publications;
  const shown = rows.filter(r => (r.title + r.venue + r.authors + r.year + L(r.tag, locale)).toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement(PageShell, {
    width: "wide"
  }, /*#__PURE__*/React.createElement(Masthead, {
    cjk: cjk,
    kicker: m.kicker,
    title: m.title,
    subtitle: m.subtitle,
    lede: m.lede
  }), /*#__PURE__*/React.createElement(Hairline, {
    style: {
      marginTop: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)',
      alignItems: 'flex-end',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 320px'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: m.filterLabel,
    placeholder: m.filterHint,
    value: q,
    onChange: e => setQ(e.target.value)
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => setQ('')
  }, m.clear), /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, m.export)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.count(shown.length, rows.length)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'year',
      label: m.cols.year,
      width: '8%'
    }, {
      key: 'title',
      label: m.cols.title
    }, {
      key: 'venue',
      label: m.cols.venue,
      width: '22%'
    }, {
      key: 'authors',
      label: m.cols.authors,
      width: '16%'
    }, {
      key: 'topic',
      label: m.cols.topic,
      width: '14%'
    }],
    rows: shown.map(r => ({
      year: /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)'
        }
      }, r.year),
      title: r.title,
      venue: /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          fontSize: 'var(--text-small)'
        }
      }, r.venue),
      authors: /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          fontSize: 'var(--text-small)'
        }
      }, r.authors),
      topic: /*#__PURE__*/React.createElement(Tag, {
        tone: "brand"
      }, L(r.tag, locale))
    }))
  })), shown.length === 0 ? /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'var(--space-4)',
      fontSize: 'var(--text-small)',
      color: 'var(--text-faint)'
    }
  }, m.empty) : null));
}
Object.assign(window, {
  PublicationsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lab_site/PublicationsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lab_site/ResearchScreen.jsx
try { (() => {
function ResearchScreen({
  t,
  cjk,
  locale
}) {
  const {
    PageShell,
    Masthead,
    Ledger,
    LedgerItem,
    Tag,
    Hairline,
    Kicker
  } = window.CMDMLabDesignSystem_c5432b;
  const m = t.research;
  const L = window.L;
  return /*#__PURE__*/React.createElement(PageShell, {
    width: "wide"
  }, /*#__PURE__*/React.createElement(Masthead, {
    cjk: cjk,
    kicker: m.kicker,
    title: m.title,
    subtitle: m.subtitle,
    lede: m.lede
  }), /*#__PURE__*/React.createElement(Hairline, {
    style: {
      marginTop: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.listLabel), /*#__PURE__*/React.createElement(Ledger, {
    min: "var(--grid-min-wide)",
    style: {
      marginTop: 'var(--space-3)'
    }
  }, window.DATA.papers.map(p => /*#__PURE__*/React.createElement(LedgerItem, {
    key: p.index,
    cjk: cjk,
    index: p.index,
    title: p.title,
    body: L(p.body, locale),
    meta: p.meta,
    imageSrc: p.img,
    href: "#",
    linkLabel: m.link,
    tags: [/*#__PURE__*/React.createElement(Tag, {
      key: "t",
      tone: "brand"
    }, L(p.tag, locale))]
  }))));
}
Object.assign(window, {
  ResearchScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lab_site/ResearchScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lab_site/ToolsScreen.jsx
try { (() => {
function ToolsScreen({
  t,
  cjk,
  locale
}) {
  const {
    PageShell,
    Masthead,
    Ledger,
    LedgerItem,
    Tag,
    Hairline,
    Kicker,
    ColophonTable
  } = window.CMDMLabDesignSystem_c5432b;
  const m = t.tools;
  const L = window.L;
  return /*#__PURE__*/React.createElement(PageShell, {
    width: "wide"
  }, /*#__PURE__*/React.createElement(Masthead, {
    cjk: cjk,
    kicker: m.kicker,
    title: m.title,
    subtitle: m.subtitle,
    lede: m.lede
  }), /*#__PURE__*/React.createElement(Hairline, {
    style: {
      marginTop: 'var(--space-6)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.listLabel), /*#__PURE__*/React.createElement(Ledger, {
    style: {
      marginTop: 'var(--space-3)'
    }
  }, window.DATA.tools.map(tool => /*#__PURE__*/React.createElement(LedgerItem, {
    key: tool.name,
    cjk: cjk,
    title: tool.name,
    body: L(tool.desc, locale),
    imageSrc: tool.img,
    meta: `${tool.url.replace(/^https?:\/\//, '').replace(/\/$/, '')} · ${L(tool.kind, locale)}`,
    href: tool.url,
    linkLabel: m.link,
    tags: [/*#__PURE__*/React.createElement(Tag, {
      key: "t",
      tone: "brand"
    }, L(tool.tag, locale))]
  }))), /*#__PURE__*/React.createElement(Hairline, {
    tone: "ink",
    style: {
      marginTop: 'var(--space-8)'
    }
  }), /*#__PURE__*/React.createElement(Kicker, {
    size: "md",
    cjk: cjk
  }, m.accessLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-3)',
      maxWidth: 640
    }
  }, /*#__PURE__*/React.createElement(ColophonTable, {
    entries: m.access
  })));
}
Object.assign(window, {
  ToolsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lab_site/ToolsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/lab_site/data.js
try { (() => {
// Content data. Paper and tool NAMES stay in their original language — that is
// correct academic practice — only descriptions, topics and person names localise.
window.DATA = {
  papers: [{
    index: 'I',
    title: 'Mutagenicity in a Molecule: Identification of Core Structural Features of Mutagenicity Using a Scaffold Analysis',
    meta: 'PLOS ONE · 2016 · doi:10.1371/journal.pone.0148900',
    img: '../../assets/research.png',
    body: {
      en: 'With advances in the development and application of Ames mutagenicity in silico prediction tools, the International Conference on Harmonisation has amended its M7 guideline to reflect the use of such prediction models in early drug safety evaluation.',
      zh: '隨著 Ames 致突變性電腦模擬預測工具的發展與應用日趨成熟，國際醫藥法規協和會已修訂 M7 指引，納入此類預測模型於早期藥物安全性評估的使用規範。'
    },
    tag: {
      en: 'Toxicology',
      zh: '毒理學'
    }
  }, {
    index: 'II',
    title: 'Using the Matrix-Induced Ion Suppression Method for Concentration Normalization in Cellular Metabolomics Studies',
    meta: 'Analytical Chemistry · 2015',
    img: '../../assets/research_2.png',
    body: {
      en: 'Most cellular metabolomics studies control only cell numbers or protein content without adjusting total metabolite concentration, mainly because no effective normalization method existed.',
      zh: '多數細胞代謝體學研究僅控制細胞數或蛋白質含量，而未校正總代謝物濃度，主因是先前缺乏有效的濃度正規化方法。'
    },
    tag: {
      en: 'Metabolomics',
      zh: '代謝體學'
    }
  }, {
    index: 'III',
    title: 'An efficient and robust fatty acid profiling method for plasma metabolomic studies by GC-MS',
    meta: 'Clinica Chimica Acta · 2016',
    body: {
      en: 'Targeted metabolomic analysis of fatty acids has linked their dysregulation to many diseases. Five frequently used derivatization methods were compared for robustness and coverage.',
      zh: '脂肪酸的標的代謝體學分析已將其失調與多種疾病連結。本研究比較五種常用衍生化方法的穩定性與偵測涵蓋率。'
    },
    tag: {
      en: 'GC-MS',
      zh: '氣相質譜'
    }
  }, {
    index: 'IV',
    title: 'A portable micro gas chromatography system for volatile compounds detection with 15 ppb sensitivity',
    meta: 'IEEE MEMS · 2015',
    body: {
      en: 'Volatile organic compounds in human breath can provide biomarkers for disease. Existing non-invasive equipment struggles with early-stage lung cancer, where abnormal tissue is under 0.5 cm.',
      zh: '人體呼氣中的揮發性有機化合物可作為疾病生物標記。現有非侵入式儀器難以偵測早期肺癌，因其異常組織小於 0.5 公分。'
    },
    tag: {
      en: 'Instrumentation',
      zh: '儀器開發'
    }
  }, {
    index: 'V',
    title: 'Synthesis and inhibitory effects of novel pyrimido-pyrrolo-quinoxalinedione analogues targeting influenza A H1N1 nucleoproteins',
    meta: 'Eur. J. Med. Chem. · 2015',
    body: {
      en: 'The influenza nucleoprotein is a single-strand RNA-binding protein at the core of the ribonucleoprotein particle, serving several functions critical to viral replication.',
      zh: '流感核蛋白為單股 RNA 結合蛋白，位於核糖核蛋白顆粒的核心，承擔多項對病毒複製至關重要的功能。'
    },
    tag: {
      en: 'Drug design',
      zh: '藥物設計'
    }
  }],
  tools: [{
    name: 'Virtual Rat',
    url: 'https://virtualrat.cmdm.tw/',
    img: '../../assets/virtual_rat.png',
    tag: 'ADMET',
    kind: {
      en: 'Web service',
      zh: '網頁服務'
    },
    desc: {
      en: 'Predictions of important ADMET properties, together with the structural reasoning behind each call.',
      zh: '預測重要的 ADMET 性質，並同時提供模型判斷所依據的結構理由。'
    }
  }, {
    name: 'CypRules',
    url: 'http://cyprules.cmdm.tw/',
    img: '../../assets/cyprules_2.png',
    tag: 'CYP450',
    kind: {
      en: 'Web service',
      zh: '網頁服務'
    },
    desc: {
      en: 'Predicts metabolizing Cytochrome P450 inhibition for CYP1A2, CYP2C19, CYP2C9, CYP2D6 and CYP3A4.',
      zh: '預測細胞色素 P450 代謝酵素的抑制情形，涵蓋 CYP1A2、CYP2C19、CYP2C9、CYP2D6 與 CYP3A4。'
    }
  }, {
    name: 'Lipidpedia',
    url: 'http://lipidpedia.cmdm.tw',
    img: '../../assets/LipidPedia.png',
    tag: {
      en: 'Lipidomics',
      zh: '脂質體學'
    },
    kind: {
      en: 'Knowledgebase',
      zh: '知識庫'
    },
    desc: {
      en: 'An encyclopedia of lipids providing associated biomedical information mined from the literature.',
      zh: '脂質百科全書，透過文獻探勘提供與各脂質相關的生醫資訊。'
    }
  }, {
    name: '3Omics',
    url: 'http://3omics.cmdm.tw',
    img: '../../assets/3omics.png',
    tag: {
      en: 'Multi-omics',
      zh: '多體學整合'
    },
    kind: {
      en: 'Web service',
      zh: '網頁服務'
    },
    desc: {
      en: 'One-click visualisation and integration of inter- and intra-transcriptomic, proteomic and metabolomic human data.',
      zh: '一鍵完成人類轉錄體、蛋白體與代謝體資料的跨體學與體學內整合視覺化。'
    }
  }, {
    name: 'GC2MS',
    url: 'http://gc2ms.cmdm.tw/',
    img: '../../assets/GC2MSlogo.png',
    tag: 'GCxGC',
    kind: {
      en: 'Platform',
      zh: '分析平台'
    },
    desc: {
      en: 'An all-inclusive GCxGC/TOF-MS-based data analysis platform.',
      zh: '基於 GCxGC/TOF-MS 的全流程資料分析平台。'
    }
  }, {
    name: 'PITracer',
    url: 'http://pitracer.cmdm.tw/',
    img: '../../assets/pitracer.png',
    tag: 'LC-MS',
    kind: {
      en: 'R package',
      zh: 'R 套件'
    },
    desc: {
      en: 'Pure ion chromatogram extraction for LC/QTOF-MS data.',
      zh: '從 LC/QTOF-MS 資料中萃取純離子層析圖。'
    }
  }, {
    name: 'Chromaligner',
    url: 'http://chromaligner.cmdm.tw/',
    img: '../../assets/chromaligner.png',
    tag: {
      en: 'Alignment',
      zh: '訊號對位'
    },
    kind: {
      en: 'Web service',
      zh: '網頁服務'
    },
    desc: {
      en: 'Chromatogram alignment for comparative runs.',
      zh: '用於比較性分析的層析圖對位工具。'
    }
  }, {
    name: 'MetaCore',
    url: 'http://web.cmdm.tw/metacore_portal/',
    img: '../../assets/metacore.png',
    tag: {
      en: 'Core lab',
      zh: '核心設施'
    },
    kind: {
      en: 'Portal',
      zh: '入口網站'
    },
    desc: {
      en: 'Web portal for the NTU Metabolomics Core Laboratory.',
      zh: '臺大代謝體學核心實驗室的入口網站。'
    }
  }],
  pi: {
    en: 'Yufeng Jane Tseng',
    zh: '曾宇鳳'
  },
  postdocs: [{
    name: {
      en: 'Bo-Han Su',
      zh: '蘇伯翰'
    },
    mail: 'suborhang[at]gmail.com',
    interests: {
      en: 'Computational chemistry and toxicology, cheminformatics, drug design',
      zh: '計算化學與毒理學、化學資訊學、藥物設計'
    }
  }, {
    name: {
      en: 'Tien-Chueh Kuo',
      zh: '郭天爵'
    },
    mail: 'cot[at]cmdm.csie.ntu.edu.tw',
    interests: {
      en: 'Biological interpretation in metabolomics, lipidomics workflows',
      zh: '代謝體學的生物意義解讀、脂質體學分析流程'
    }
  }],
  phds: [{
    name: {
      en: 'Ming-Tsung Hsu',
      zh: '許明宗'
    },
    mail: 'trams10[at]gmail.com',
    interests: {
      en: 'Systems biology, cancer biology, extracellular vesicles',
      zh: '系統生物學、癌症生物學、胞外囊泡'
    }
  }, {
    name: {
      en: 'Ying-An Lin (Olivia)',
      zh: '林盈安'
    },
    mail: 'olivia23lin[at]gmail.com',
    interests: {
      en: 'Computational chemistry and toxicology, cheminformatics',
      zh: '計算化學與毒理學、化學資訊學'
    }
  }, {
    name: {
      en: 'Yu-Ke Wang',
      zh: '王于可'
    },
    mail: 'cragger1027[at]gmail.com',
    interests: {
      en: 'Lung cancer stem cells, animal models, exosomes',
      zh: '肺癌幹細胞、動物模式、外泌體'
    }
  }, {
    name: {
      en: 'Arthur Liu',
      zh: '劉亞瑟'
    },
    mail: 'meteor260[at]gmail.com',
    interests: {
      en: '—',
      zh: '—'
    }
  }],
  msc: [{
    name: {
      en: 'Yu-Yuan Yang',
      zh: '楊育源'
    },
    mail: 'adp871111[at]gmail.com'
  }, {
    name: {
      en: 'Ching-Yao Chang',
      zh: '張競堯'
    },
    mail: 'myersccy[at]cmdm.csie.ntu.edu.tw'
  }, {
    name: {
      en: 'Chien Lee',
      zh: '李健'
    },
    mail: 'chienlee1003[at]cmdm.csie.ntu.edu.tw'
  }, {
    name: {
      en: 'Yue-Chen Jung',
      zh: '榮鈺宸'
    },
    mail: 'xholic54000[at]gmail.com'
  }, {
    name: {
      en: 'Shou-Zhi Lin',
      zh: '林壽誌'
    },
    mail: 'r10922088[at]ntu.edu.tw'
  }, {
    name: {
      en: 'Chia-Yu Chang',
      zh: '張家瑜'
    },
    mail: 'takoko1118[at]gmail.com'
  }, {
    name: {
      en: 'Bo-Yang Yao',
      zh: '姚柏陽'
    },
    mail: 'worldmap042288[at]gmail.com'
  }, {
    name: {
      en: 'Yi-Xuan Zhan',
      zh: '詹以萱'
    },
    mail: 'marty[at]cmdm.csie.ntu.edu.tw'
  }, {
    name: {
      en: 'Guang-Cheng Xu',
      zh: '許光晟'
    },
    mail: 'apple8952047[at]gmail.com'
  }, {
    name: {
      en: 'Jie-Rui Tian',
      zh: '田杰睿'
    },
    mail: 'jrtien[at]cmdm.csie.ntu.edu.tw'
  }],
  // Degrees and thesis titles stay as recorded by the university.
  alumni: [{
    year: '2022',
    name: {
      en: 'Pei-Hwa Wang',
      zh: '王培華'
    },
    degree: 'PhD, BEBI',
    thesis: {
      en: 'Cheminformatics, quantum informatics',
      zh: '化學資訊學、量子資訊學'
    }
  }, {
    year: '2022',
    name: {
      en: 'Jen-Hao Chen',
      zh: '陳仁豪'
    },
    degree: 'PhD, CS',
    thesis: {
      en: 'Cheminformatics, toxicology, computational chemistry, drug design',
      zh: '化學資訊學、毒理學、計算化學、藥物設計'
    }
  }, {
    year: '2022',
    name: {
      en: 'Yu-Hao Ni',
      zh: '倪育豪'
    },
    degree: 'MS, BEBI',
    thesis: {
      en: 'Construction of mouse brain MRI image',
      zh: '小鼠腦部磁振影像重建'
    }
  }, {
    year: '2021',
    name: {
      en: 'Ming-Yang Ho',
      zh: '何明陽'
    },
    degree: 'MS, BEBI',
    thesis: {
      en: "Deep learning-based Parkinson's disease evaluation with 3D point cloud and acoustic features",
      zh: '結合三維點雲與聲學特徵的深度學習帕金森氏症評估系統'
    }
  }, {
    year: '2019',
    name: {
      en: 'Chia-Yu Chang',
      zh: '張家瑜'
    },
    degree: 'MS, BEBI',
    thesis: {
      en: 'Systems biology, computational modelling of cells',
      zh: '系統生物學、細胞計算模型'
    }
  }, {
    year: '2018',
    name: {
      en: 'Yi Hsiao',
      zh: '蕭羿'
    },
    degree: 'MS, BEBI',
    thesis: {
      en: 'Virtual Rat: a systematic in silico preclinical ADMET prediction',
      zh: 'Virtual Rat：系統性電腦模擬臨床前 ADMET 預測'
    }
  }, {
    year: '2017',
    name: {
      en: 'Dong-Ming Tsai',
      zh: '蔡東明'
    },
    degree: 'Ph.D., BEBI',
    thesis: {
      en: 'HILIC-LC-MS based metabolomics of peritoneal dialysis effluent',
      zh: '基於 HILIC-LC-MS 的腹膜透析排液代謝體學研究'
    }
  }, {
    year: '2015',
    name: {
      en: 'Tien-Chueh Kuo',
      zh: '郭天爵'
    },
    degree: 'Ph.D., BEBI',
    thesis: {
      en: 'Metabolomics analysis in systems biology and a lipidomics knowledgebase',
      zh: '系統生物學中的代謝體學分析與脂質體學知識庫'
    }
  }],
  publications: [{
    year: '2018',
    title: 'LipidPedia: a comprehensive lipid knowledgebase',
    venue: 'Bioinformatics',
    authors: 'Kuo TC, Tseng YJ',
    tag: {
      en: 'Lipidomics',
      zh: '脂質體學'
    }
  }, {
    year: '2017',
    title: 'GAME: GPU-accelerated mixture elucidator',
    venue: 'J. Cheminformatics 9(1):50',
    authors: 'Schurz A, et al.',
    tag: {
      en: 'Software',
      zh: '軟體工具'
    }
  }, {
    year: '2017',
    title: 'Trowaglerix venom polypeptides as a novel antithrombotic agent targeting glycoprotein VI',
    venue: 'Arterioscler. Thromb. Vasc. Biol.',
    authors: 'Chang CH, et al.',
    tag: {
      en: 'Drug design',
      zh: '藥物設計'
    }
  }, {
    year: '2016',
    title: 'Mutagenicity in a molecule: core structural features of mutagenicity via scaffold analysis',
    venue: 'PLOS ONE 11(2)',
    authors: 'Hsu KH, et al.',
    tag: {
      en: 'Toxicology',
      zh: '毒理學'
    }
  }, {
    year: '2016',
    title: 'An efficient and robust fatty acid profiling method for plasma metabolomic studies by GC-MS',
    venue: 'Clinica Chimica Acta',
    authors: 'Tsai DM, et al.',
    tag: {
      en: 'GC-MS',
      zh: '氣相質譜'
    }
  }, {
    year: '2015',
    title: 'Matrix-induced ion suppression for concentration normalization in cellular metabolomics',
    venue: 'Analytical Chemistry',
    authors: 'Kuo TC, et al.',
    tag: {
      en: 'Metabolomics',
      zh: '代謝體學'
    }
  }, {
    year: '2015',
    title: 'Synthesis and inhibitory effects of pyrimido-pyrrolo-quinoxalinedione analogues targeting influenza A H1N1',
    venue: 'Eur. J. Med. Chem.',
    authors: 'Tu YS, et al.',
    tag: {
      en: 'Drug design',
      zh: '藥物設計'
    }
  }, {
    year: '2015',
    title: 'A portable micro gas chromatography system for volatile compounds detection at 15 ppb',
    venue: 'IEEE MEMS',
    authors: 'Wang SY, et al.',
    tag: {
      en: 'Instrumentation',
      zh: '儀器開發'
    }
  }]
};

/** Pick a localised value; plain strings pass through untouched. */
window.L = (v, locale) => v && typeof v === 'object' && !Array.isArray(v) && !v.$$typeof ? v[locale] ?? v.en : v;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lab_site/data.js", error: String((e && e.message) || e) }); }

// ui_kits/lab_site/messages.js
try { (() => {
// Flat-ish message dictionary. Both locales must carry the same key set.
window.MESSAGES = {
  en: {
    nav: ['Overview', 'Research', 'Tools', 'People', 'Publications'],
    langToggle: '中文',
    status: 'Core online',
    footerLabel: 'Colophon',
    brand: 'CMDM Lab',
    tagline: 'Computational Molecular Design & Metabolomics',
    footer: ['No. 1 Roosevelt Rd. Sec. 4, Taipei 106, Taiwan', '+886-2-33664888 #403 · R529, Dept. of CSIE, National Taiwan University', '© 2006–2026 Computational Molecular Design & Metabolomics Laboratory'],
    overview: {
      kicker: 'NTU CSIE · Est. 2006',
      title: 'Computational Molecular Design & Metabolomics Lab',
      subtitle: 'Prof. Yufeng Jane Tseng · Department of Computer Science & Information Engineering',
      lede: 'We develop algorithms and tools to identify and design molecular structures for targeted use, and to detect biomarkers in clinical metabolomics cohorts. Our methods are published in international journals and are in active use for biomarker development in Taiwan and the United States.',
      pillarsLabel: 'Two research pillars',
      pillars: [{
        index: 'I',
        title: 'Computational Molecular Design',
        body: 'Computer-aided drug design and A.I. for drug discovery: structure-based fragment hopping for lead optimisation, synthetic-accessibility scoring, and in silico toxicity prediction.',
        meta: '6 NRPB drug development projects · U.S. patents',
        link: 'Research'
      }, {
        index: 'II',
        title: 'Metabolomics',
        body: 'Biomarker detection and precision medicine: mass-spectrometry and NMR computing methods for clinical cohorts, from welding-fume exposure to ICU mortality prediction.',
        meta: 'NTU Metabolomics Core Laboratory',
        link: 'Research'
      }],
      recordLabel: 'Lab record',
      record: ['The lab was involved in six drug development projects in the National Research Program for Biopharmaceuticals, in collaboration with the chemistry and pharmacy departments of China Medical University, National Tsing Hua University, Taipei Medical University and others. Our primary objective is to develop treatments for neuropathic pain, thrombosis and cancer.', 'In metabolomics, the mass spectrometry and NMR computing methods we developed have been published in Analytical Chemistry and applied to compound identification in Chinese herbs, hypoxia in breast cancer cells, and molecular markers for lung cancer and leukaemia.'],
      facts: [{
        label: 'Director',
        value: 'Prof. Yufeng Jane Tseng'
      }, {
        label: 'Affiliation',
        value: 'NTU CSIE · GINM · BEBI'
      }, {
        label: 'Platforms',
        value: 'LC-QTOF-MS · GCxGC/TOF-MS · 1D ¹H-NMR'
      }, {
        label: 'Public tools',
        value: '8 services under *.cmdm.tw'
      }, {
        label: 'Alumni',
        value: '40+ since 2008'
      }],
      recruitKicker: 'Now recruiting',
      recruitBody: 'We are looking for graduate students with a background in cheminformatics, mass spectrometry, or machine learning. Write to ',
      recruitTail: ' with a CV and a short statement of interest.'
    },
    research: {
      kicker: 'Research',
      title: 'Selected work',
      subtitle: 'Cheminformatics · Predictive toxicology · Clinical metabolomics',
      lede: 'Five representative papers. Each entry links to the publisher record; the full list lives under Publications.',
      listLabel: 'Papers',
      link: 'Publisher'
    },
    tools: {
      kicker: 'Tools',
      title: 'Public services',
      subtitle: 'Eight services under *.cmdm.tw',
      lede: 'Every tool below is open to external researchers. Web services need no account; the R package is installed from source.',
      listLabel: 'Catalogue',
      link: 'Open',
      accessLabel: 'Access',
      access: [{
        label: 'Authentication',
        value: 'None required for web services'
      }, {
        label: 'Citation',
        value: 'Cite the tool’s original publication'
      }, {
        label: 'Support',
        value: 'yjtseng[at]csie.ntu.edu.tw'
      }, {
        label: 'Status',
        value: 'Hosted on lab infrastructure at NTU'
      }]
    },
    people: {
      kicker: 'People',
      title: 'Members',
      subtitle: '1 principal investigator · 2 postdocs · 4 PhD · 10 MSc · 40+ alumni',
      lede: 'The lab is hosted in the Department of Computer Science & Information Engineering at National Taiwan University, with joint appointments in GINM and BEBI.',
      piLabel: 'Principal investigator',
      piBio: 'Professor and Director. Ph.D. in Medicinal Chemistry and Pharmacognosy, University of Illinois at Chicago; BS, School of Pharmacy, National Taiwan University.',
      piFacts: [{
        label: 'Email',
        value: 'yjtseng[at]csie.ntu.edu.tw'
      }, {
        label: 'Telephone',
        value: '+886-2-33664888 ext. 529'
      }, {
        label: 'Office',
        value: 'R529, Dept. of CSIE, No. 1 Roosevelt Rd. Sec. 4, Taipei 106'
      }],
      postdocLabel: 'Postdoctoral researchers',
      phdLabel: 'Doctoral students',
      mscLabel: 'Master’s students',
      alumniLabel: 'Alumni',
      cols: {
        name: 'Name',
        contact: 'Contact',
        year: 'Year',
        degree: 'Degree',
        thesis: 'Thesis'
      }
    },
    publications: {
      kicker: 'Publications',
      title: 'Record',
      subtitle: 'Selected entries · full list on request',
      lede: 'Filter by title, venue, author or topic. The complete bibliography runs to roughly two hundred entries and is maintained separately.',
      filterLabel: 'Filter',
      filterHint: 'e.g. metabolomics, Tseng, 2017',
      clear: 'Clear',
      export: 'Export BibTeX',
      count: (n, t) => `${n} of ${t} entries`,
      empty: 'No entry matches that filter.',
      cols: {
        year: 'Year',
        title: 'Title',
        venue: 'Venue',
        authors: 'Authors',
        topic: 'Topic'
      }
    }
  },
  zh: {
    nav: ['總覽', '研究', '工具', '成員', '論文'],
    langToggle: 'English',
    status: '核心運作中',
    footerLabel: '版本資訊',
    brand: 'CMDM 實驗室',
    tagline: '計算分子設計與代謝體學',
    footer: ['10617 臺北市羅斯福路四段一號', '+886-2-33664888 #403 · 國立臺灣大學資訊工程學系 R529', '© 2006–2026 計算分子設計與代謝體學實驗室'],
    overview: {
      kicker: '臺大資工系 · 創立於 2006',
      title: '計算分子設計與代謝體學實驗室',
      subtitle: '曾宇鳳教授 · 國立臺灣大學資訊工程學系',
      lede: '我們開發演算法與工具，用於鑑定並設計具特定用途的分子結構，以及在臨床代謝體學世代研究中偵測生物標記。研究成果發表於國際期刊，並已實際應用於臺灣與美國的臨床生物標記開發。',
      pillarsLabel: '兩大研究主軸',
      pillars: [{
        index: 'I',
        title: '計算分子設計',
        body: '電腦輔助藥物設計與人工智慧藥物探索：以結構為基礎的片段跳躍先導最佳化、合成可行性評分，以及電腦模擬毒性預測。',
        meta: '6 項國家生技醫藥研究計畫 · 美國專利',
        link: '前往研究'
      }, {
        index: 'II',
        title: '代謝體學',
        body: '生物標記偵測與精準醫療：針對臨床世代的質譜與核磁共振計算方法，應用範圍從焊接煙塵暴露到加護病房死亡率預測。',
        meta: '臺大代謝體學核心實驗室',
        link: '前往研究'
      }],
      recordLabel: '實驗室紀錄',
      record: ['本實驗室參與國家生技醫藥研究計畫中六項新藥開發專案，並與中國醫藥大學、國立清華大學、臺北醫學大學等校化學系與藥學系合作。主要目標為開發神經病理性疼痛、血栓與癌症的治療藥物。', '在代謝體學方面，我們開發的質譜與核磁共振計算方法已發表於《Analytical Chemistry》，並應用於中草藥成分鑑定、乳癌細胞缺氧反應，以及肺癌與白血病的分子標記研究。'],
      facts: [{
        label: '主持人',
        value: '曾宇鳳 教授'
      }, {
        label: '所屬單位',
        value: '臺大資工系 · 基因體醫學所 · 生醫電資所'
      }, {
        label: '分析平台',
        value: 'LC-QTOF-MS · GCxGC/TOF-MS · 1D ¹H-NMR'
      }, {
        label: '公開工具',
        value: '*.cmdm.tw 下共 8 項服務'
      }, {
        label: '畢業校友',
        value: '2008 年起逾 40 人'
      }],
      recruitKicker: '招生中',
      recruitBody: '我們正在尋找具備化學資訊學、質譜分析或機器學習背景的研究生。請將履歷與簡短研究興趣說明寄至 ',
      recruitTail: '。'
    },
    research: {
      kicker: '研究',
      title: '代表性成果',
      subtitle: '化學資訊學 · 預測毒理學 · 臨床代謝體學',
      lede: '以下為五篇代表性論文，每則條目均連結至出版社頁面；完整清單請見「論文」頁。',
      listLabel: '論文',
      link: '出版社頁面'
    },
    tools: {
      kicker: '工具',
      title: '公開服務',
      subtitle: '*.cmdm.tw 下共 8 項服務',
      lede: '以下工具皆開放外部研究者使用。網頁服務無須註冊；R 套件請由原始碼安裝。',
      listLabel: '服務清單',
      link: '開啟',
      accessLabel: '使用方式',
      access: [{
        label: '身分驗證',
        value: '網頁服務無須帳號'
      }, {
        label: '引用方式',
        value: '請引用該工具的原始論文'
      }, {
        label: '技術支援',
        value: 'yjtseng[at]csie.ntu.edu.tw'
      }, {
        label: '主機狀態',
        value: '架設於臺大實驗室自有主機'
      }]
    },
    people: {
      kicker: '成員',
      title: '實驗室成員',
      subtitle: '主持人 1 位 · 博士後 2 位 · 博士生 4 位 · 碩士生 10 位 · 校友逾 40 位',
      lede: '本實驗室設於國立臺灣大學資訊工程學系，並於基因體醫學研究所與生醫電子與資訊學研究所合聘。',
      piLabel: '計畫主持人',
      piBio: '教授兼實驗室主持人。美國伊利諾大學芝加哥分校藥物化學與生藥學博士；國立臺灣大學醫學院藥學系學士。',
      piFacts: [{
        label: '電子郵件',
        value: 'yjtseng[at]csie.ntu.edu.tw'
      }, {
        label: '聯絡電話',
        value: '+886-2-33664888 轉 529'
      }, {
        label: '研究室',
        value: '臺北市羅斯福路四段一號 資工系 R529'
      }],
      postdocLabel: '博士後研究員',
      phdLabel: '博士班學生',
      mscLabel: '碩士班學生',
      alumniLabel: '歷屆校友',
      cols: {
        name: '姓名',
        contact: '聯絡方式',
        year: '年度',
        degree: '學位',
        thesis: '論文題目'
      }
    },
    publications: {
      kicker: '論文',
      title: '發表紀錄',
      subtitle: '節選條目 · 完整清單請來信索取',
      lede: '可依標題、期刊、作者或主題篩選。完整書目約兩百筆，另行維護。',
      filterLabel: '篩選',
      filterHint: '例如：代謝體學、Tseng、2017',
      clear: '清除',
      export: '匯出 BibTeX',
      count: (n, t) => `顯示 ${n} / ${t} 筆`,
      empty: '沒有符合篩選條件的條目。',
      cols: {
        year: '年度',
        title: '標題',
        venue: '發表處',
        authors: '作者',
        topic: '主題'
      }
    }
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/lab_site/messages.js", error: String((e && e.message) || e) }); }

__ds_ns.ArticleFlow = __ds_scope.ArticleFlow;

__ds_ns.ColophonTable = __ds_scope.ColophonTable;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.Ledger = __ds_scope.Ledger;

__ds_ns.LedgerItem = __ds_scope.LedgerItem;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Hairline = __ds_scope.Hairline;

__ds_ns.InkPanel = __ds_scope.InkPanel;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Kicker = __ds_scope.Kicker;

__ds_ns.PageShell = __ds_scope.PageShell;

__ds_ns.Prose = __ds_scope.Prose;

__ds_ns.PulseDot = __ds_scope.PulseDot;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.Masthead = __ds_scope.Masthead;

__ds_ns.SiteNav = __ds_scope.SiteNav;

})();
