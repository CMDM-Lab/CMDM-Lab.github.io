import React from 'react';
import { MobileNav, useNarrow } from './MobileNav.jsx';

function NavItem({ label, active, onSelect, href }) {
  const [hover, setHover] = React.useState(false);
  return (
    <a href={href || '#'} aria-current={active ? 'page' : undefined}
      onClick={(e) => { if (onSelect) { e.preventDefault(); onSelect(label); } }}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        fontSize: 'var(--font-size-body-lg)',
        color: active ? 'var(--accent-600)' : 'var(--text-secondary)',
        textDecoration: 'none',
        paddingBottom: 2,
        borderBottom: `1px solid ${active || hover ? 'var(--accent-600)' : 'transparent'}`,
      }}>{label}</a>
  );
}

/** Sticky site nav: two-line brand block left, hairline-underlined links right. */
export function SiteNav({ brand = 'CMDM Lab', tagline = 'Computational Molecular Design & Metabolomics', logoSrc, items = [], active, onSelect, right, cjk = false, menuLabel = 'Menu', collapse = true, style }) {
  const narrow = useNarrow();
  if (collapse && narrow) {
    return <MobileNav brand={brand} tagline={tagline} logoSrc={logoSrc} items={items} active={active} onSelect={onSelect} right={right} cjk={cjk} menuLabel={menuLabel} style={style} />;
  }
  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 10,
      background: 'color-mix(in srgb, var(--bg) 92%, transparent)',
      backdropFilter: 'blur(var(--nav-blur))',
      borderBottom: 'var(--border-ink)',
      padding: 'var(--nav-pad-y) var(--nav-pad-x)',
      display: 'flex', alignItems: 'center', gap: 'var(--space-6)',
      ...style,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', flex: 'none' }}>
        {logoSrc ? <img src={logoSrc} alt="" style={{ height: 30, width: 'auto', display: 'block' }} /> : null}
        <div>
          <div style={{ fontSize: 20, fontWeight: 'var(--weight-medium)', letterSpacing: 'var(--tracking-heading)', lineHeight: 1.1 }}>{brand}</div>
          <div style={{ fontFamily: cjk ? 'var(--font-sans)' : 'var(--font-mono)', fontSize: cjk ? 'var(--text-kicker-cjk)' : 'var(--text-kicker-sm)', textTransform: cjk ? 'none' : 'uppercase', letterSpacing: cjk ? 'var(--tracking-kicker-cjk)' : '0.18em', color: 'var(--neutral-600)', marginTop: 2 }}>{tagline}</div>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 'var(--space-4)', marginLeft: 'auto', alignItems: 'center', flexWrap: 'wrap' }}>
        {items.map((it) => <NavItem key={it.label || it} label={it.label || it} href={it.href} active={(it.label || it) === active} onSelect={onSelect} />)}
        {right}
      </div>
    </nav>
  );
}
