Journal masthead: kicker → ink rule → title → mono subtitle → justified lede. Opens every page.

```jsx
<Masthead hero kicker="NTU CSIE" title="Computational Molecular Design & Metabolomics Lab"
  subtitle="Est. 2006 · Prof. Yufeng Jane Tseng"
  lede="Our research group develops algorithms and tools to identify and design molecular structures for targeted use." />
```

`hero` switches the title to `clamp(30px, 3.4vw, 40px)` — use it once, on the landing page.