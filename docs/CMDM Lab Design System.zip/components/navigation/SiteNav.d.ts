/** Sticky, blurred site nav with an ink bottom rule. */
export interface SiteNavProps {
  /** 20px/500 wordmark line. */
  brand?: string;
  /** Mono uppercase second line under the brand. */
  tagline?: string;
  /** Optional logo lockup to the left of the brand block. */
  logoSrc?: string;
  items?: ({ label: string; href?: string } | string)[];
  active?: string;
  onSelect?: (label: string) => void;
  /** CJK mode: sans tagline at 12px / 0.08em tracking, no uppercasing. */
  cjk?: boolean;
  /** Slot at the far right — language toggle, status dot, action button.
   *  Below 768px it moves to the bottom of the mobile drawer. */
  right?: React.ReactNode;
  /** Accessible name for the mobile hamburger. Localise it. */
  menuLabel?: string;
  /** Set false to keep the desktop row below 768px (it will scroll). Default true. */
  collapse?: boolean;
  style?: React.CSSProperties;
}
export declare function SiteNav(props: SiteNavProps): JSX.Element;
