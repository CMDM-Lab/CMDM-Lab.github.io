/** True below the 768px mobile breakpoint. */
export declare function useNarrow(max?: number): boolean;

/** Compact sticky bar + full-height hairline drawer. Used below 768px. */
export interface MobileNavProps {
  /** 17px/500 wordmark. */
  brand?: string;
  /** Mono uppercase second line; truncates rather than wrapping. */
  tagline?: string;
  logoSrc?: string;
  items?: ({ label: string; href?: string } | string)[];
  active?: string;
  /** Fires after the drawer closes. */
  onSelect?: (label: string) => void;
  /** Pinned to the bottom of the open drawer — language toggle, status dot. */
  right?: React.ReactNode;
  cjk?: boolean;
  /** Accessible name for the hamburger and the drawer. Localise it. */
  menuLabel?: string;
  style?: React.CSSProperties;
}
export declare function MobileNav(props: MobileNavProps): JSX.Element;
