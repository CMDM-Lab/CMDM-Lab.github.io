# MobileNav

The under-768px form of `SiteNav`. You rarely mount it directly — `SiteNav` swaps
to it automatically. Mount it alone only when a page is mobile-only.

- Bar: logo 26px, brand 17px, mono tagline truncated with an ellipsis (never wrapped).
- Hamburger: 44×44, hairline border, morphs to an X. No icon library.
- Drawer: opens under the bar to `100dvh`, solid `--bg` (no scrim — the drawer
  *is* the page), 52px rows on row hairlines, two-digit mono ordinals in a 26px gutter.
- Active row is `--accent-600` text. No left accent bar, no fill, no radius.
- `right` sits at the bottom of the drawer above an ink rule.
- Body scroll locks while open; Escape closes.

Do not add a search field, nested sub-menus, or animation beyond the 120ms glyph
morph. One level, one column.
