Sticky page nav. Blurred near-white background, ink bottom rule, two-line brand block on the left.

```jsx
<SiteNav logoSrc="assets/logo.png" brand="CMDM Lab"
  tagline="Computational Molecular Design & Metabolomics"
  items={['Research','Tools','People','Publications']}
  active="Research" onSelect={setPage}
  right={<Button variant="ghost">中文</Button>} />
```

Links carry a transparent 1px bottom border that turns accent on hover; the active item is accent-coloured and sets `aria-current="page"`.
## Mobile

Below 768px `SiteNav` renders `MobileNav` itself — bar + hamburger + full-height
drawer; the `right` slot moves to the drawer's bottom. Pass `menuLabel` from your
messages file so the hamburger is localised. `collapse={false}` opts out.
