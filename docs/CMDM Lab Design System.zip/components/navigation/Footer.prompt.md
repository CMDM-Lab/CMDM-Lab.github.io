Colophon footer. Ink top rule, a kicker label, then mono meta lines. No link columns, no social row.

```jsx
<Footer lines={[
  'No. 1 Roosevelt Rd. Sec. 4, Taipei 106, Taiwan',
  '+886-2-33664888 #403',
  '© 2006–2026 CMDM Laboratory',
]} />

<Footer cjk label="版本資訊" lines={[…]} />
```

`label` defaults to `Colophon` — always localise it, and pass `cjk` on Chinese pages so the label follows the CJK kicker rules (12px sans, 0.08em, no uppercasing).
