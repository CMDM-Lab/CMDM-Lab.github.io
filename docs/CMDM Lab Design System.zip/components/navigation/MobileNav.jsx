import React from 'react';

/** True below the 768px mobile breakpoint. SSR-safe, listener-based. */
export function useNarrow(max = 767) {
  const q = `(max-width:${max}px)`;
  const [narrow, setNarrow] = React.useState(() => typeof window !== 'undefined' && window.matchMedia(q).matches);
  React.useEffect(() => {
    const m = window.matchMedia(q);
    const on = (e) => setNarrow(e.matches);
    setNarrow(m.matches);
    m.addEventListener('change', on);
    return () => m.removeEventListener('change', on);
  }, [q]);
  return narrow;
}

function Glyph({ open }) {
  const bar = { height: 1, background: 'var(--text)', width: 18, display: 'block', transition: 'transform 120ms linear, opacity 120ms linear' };
  return (
    <span style={{ display: 'grid', gap: 5, placeItems: 'center' }} aria-hidden="true">
      <span style={{ ...bar, transform: open ? 'translateY(6px) rotate(45deg)' : 'none' }} />
      <span style={{ ...bar, opacity: open ? 0 : 1 }} />
      <span style={{ ...bar, transform: open ? 'translateY(-6px) rotate(-45deg)' : 'none' }} />
    </span>
  );
}

function DrawerRow({ label, index, active, onSelect, href, cjk }) {
  const [down, setDown] = React.useState(false);
  return (
    <a href={href || '#'} aria-current={active ? 'page' : undefined}
      onClick={(e) => { if (onSelect) { e.preventDefault(); onSelect(label); } }}
      onTouchStart={() => setDown(true)} onTouchEnd={() => setDown(false)}
      onMouseDown={() => setDown(true)} onMouseUp={() => setDown(false)} onMouseLeave={() => setDown(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
        minHeight: 'var(--drawer-row-h)', padding: '0 var(--page-pad-x)',
        borderBottom: 'var(--border-row)', textDecoration: 'none',
        background: down ? 'var(--neutral-100)' : 'transparent',
        color: active ? 'var(--accent-600)' : 'var(--text)',
        fontSize: cjk ? 'var(--font-size-body-lg)' : 'var(--text-lede)',
        WebkitTapHighlightColor: 'transparent',
      }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-kicker-sm)', letterSpacing: '0.14em', color: active ? 'var(--accent-600)' : 'var(--neutral-600)', width: 'var(--drawer-index-w)', flex: 'none' }}>
        {String(index + 1).padStart(2, '0')}
      </span>
      <span>{label}</span>
    </a>
  );
}

/**
 * Mobile site nav: compact sticky bar plus a full-height hairline drawer.
 * Same information as SiteNav, one column, 44px minimum targets.
 */
export function MobileNav({ brand = 'CMDM Lab', tagline, logoSrc, items = [], active, onSelect, right, cjk = false, menuLabel = 'Menu', style }) {
  const [open, setOpen] = React.useState(false);
  React.useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const esc = (e) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', esc);
    return () => { document.body.style.overflow = prev; window.removeEventListener('keydown', esc); };
  }, [open]);

  const pick = (label) => { setOpen(false); if (onSelect) onSelect(label); };

  return (
    <nav style={{ position: 'sticky', top: 0, zIndex: 20, ...style }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
        padding: 'var(--nav-pad-y) var(--nav-pad-x)',
        background: 'color-mix(in srgb, var(--bg) 92%, transparent)',
        backdropFilter: 'blur(var(--nav-blur))',
        borderBottom: 'var(--border-ink)',
      }}>
        {logoSrc ? <img src={logoSrc} alt="" style={{ height: 26, width: 'auto', display: 'block' }} /> : null}
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 17, fontWeight: 'var(--weight-medium)', letterSpacing: 'var(--tracking-heading)', lineHeight: 1.1 }}>{brand}</div>
          {tagline ? <div style={{
            fontFamily: cjk ? 'var(--font-sans)' : 'var(--font-mono)',
            fontSize: cjk ? 'var(--text-kicker-cjk)' : 'var(--text-kicker-sm)',
            textTransform: cjk ? 'none' : 'uppercase',
            letterSpacing: cjk ? 'var(--tracking-kicker-cjk)' : '0.14em',
            color: 'var(--neutral-600)', marginTop: 2,
            whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
          }}>{tagline}</div> : null}
        </div>
        <button type="button" aria-expanded={open} aria-label={menuLabel} onClick={() => setOpen((v) => !v)}
          style={{
            marginLeft: 'auto', flex: 'none',
            width: 'var(--tap-min)', height: 'var(--tap-min)',
            display: 'grid', placeItems: 'center',
            background: open ? 'var(--neutral-100)' : 'transparent',
            border: 'var(--border-hairline)', borderRadius: 0, cursor: 'pointer',
          }}>
          <Glyph open={open} />
        </button>
      </div>

      {open ? (
        <div role="dialog" aria-label={menuLabel} style={{
          position: 'absolute', left: 0, right: 0, top: '100%',
          height: 'calc(100dvh - 100%)', overflowY: 'auto',
          background: 'var(--bg)', borderBottom: 'var(--border-ink)',
          display: 'flex', flexDirection: 'column',
        }}>
          {items.map((it, i) => (
            <DrawerRow key={it.label || it} label={it.label || it} href={it.href} index={i} cjk={cjk}
              active={(it.label || it) === active} onSelect={pick} />
          ))}
          {right ? (
            <div style={{ marginTop: 'auto', padding: 'var(--space-4) var(--page-pad-x)', borderTop: 'var(--border-ink)', display: 'flex', alignItems: 'center', gap: 'var(--space-4)', flexWrap: 'wrap' }}>{right}</div>
          ) : null}
        </div>
      ) : null}
    </nav>
  );
}
