import React from 'react';
import { Kicker } from '../core/Kicker.jsx';

/** Colophon-style footer: ink rule, mono meta lines, no columns of links. */
export function Footer({ lines = [], label = 'Colophon', note, cjk = false, style }) {
  return (
    <footer style={{ borderTop: 'var(--border-ink)', padding: 'var(--space-6) var(--nav-pad-x)', ...style }}>
      <Kicker size="sm" tone="neutral" cjk={cjk}>{label}</Kicker>
      <div style={{ marginTop: 'var(--space-3)', display: 'flex', flexDirection: 'column', gap: 'var(--space-1)' }}>
        {lines.map((l, i) => (
          <div key={i} style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-small)', color: 'var(--text-meta)', fontVariantNumeric: 'tabular-nums' }}>{l}</div>
        ))}
      </div>
      {note ? <p style={{ marginTop: 'var(--space-3)', fontSize: 'var(--text-small)', color: 'var(--text-faint)' }}>{note}</p> : null}
    </footer>
  );
}
