import React from 'react';
import { Kicker } from '../core/Kicker.jsx';
import { Hairline } from '../core/Hairline.jsx';

/** Journal-style page masthead: kicker → ink rule → title → subtitle → lede. */
export function Masthead({ kicker, title, subtitle, lede, hero = false, cjk = false, style }) {
  return (
    <header style={style}>
      {kicker ? <Kicker size="md" cjk={cjk}>{kicker}</Kicker> : null}
      <Hairline tone="ink" style={{ margin: 'var(--space-2) 0 var(--space-4)' }} />
      <h1 style={{ fontSize: hero ? 'var(--text-h1-hero)' : 'var(--text-h1)', lineHeight: cjk ? 1.3 : 1.1 }}>{title}</h1>
      {subtitle ? (
        <div style={{
          fontFamily: cjk ? 'var(--font-sans)' : 'var(--font-mono)',
          fontSize: cjk ? 'var(--text-kicker-cjk)' : 'var(--text-kicker)',
          textTransform: cjk ? 'none' : 'uppercase',
          letterSpacing: cjk ? 'var(--tracking-kicker-cjk)' : 'var(--tracking-kicker)',
          color: 'var(--neutral-600)', marginTop: 'var(--space-2)',
        }}>{subtitle}</div>
      ) : null}
      {lede ? (
        <p style={{
          marginTop: 'var(--space-4)',
          maxWidth: cjk ? 'var(--measure-prose-cjk)' : 'var(--measure-prose)',
          fontSize: 'var(--text-lede)',
          lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
          textAlign: cjk ? 'left' : 'justify',
          hyphens: cjk ? undefined : 'auto',
          color: 'var(--text-secondary)',
        }}>{lede}</p>
      ) : null}
    </header>
  );
}
