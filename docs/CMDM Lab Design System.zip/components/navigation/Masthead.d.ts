/** Journal-style page masthead. */
export interface MastheadProps {
  /** Mono uppercase accent label above the ink rule. */
  kicker?: React.ReactNode;
  title: React.ReactNode;
  /** Mono uppercase line under the title. */
  subtitle?: React.ReactNode;
  /** Opening paragraph — justified in Latin, ragged-right in CJK. */
  lede?: React.ReactNode;
  /** Use the clamp(30px,3.4vw,40px) hero size. */
  hero?: boolean;
  /** CJK mode: sans subtitle, 1.3 title leading, 1.8 lede leading, no justification. */
  cjk?: boolean;
  style?: React.CSSProperties;
}
export declare function Masthead(props: MastheadProps): JSX.Element;
