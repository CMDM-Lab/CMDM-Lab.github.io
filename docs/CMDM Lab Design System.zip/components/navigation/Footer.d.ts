/** Colophon footer — mono meta lines under an ink rule. */
export interface FooterProps {
  /** Address, phone, copyright — one string per line, set in mono. */
  lines?: React.ReactNode[];
  /** Kicker label above the lines. Default "Colophon" — localise it. */
  label?: React.ReactNode;
  /** Optional closing sentence in sans. */
  note?: React.ReactNode;
  /** CJK mode: 12px sans label at 0.08em tracking, no uppercasing. */
  cjk?: boolean;
  style?: React.CSSProperties;
}
export declare function Footer(props: FooterProps): JSX.Element;
