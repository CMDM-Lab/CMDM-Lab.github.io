Unfilled auto-fit list container — the replacement for cards. Columns are decided by container width, so no breakpoints are needed.

```jsx
<Ledger>
  <LedgerItem index="I" title="Computer-aided drug design" body="…" />
  <LedgerItem index="II" title="Biomarker detection" body="…" />
</Ledger>
<Ledger min="var(--grid-min-wide)">…</Ledger>
```

The container draws the top hairline; each item draws its own bottom hairline. Nothing is filled.