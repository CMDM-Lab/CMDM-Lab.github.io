import React from 'react';
import { useNarrow } from '../navigation/MobileNav.jsx';

/** Below 768px a table becomes one stacked record per row: mono label, then value. */
function StackedRecords({ columns, rows }) {
  return (
    <div style={{ borderTop: 'var(--border-ink)' }}>
      {rows.map((r, i) => (
        <div key={i} style={{ padding: 'var(--space-3) 0', borderBottom: 'var(--border-row)', display: 'grid', gap: 'var(--space-1)' }}>
          {columns.map((c) => (
            <div key={c.key || c.label} style={{ display: 'grid', gridTemplateColumns: 'minmax(88px,32%) 1fr', gap: 'var(--space-2)', alignItems: 'baseline' }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-kicker-sm)', letterSpacing: 'var(--tracking-table-head)', textTransform: 'uppercase', color: 'var(--neutral-600)' }}>{c.label}</span>
              <span style={{ fontSize: 'var(--text-table)', fontVariantNumeric: 'tabular-nums', color: 'var(--text-secondary)' }}>{r[c.key]}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

/** Data table: mono uppercase heads over an ink rule, row hairlines, tabular nums. */
export function DataTable({ columns = [], rows = [], stackOnMobile = true, style }) {
  const narrow = useNarrow();
  if (stackOnMobile && narrow) return <StackedRecords columns={columns} rows={rows} />;
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 'var(--text-lede)', fontVariantNumeric: 'tabular-nums', ...style }}>
      <thead>
        <tr>
          {columns.map((c) => (
            <th key={c.key || c.label} style={{
              fontFamily: 'var(--font-mono)', fontSize: 'var(--text-kicker-sm)',
              letterSpacing: 'var(--tracking-table-head)', textTransform: 'uppercase',
              textAlign: c.align || 'left', padding: 'var(--space-2)',
              borderBottom: 'var(--border-ink)', color: 'var(--text)', width: c.width,
              fontWeight: 'var(--weight-medium)',
            }}>{c.label}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => <Row key={i} row={r} columns={columns} />)}
      </tbody>
    </table>
  );
}

function Row({ row, columns }) {
  const [hover, setHover] = React.useState(false);
  return (
    <tr onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ background: hover ? 'var(--neutral-100)' : 'transparent' }}>
      {columns.map((c) => (
        <td key={c.key || c.label} style={{ fontSize: 'var(--text-table)', padding: 'var(--space-2)', borderBottom: 'var(--border-row)', textAlign: c.align || 'left', verticalAlign: 'top', color: 'var(--text-secondary)' }}>
          {row[c.key]}
        </td>
      ))}
    </tr>
  );
}
