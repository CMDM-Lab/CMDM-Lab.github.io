import React from 'react';

/** Data table: mono uppercase heads over an ink rule, row hairlines, tabular nums. */
export function DataTable({ columns = [], rows = [], style }) {
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 'var(--text-lede)', fontVariantNumeric: 'tabular-nums', ...style }}>
      <thead>
        <tr>
          {columns.map((c) => (
            <th key={c.key || c.label} style={{
              fontFamily: 'var(--font-mono)', fontSize: 'var(--text-kicker-sm)',
              letterSpacing: 'var(--tracking-table-head)', textTransform: 'uppercase',
              textAlign: c.align || 'left', padding: 'var(--space-2)',
              borderBottom: 'var(--border-ink)', color: 'var(--text)', width: c.width,
              fontWeight: 'var(--weight-medium)',
            }}>{c.label}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => <Row key={i} row={r} columns={columns} />)}
      </tbody>
    </table>
  );
}

function Row({ row, columns }) {
  const [hover, setHover] = React.useState(false);
  return (
    <tr onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} style={{ background: hover ? 'var(--neutral-100)' : 'transparent' }}>
      {columns.map((c) => (
        <td key={c.key || c.label} style={{ fontSize: 'var(--text-table)', padding: 'var(--space-2)', borderBottom: 'var(--border-row)', textAlign: c.align || 'left', verticalAlign: 'top', color: 'var(--text-secondary)' }}>
          {row[c.key]}
        </td>
      ))}
    </tr>
  );
}
