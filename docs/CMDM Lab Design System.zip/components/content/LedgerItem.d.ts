/** One entry in a Ledger — research direction, tool, member, publication. */
export interface LedgerItemProps {
  /** Mono accent index: a roman numeral, a year, or a short code. */
  index?: React.ReactNode;
  title: React.ReactNode;
  body?: React.ReactNode;
  /** Mono meta line: authors, journal, dates, identifiers. */
  meta?: React.ReactNode;
  href?: string;
  /** Text before the → arrow. Default "Read". */
  linkLabel?: string;
  /** Array of <Tag> elements. */
  tags?: React.ReactNode[];
  /** Hairline-framed figure or screenshot. */
  imageSrc?: string;
  /** Justify the body. Ignored when `cjk` is set. */
  justify?: boolean;
  /** CJK mode: 14px / 1.8 body, looser title leading, never justified. */
  cjk?: boolean;
  style?: React.CSSProperties;
}
export declare function LedgerItem(props: LedgerItemProps): JSX.Element;
