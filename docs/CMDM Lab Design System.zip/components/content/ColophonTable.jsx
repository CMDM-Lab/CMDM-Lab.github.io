import React from 'react';

/** Two-column label/value colophon table — tech stack, equipment, resources. */
export function ColophonTable({ entries = [], style }) {
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontVariantNumeric: 'tabular-nums', ...style }}>
      <tbody>
        {entries.map((e) => (
          <tr key={e.label}>
            <th style={{
              width: '34%', verticalAlign: 'top', textAlign: 'left',
              fontFamily: 'var(--font-mono)', fontSize: 'var(--text-kicker-sm)',
              letterSpacing: 'var(--tracking-table-head)', textTransform: 'uppercase',
              padding: 'var(--space-2)', borderBottom: 'var(--border-row)',
              color: 'var(--neutral-600)', fontWeight: 'var(--weight-medium)',
            }}>{e.label}</th>
            <td style={{ fontSize: 'var(--text-table)', padding: 'var(--space-2)', borderBottom: 'var(--border-row)', color: 'var(--text-secondary)', verticalAlign: 'top' }}>{e.value}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
