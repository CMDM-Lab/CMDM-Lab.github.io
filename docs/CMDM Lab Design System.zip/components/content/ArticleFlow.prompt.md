Two-column justified flow for long prose — reads like a journal page, unlike side-by-side flex columns.

```jsx
<ArticleFlow>
  <p>Our research focuses on…</p>
  <p>In metabolomics, we have built…</p>
</ArticleFlow>
```

Uses CSS `columns` with a hairline column rule. Keep it for English prose at 14px; long CJK paragraphs are better left in a single `Prose` column.