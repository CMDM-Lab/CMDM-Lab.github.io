import React from 'react';

/** Journal two-column article flow with a hairline column rule. */
export function ArticleFlow({ columns = 2, children, style }) {
  return (
    <div style={{
      columns,
      columnGap: 'var(--column-gap)',
      columnRule: 'var(--border-hairline)',
      fontSize: 'var(--text-lede)',
      lineHeight: 'var(--leading-body)',
      textAlign: 'justify',
      hyphens: 'auto',
      color: 'var(--text-secondary)',
      ...style,
    }}>{children}</div>
  );
}
