/** Multi-column justified article flow — reads more like a journal than flex columns. */
export interface ArticleFlowProps {
  /** Column count. Default 2. */
  columns?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function ArticleFlow(props: ArticleFlowProps): JSX.Element;
