/** Two-column label/value table for specs, stacks, equipment lists. */
export interface ColophonTableProps {
  entries?: { label: React.ReactNode; value: React.ReactNode }[];
  style?: React.CSSProperties;
}
export declare function ColophonTable(props: ColophonTableProps): JSX.Element;
