/** Instrument-style data table. */
export interface DataTableProps {
  columns?: { key: string; label: React.ReactNode; align?: 'left' | 'right' | 'center'; width?: string }[];
  /** One object per row, keyed by column `key`. */
  rows?: Record<string, React.ReactNode>[];
  /** Below 768px, become one stacked label/value record per row. Default true. */
  stackOnMobile?: boolean;
  style?: React.CSSProperties;
}
export declare function DataTable(props: DataTableProps): JSX.Element;
