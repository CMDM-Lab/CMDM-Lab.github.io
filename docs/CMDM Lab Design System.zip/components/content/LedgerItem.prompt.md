One ledger entry — a research direction, a tool, a person, a paper.

```jsx
<LedgerItem index="III" title="Virtual Rat"
  body="Predictions of ADMET properties plus the structural reasoning behind each call."
  meta="virtualrat.cmdm.tw · web service"
  tags={[<Tag tone="brand" key="a">ADMET</Tag>]}
  href="https://virtualrat.cmdm.tw/" linkLabel="Open" />
```

Links always end in `→`. The index is mono accent; the title is h4; body is 13.5px secondary ink; meta is mono with tabular numerals.