Label/value spec table. The `th` column is fixed at 34% and set in mono uppercase.

```jsx
<ColophonTable entries={[
  { label: 'Instrument', value: 'Bruker Avance III 600 MHz' },
  { label: 'Platform', value: 'LC-QTOF-MS, GCxGC/TOF-MS' },
]} />
```

Right for equipment, tech stacks, dataset provenance, and method parameters.