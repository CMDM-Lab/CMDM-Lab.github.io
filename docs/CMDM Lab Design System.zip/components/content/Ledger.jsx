import React from 'react';

/** Unfilled auto-fit list container. No card fills — hairlines only. */
export function Ledger({ min, children, style, ...rest }) {
  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: `repeat(auto-fit, minmax(${min || 'var(--grid-min-ledger)'}, 1fr))`,
      borderTop: 'var(--border-hairline)',
      ...style,
    }} {...rest}>{children}</div>
  );
}
