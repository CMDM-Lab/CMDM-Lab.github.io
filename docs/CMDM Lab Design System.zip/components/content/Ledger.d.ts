/** Auto-fit ledger grid. Items reflow by container width, no media queries. */
export interface LedgerProps {
  /** Minimum column width. Default var(--grid-min-ledger) = 260px. */
  min?: string;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Ledger(props: LedgerProps): JSX.Element;
