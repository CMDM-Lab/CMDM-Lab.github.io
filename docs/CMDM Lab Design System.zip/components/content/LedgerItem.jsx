import React from 'react';
import { Kicker } from '../core/Kicker.jsx';

/** One row of a Ledger: mono index, title, body, meta line, → link. */
export function LedgerItem({ index, title, body, meta, href, linkLabel = 'Read', tags, imageSrc, justify = false, cjk = false, style }) {
  const [hover, setHover] = React.useState(false);
  return (
    <article style={{
      borderBottom: 'var(--border-hairline)',
      padding: 'var(--space-4) var(--space-6) var(--space-4) 0',
      display: 'flex', flexDirection: 'column', gap: 'var(--space-2)',
      ...style,
    }}>
      {index ? <Kicker>{index}</Kicker> : null}
      <h4 style={{ fontSize: 'var(--text-h4)', lineHeight: cjk ? 1.5 : 1.3 }}>{title}</h4>
      {imageSrc ? <img src={imageSrc} alt="" style={{ display: 'block', width: '100%', height: 'auto', border: 'var(--border-hairline)', marginTop: 'var(--space-1)' }} /> : null}
      {body ? (
        <p style={{
          fontSize: cjk ? 'var(--text-lede)' : 'var(--font-size-body-lg)',
          lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
          color: 'var(--text-secondary)',
          textAlign: justify && !cjk ? 'justify' : 'left',
          hyphens: justify && !cjk ? 'auto' : undefined,
        }}>{body}</p>
      ) : null}
      {tags && tags.length ? <div style={{ display: 'flex', gap: 'var(--space-1)', flexWrap: 'wrap' }}>{tags}</div> : null}
      {meta ? (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-kicker)', color: 'var(--text-meta)', fontVariantNumeric: 'tabular-nums' }}>{meta}</div>
      ) : null}
      {href ? (
        <a href={href} target="_blank" rel="noreferrer"
          onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
          style={{ fontSize: 'var(--text-small)', color: hover ? 'var(--accent-800)' : 'var(--accent-600)', marginTop: 'auto', paddingTop: 'var(--space-2)' }}>{linkLabel} →</a>
      ) : null}
    </article>
  );
}
