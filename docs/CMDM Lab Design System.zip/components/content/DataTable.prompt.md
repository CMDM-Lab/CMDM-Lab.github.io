Instrument-style table. Mono uppercase 9.5px heads over an ink rule, 12.5px rows separated by neutral-200 hairlines, tabular numerals throughout.

```jsx
<DataTable
  columns={[{key:'name',label:'Name'},{key:'degree',label:'Degree'},{key:'year',label:'Year',align:'right'}]}
  rows={[{name:'Pei-Hwa Wang',degree:'PhD, BEBI',year:'2022'}]} />
```

Rows tint to neutral-100 on hover. That is the whole interaction.
## Mobile

Below 768px the table stops being a table: each row becomes a stacked record —
mono uppercase label in a ~32% column, value beside it, row hairline between
records. Never horizontally scroll a five-column table on a phone. Pass
`stackOnMobile={false}` only for a genuinely narrow (2-column, numeric) table.
