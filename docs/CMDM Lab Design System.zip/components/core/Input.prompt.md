Zero-radius field. Border darkens on hover, turns accent on focus; the caret is accent too.

```jsx
<Input label="Compound name" placeholder="e.g. Trowaglerix" />
<Input as="textarea" label="Notes" hint="Markdown accepted" />
```

Field text is 13px — the same size as body copy and never larger than its own label. Labels are 12px neutral-700; hints are mono 11px.