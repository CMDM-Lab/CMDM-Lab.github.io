/** Zero-radius field, optionally wrapped in the system's label/hint stack. */
export interface InputProps {
  /** `input`, `textarea` or `select`. */
  as?: 'input' | 'textarea' | 'select';
  /** 12px neutral-700 label above the field. */
  label?: React.ReactNode;
  /** Mono 11px note below the field. */
  hint?: React.ReactNode;
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  style?: React.CSSProperties;
}
export declare function Input(props: InputProps): JSX.Element;
