/** 2px ink-framed emphasis block on white. At most one per page. */
export interface InkPanelProps {
  /** Mono 11px uppercase accent label on the first line. */
  kicker?: React.ReactNode;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function InkPanel(props: InkPanelProps): JSX.Element;
