/** Square mono uppercase tag. */
export interface TagProps {
  /** accent = signal (must-fix, positive), neutral = default, outline = quiet, brand = lab-blue classification. */
  tone?: 'accent' | 'neutral' | 'outline' | 'brand';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Tag(props: TagProps): JSX.Element;
