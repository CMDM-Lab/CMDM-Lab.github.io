/** 1px rule. There are no shadows in this system — Hairline is the only elevation. */
export interface HairlineProps {
  /** divider = #d8dad6, ink = #16181a section closer, row = table row hairline. */
  tone?: 'divider' | 'ink' | 'row';
  style?: React.CSSProperties;
}
export declare function Hairline(props: HairlineProps): JSX.Element;
