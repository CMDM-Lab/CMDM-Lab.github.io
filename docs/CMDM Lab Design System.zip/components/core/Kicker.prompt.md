Mono uppercase micro-label. The only place type is allowed below 12px, and only because it is uppercase monospace.

```jsx
<Kicker>I</Kicker>
<Kicker size="md">Metabolomics core</Kicker>
<Kicker tone="faint">Draft</Kicker>
<Kicker cjk>代謝體學核心設施</Kicker>
```

Use it for section numbers, roman numerals, eyebrow labels above headings, and table-adjacent classifications. Never for sentences.

**CJK:** pass `cjk`. Chinese has no case, so uppercasing does nothing and 0.14em tracking pulls glyphs apart; CJK mode switches to sans at 12px with 0.08em tracking. Never set a Chinese kicker below 12px.
