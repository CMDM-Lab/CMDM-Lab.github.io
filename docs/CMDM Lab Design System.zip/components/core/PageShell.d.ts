/** Centred page container. */
export interface PageShellProps {
  /** default = 960px, wide = 1180px. */
  width?: 'default' | 'wide';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function PageShell(props: PageShellProps): JSX.Element;

/** Prose column. */
export interface ProseProps {
  /** Justify + hyphenate. Ignored when `cjk` is set. */
  justify?: boolean;
  size?: 'body' | 'lede';
  /** CJK mode: 14px / 1.8 leading, 38em measure, ragged right — never justified. */
  cjk?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Prose(props: ProseProps): JSX.Element;
