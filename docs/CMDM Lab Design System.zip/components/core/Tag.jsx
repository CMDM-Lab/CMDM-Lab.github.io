import React from 'react';

const TONE = {
  accent: { background: 'var(--accent-100)', color: 'var(--accent-800)', border: '1px solid transparent' },
  neutral: { background: 'var(--neutral-200)', color: 'var(--neutral-700)', border: '1px solid transparent' },
  outline: { background: 'transparent', color: 'var(--accent-600)', border: '1px solid var(--accent-600)' },
  brand: { background: 'var(--brand-200)', color: 'var(--brand-800)', border: '1px solid transparent' },
};

/** Mono uppercase tag. Square, tiny, never a pill. */
export function Tag({ tone = 'neutral', children, style, ...rest }) {
  return (
    <span style={{
      display: 'inline-block',
      borderRadius: 0,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-kicker-sm)',
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      padding: '2px 6px',
      ...TONE[tone] || TONE.neutral,
      ...style,
    }} {...rest}>{children}</span>
  );
}
