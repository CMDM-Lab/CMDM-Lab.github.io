Square mono uppercase tag. Never a pill, never rounded.

```jsx
<Tag tone="accent">Must fix</Tag>
<Tag tone="neutral">R package</Tag>
<Tag tone="outline">Preprint</Tag>
<Tag tone="brand">LC-MS</Tag>
```

`accent` counts against the signal-colour budget — reserve it for must-fix / flagged states. `brand` uses the lab blue and is the right choice for instrument or assay classifications.