import React from 'react';

/** Mono uppercase micro-label. The system's only decorative type device. */
export function Kicker({ size = 'sm', tone = 'accent', cjk = false, as = 'span', children, style, ...rest }) {
  const Tag = as;
  const color = tone === 'faint' ? 'var(--text-faint)' : tone === 'neutral' ? 'var(--neutral-600)' : 'var(--accent-700)';
  return (
    <Tag style={{
      fontFamily: cjk ? 'var(--font-sans)' : 'var(--font-mono)',
      fontSize: cjk ? 'var(--text-kicker-cjk)' : size === 'md' ? 'var(--text-kicker)' : 'var(--text-kicker-sm)',
      letterSpacing: cjk ? 'var(--tracking-kicker-cjk)' : 'var(--tracking-kicker)',
      textTransform: cjk ? 'none' : 'uppercase',
      fontWeight: 'var(--weight-medium)',
      color,
      ...style,
    }} {...rest}>{children}</Tag>
  );
}
