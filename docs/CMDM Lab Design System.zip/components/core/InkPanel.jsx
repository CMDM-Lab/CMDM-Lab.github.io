import React from 'react';
import { Kicker } from './Kicker.jsx';

/** The loudest element on a page: 2px ink frame on white. Use at most once. */
export function InkPanel({ kicker, children, style, ...rest }) {
  return (
    <div style={{ border: 'var(--border-plate)', background: 'var(--white)', padding: 'var(--space-6)', ...style }} {...rest}>
      {kicker ? <div style={{ marginBottom: 'var(--space-3)' }}><Kicker size="md">{kicker}</Kicker></div> : null}
      {children}
    </div>
  );
}
