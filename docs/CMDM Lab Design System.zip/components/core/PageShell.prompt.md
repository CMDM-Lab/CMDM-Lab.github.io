Page container and prose column.

```jsx
<PageShell>
  <Masthead kicker="Research" title="Computational Molecular Design" />
  <Prose><p>…</p><p>…</p></Prose>
</PageShell>
```

`PageShell` is 960px by default, 1180px with `width="wide"`. `Prose` caps at 64ch and justifies with hyphenation — pass `justify={false}` in narrow columns and for CJK, where justification breaks tokens like `|log₂FC| > 1` apart.