/** Flat, zero-radius button. */
export interface ButtonProps {
  /** primary = accent fill (the signal colour), secondary = surface fill, ghost = text only. */
  variant?: 'primary' | 'secondary' | 'ghost';
  /** Full-width, with the source system's space-2 top margin. */
  block?: boolean;
  disabled?: boolean;
  /** Renders an `<a>`; the button styling is identical. */
  href?: string;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
