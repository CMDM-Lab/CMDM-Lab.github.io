The system's only elevation device. There are no shadows anywhere — every layer boundary is a 1px rule.

```jsx
<Hairline />                 {/* #d8dad6 divider */}
<Hairline tone="ink" />      {/* #16181a — closes a section */}
```

Ink rules mark real boundaries (nav underline, section closer, table head). Divider rules separate peers. Don't stack them.