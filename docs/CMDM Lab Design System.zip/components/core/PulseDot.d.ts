/** Pulsing live-status dot — the system's only animation. */
export interface PulseDotProps {
  /** Mono uppercase label to the right of the dot. */
  label?: React.ReactNode;
  /** Diameter in px. Default 7. */
  size?: number;
  tone?: 'accent' | 'brand';
  style?: React.CSSProperties;
}
export declare function PulseDot(props: PulseDotProps): JSX.Element;
