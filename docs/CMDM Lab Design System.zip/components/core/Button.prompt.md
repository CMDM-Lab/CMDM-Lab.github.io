Flat, zero-radius button. Three variants and no more.

```jsx
<Button variant="primary">Run analysis</Button>
<Button variant="secondary">Cancel</Button>
<Button variant="ghost">View details</Button>
<Button variant="primary" block>Submit</Button>
```

`primary` is one of the six sanctioned uses of the accent colour — don't reach for it twice in the same view. Icons go inside as SVG (`.btn svg{display:block}`); no radius, no shadow, hover and active only change the fill.