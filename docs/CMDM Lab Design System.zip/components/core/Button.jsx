import React from 'react';

const VARIANT = {
  primary: { background: 'var(--accent-600)', color: 'var(--white)', borderColor: 'var(--accent-600)' },
  secondary: { background: 'var(--surface)', color: 'var(--text)', borderColor: 'var(--divider)' },
  ghost: { background: 'transparent', color: 'var(--accent-600)', borderColor: 'transparent' },
};
const HOVER = {
  primary: { background: 'var(--accent-700)' },
  secondary: { background: 'color-mix(in srgb, var(--text) 7%, transparent)' },
  ghost: { background: 'color-mix(in srgb, var(--accent) 10%, transparent)' },
};
const ACTIVE = {
  primary: { background: 'var(--accent-800)' },
  secondary: { background: 'color-mix(in srgb, var(--text) 14%, transparent)' },
  ghost: { background: 'color-mix(in srgb, var(--accent) 18%, transparent)' },
};

/** Flat, zero-radius button. Three variants only: primary / secondary / ghost. */
export function Button({ variant = 'secondary', block = false, disabled = false, href, children, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const [down, setDown] = React.useState(false);
  const v = VARIANT[variant] || VARIANT.secondary;
  const state = disabled ? null : down ? ACTIVE[variant] : hover ? HOVER[variant] : null;
  const css = {
    display: block ? 'flex' : 'inline-flex',
    width: block ? '100%' : undefined,
    marginTop: block ? 'var(--space-2)' : undefined,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    cursor: disabled ? 'not-allowed' : 'pointer',
    textDecoration: 'none',
    lineHeight: 'var(--leading-tight)',
    borderWidth: 1,
    borderStyle: 'solid',
    borderRadius: 0,
    whiteSpace: 'nowrap',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--weight-medium)',
    fontSize: 'var(--text-small)',
    padding: variant === 'ghost' ? 'var(--space-2) var(--space-1)' : 'var(--btn-pad-y) var(--btn-pad-x)',
    opacity: disabled ? 0.45 : 1,
    ...v,
    ...state,
    ...style,
  };
  const Tag = href ? 'a' : 'button';
  return (
    <Tag href={href} disabled={!href ? disabled : undefined} style={css}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => { setHover(false); setDown(false); }}
      onMouseDown={() => setDown(true)} onMouseUp={() => setDown(false)} {...rest}>
      {children}
    </Tag>
  );
}
