import React from 'react';

/** The system's only elevation device: a 1px rule. `ink` closes a section. */
export function Hairline({ tone = 'divider', style }) {
  const map = { divider: 'var(--divider)', ink: 'var(--text)', row: 'var(--neutral-200)' };
  return <hr style={{ height: 1, border: 0, margin: 'var(--space-4) 0', background: map[tone] || map.divider, opacity: tone === 'ink' ? 0.85 : 1, ...style }} />;
}
