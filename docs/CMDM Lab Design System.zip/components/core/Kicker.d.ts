/** Mono uppercase micro-label — the only place type below 12px is allowed. */
export interface KickerProps {
  /** sm = 9.5px, md = 11px. Ignored when `cjk` is set. */
  size?: 'sm' | 'md';
  tone?: 'accent' | 'neutral' | 'faint';
  /** CJK mode: sans instead of mono, 12px, 0.08em tracking, no uppercasing. */
  cjk?: boolean;
  as?: keyof JSX.IntrinsicElements;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Kicker(props: KickerProps): JSX.Element;
