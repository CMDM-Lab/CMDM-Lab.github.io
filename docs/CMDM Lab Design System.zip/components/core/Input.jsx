import React from 'react';

/** Zero-radius text input. Hover darkens the border; focus turns it accent. */
export function Input({ as = 'input', label, hint, style, ...rest }) {
  const Tag = as;
  const [hover, setHover] = React.useState(false);
  const [focus, setFocus] = React.useState(false);
  const field = (
    <Tag
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
      style={{
        font: 'inherit',
        width: '100%',
        borderRadius: 0,
        minHeight: as === 'textarea' ? 90 : 36,
        resize: as === 'textarea' ? 'vertical' : undefined,
        borderWidth: 1,
        borderStyle: 'solid',
        borderColor: focus ? 'var(--accent-600)' : hover ? 'color-mix(in srgb, var(--text) 45%, transparent)' : 'var(--divider)',
        background: 'var(--white)',
        padding: as === 'textarea' ? 'var(--space-2)' : '0 var(--space-2)',
        fontSize: 'var(--font-size-body)',
        caretColor: 'var(--accent-600)',
        color: 'var(--text)',
        ...style,
      }} {...rest} />
  );
  if (!label && !hint) return field;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
      {label ? <label style={{ fontSize: 'var(--text-small)', color: 'var(--neutral-700)' }}>{label}</label> : null}
      {field}
      {hint ? <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-kicker)', color: 'var(--neutral-600)' }}>{hint}</span> : null}
    </div>
  );
}
