import React from 'react';

/** Page container: centred, max 960px, space-6/space-8 padding. */
export function PageShell({ width = 'default', children, style, ...rest }) {
  return (
    <div style={{
      margin: '0 auto',
      width: '100%',
      maxWidth: width === 'wide' ? 'var(--page-max-wide)' : 'var(--page-max)',
      padding: 'var(--page-pad-y) var(--page-pad-x)',
      ...style,
    }} {...rest}>{children}</div>
  );
}

/** Prose column. Latin justifies at 64ch; CJK sets ragged-right at 38em / 1.8. */
export function Prose({ justify = true, size = 'body', cjk = false, children, style }) {
  const doJustify = justify && !cjk;
  return (
    <div style={{
      maxWidth: cjk ? 'var(--measure-prose-cjk)' : 'var(--measure-prose)',
      fontSize: cjk ? 'var(--text-lede)' : size === 'lede' ? 'var(--text-lede)' : 'var(--font-size-body-lg)',
      lineHeight: cjk ? 'var(--leading-body-cjk)' : 'var(--leading-body)',
      textAlign: doJustify ? 'justify' : 'left',
      hyphens: doJustify ? 'auto' : undefined,
      color: 'var(--text-secondary)',
      display: 'flex',
      flexDirection: 'column',
      gap: cjk ? 'var(--space-4)' : 'var(--space-3)',
      ...style,
    }}>{children}</div>
  );
}
