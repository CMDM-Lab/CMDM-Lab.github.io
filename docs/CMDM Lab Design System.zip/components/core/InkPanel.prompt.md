The loudest element available: a 2px ink frame on white. **At most one per page.**

```jsx
<InkPanel kicker="Now recruiting">
  <p>We are looking for graduate students with a background in…</p>
</InkPanel>
```

Use it for the single thing a visitor must not miss. If a page has two of these, it has none.