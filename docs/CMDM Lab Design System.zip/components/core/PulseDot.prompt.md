The only animation in the system — a 1.4s opacity/scale pulse marking live state.

```jsx
<PulseDot label="Pipeline running" />
<PulseDot tone="brand" size={9} />
```

Nothing else moves: no slide-ins, no card lifts, no shadow transitions.