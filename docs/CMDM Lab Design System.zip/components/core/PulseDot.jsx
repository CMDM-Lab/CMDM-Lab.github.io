import React from 'react';

/** The one piece of motion in the system: a pulsing status dot. */
export function PulseDot({ label, size = 7, tone = 'accent', style }) {
  const color = tone === 'brand' ? 'var(--brand-500)' : 'var(--accent-600)';
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 'var(--space-2)', ...style }}>
      <span style={{ width: size, height: size, borderRadius: 'var(--radius-circle)', background: color, animation: 'ds-pulse 1.4s ease-in-out infinite', flex: 'none' }} />
      {label ? <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-kicker-sm)', letterSpacing: 'var(--tracking-kicker)', textTransform: 'uppercase', color: 'var(--neutral-600)' }}>{label}</span> : null}
    </span>
  );
}
