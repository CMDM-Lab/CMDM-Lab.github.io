# Handoff: CMDM Lab site — "Clinical Instrument" design system

## Overview

A complete design system and a five-screen bilingual (English / 繁體中文) recreation of the website for the **Computational Molecular Design & Metabolomics Laboratory (CMDM Lab)**, Prof. Yufeng Jane Tseng's group in NTU CSIE.

The visual language is called **Clinical Instrument**: near-white page, hard 1px hairlines, zero border-radius, zero shadows, one signal colour. It should read like a research instrument or a journal page. It is adopted from the lab's MetaboMAIA frontend so the lab's web properties share one language.

Two things to implement:

1. **The token + component layer** — 18 components over ~109 CSS custom properties.
2. **The lab site** — five screens (Overview, Research, Tools, People, Publications), fully bilingual with a live locale toggle.

## About the design files

Everything in this bundle is a **design reference written in HTML/JSX** — prototypes that show intended look and behaviour. **Do not ship them as production code.** The `.jsx` files use browser-Babel, `window.*` globals for cross-file sharing, and inline style objects, none of which belong in a real app.
Your task is to **recreate these designs in the target codebase's own environment** using its established patterns. If there is no codebase yet, the natural target — and the one the source system already uses — is **Next.js (App Router) + React + Tailwind CSS v4**, because the governing design document was written against exactly that stack (see "Recommended implementation" below).

The `.d.ts` files are the real API contract for each component; the `.prompt.md` files explain when and how to use each one. Read `readme.md` first — it is the full design guide.

## Fidelity

**High-fidelity.** Every colour, size, weight, tracking value, spacing step and border width in this bundle is final and intentional. Reproduce them exactly. In particular:

- Spacing values are **1.15×-scaled and non-round on purpose** — `4.6px`, `9.2px`, `13.8px`, `18.4px`, `27.6px`, `36.8px`. Do **not** snap them to a 4/8px grid.
- Type sizes include `9.5px`, `12.5px`, `13.5px`. Do **not** round them.
- `border-radius` is `0` everywhere except true circles. This is not an oversight.
- There are **no shadows**. Layering is done with 1px rules.

---

## Recommended implementation

The source system is Tailwind v4, CSS-first, **no `tailwind.config`** — the entire token layer is one `globals.css`. If you use Tailwind, follow that shape:

```css
@import "tailwindcss";

:root { color-scheme: light; /* …all tokens… */ }

@theme inline {
  --color-bg: var(--bg);
  --color-accent-600: var(--accent-600);
  /* …turns each token into a utility: bg-bg, text-accent-600, border-divider… */
  --font-sans: var(--font-plex-sans), var(--font-noto-tc), sans-serif;
  --font-mono: var(--font-plex-mono), var(--font-noto-tc), monospace;
}

@layer base { /* element defaults */ }
@layer components { /* .btn, .input, .table, .tag, .hr */ }
```

**Structural rule, learned the hard way:** apart from `:root` and `@theme`, **every rule must live inside an `@layer`.** CSS cascade layers make any unlayered declaration beat every layered one regardless of specificity. An unlayered `a { color }` once overrode `.btn-primary`, making a CTA's text the same colour as its own fill and rendering it invisible.

### Enforce the rules with tests

The source project guards these with two ratchet tests that scan all `.ts`/`.tsx`/`.css` source text. Port them:

| Forbidden | Why |
| --- | --- |
| `dark:` variants | No dark mode — a design decision, not a gap |
| `prefers-color-scheme: dark` | Same rule, CSS side |
| `rounded-*` (except `rounded-full`) | All radii are 0; circles only where a circle is real |
| `shadow-*` (except `shadow-none`) | Elevation is a 1px line |
| Framework default palettes (`slate-`, `blue-`, `red-`, `amber-`, `emerald-`…) | Colour comes only from the three ramps |
| Bare hex in component files | Colour comes only from tokens (the global stylesheet is the one exception) |
| Any rule outside `@layer` in the global stylesheet | See the cascade-layer note above |

Use an **allowlist that can only shrink**: a second test should fail when a file has been fixed but is still listed, so the list cannot quietly grow.

Four more rules exist only in prose in the source project and had already drifted there. Make them testable this time:

1. The accent whitelist (six permitted uses, below).
2. Body copy never below 12px (kickers excepted).
3. Spacing only from `--space-*`.
4. Focus ring always `2px`.

---

## Design tokens

### Colour — semantic core

| Token | Hex | Use |
| --- | --- | --- |
| `--bg` | `#f7f7f5` | Page background |
| `--surface` | `#eeeeec` | Secondary button fill, embedded panels |
| `--text` | `#16181a` | Body ink, hard rules |
| `--accent` | `#8c1d2f` | The single signal colour |
| `--divider` | `#d8dad6` | Hairlines, input borders |
| `--white` | `#ffffff` | Plates, primary button text |

### Accent ramp (dark red)

`100 #f6e8ea` · `200 #eccfd3` · `300 #dba7ae` · `400 #c47c86` · `500 #a8404f` · `600 #8c1d2f` · `700 #7a1926` · `800 #5e1420` · `900 #3f0d16`

**Whitelist — `#8c1d2f` may appear ONLY as:** primary button fill · active nav item · live pulse dot · positive-value emphasis · the numbers inside kickers and indices · must-fix tags.

**Never a large fill or background wash.** The only tinted surface in the entire system is a notice banner at `--accent-100 #f6e8ea`. Every other surface is `--bg`, `--surface`, `#fff`, or `--neutral-100`.

### Neutral ramp (warm grey)

`100 #f2f2f0` · `200 #e6e7e4` · `300 #d8dad6` · `400 #b9bdb8` · `500 #8b9199` · `600 #6b7280` · `700 #3f4a56` · `800 #2a3038` · `900 #16181a`

### Brand ramp — `#B4D6E0`

`100 #f1f8fa` · `200 #ddedf2` · `300 #B4D6E0` · `400 #8ab9c8` · `500 #5e94a6` · `600 #3d6f80` · `700 #2b5361` · `800 #1e3d47`

This is the **one colour retained from the lab's previous identity**, sampled from the flask in the logo mark. It is deliberately narrow: allowed for the logo lockup itself, data-visualisation series fills, figure/spectrum plates, and `brand`-tone tags (instrument and assay classifications, e.g. `ADMET`, `LC-MS`). It is **not** a button fill, not body text, not a page background — at this lightness a large fill only mutes the page.

### Semantic aliases

```
--surface-page    → var(--bg)
--surface-panel   → var(--surface)
--surface-plate   → var(--white)
--surface-notice  → var(--accent-100)     /* the only tinted surface */

--text-body       → var(--text)           /* NOTE: a colour, not a size */
--text-secondary  → color-mix(in srgb, var(--text) 78%, transparent)
--text-meta       → color-mix(in srgb, var(--text) 54%, transparent)
--text-faint      → color-mix(in srgb, var(--text) 50%, transparent)
--text-idle       → color-mix(in srgb, var(--text) 35%, transparent)
--text-link       → var(--accent-600)
--text-link-hover → var(--accent-800)

--rule-hairline   → var(--divider)
--rule-ink        → var(--text)
--rule-row        → var(--neutral-200)
--focus-ring      → var(--accent-600)
```

Opacity is mixed inline with `color-mix` rather than tokenised per step. The four steps in use are 78 / 54 / 50 / 35%.

> **Naming trap:** `--text-body` is a **colour**. Font sizes are `--font-size-body` (13px) and `--font-size-body-lg` (13.5px). Keep these apart — an earlier revision of this system declared `--text-body` twice with two meanings and the colour alias silently resolved to `13px`, an invalid colour, so the declaration was dropped.

### Typography

| Role | Font | Spec |
| --- | --- | --- |
| Headings / UI | IBM Plex Sans | 500 (600 for small labels), `letter-spacing: -0.02em` |
| Body | IBM Plex Sans | 13px / 1.55 |
| CJK | Noto Sans TC | 400 / 500 |
| Figures, kickers, identifiers, filenames, durations | IBM Plex Mono | 400 / 500 + `font-variant-numeric: tabular-nums` |

Family strings: `'IBM Plex Sans','Noto Sans TC',sans-serif` and `'IBM Plex Mono','Noto Sans TC',monospace`.

Scale tokens:

```
--text-h1-hero   clamp(30px,3.4vw,40px)
--text-h1        30px      --text-h2       24px      --text-h2-hero  28px
--text-h3        19px      --text-h4       16px
--text-lede      14px      --font-size-body-lg  13.5px
--font-size-body 13px      --text-table    12.5px    --text-small    12px
--text-kicker    11px      --text-kicker-sm 9.5px    --text-kicker-cjk 12px

--weight-regular 400   --weight-medium 500   --weight-semibold 600
--leading-body 1.55    --leading-tight 1.2   --leading-body-cjk 1.8
--tracking-heading -0.02em   --tracking-kicker 0.14em
--tracking-kicker-wide 0.2em --tracking-kicker-cjk 0.08em
--tracking-table-head 0.12em
--measure-prose 64ch         --measure-prose-cjk 38em
```

**Body copy never goes below 12px.** The single exception is a kicker at 9.5–11px, and only because it is uppercase monospace.

Long Latin prose: `text-align: justify` + `hyphens: auto` + `max-width: 64ch`. **Exception:** never justify technical prose in narrow columns — it pulls tokens like `|log₂FC| > 1` apart.

### Spacing — 1.15× density, six steps

```
--space-1 4.6px   --space-2 9.2px   --space-3 13.8px
--space-4 18.4px  --space-6 27.6px  --space-8 36.8px
--column-gap 36.8px   --btn-pad-y 9.2px   --btn-pad-x 16.56px   /* space-3 × 1.2 */
```

`--space-5` and `--space-7` **do not exist**, deliberately. Never write a bare pixel value for spacing.

### Radius, borders, elevation, focus

```
--radius-sm/md/lg      0        /* all of them */
--radius-circle        50%      /* score dots, pulse dot only */

--border-hairline  1px solid var(--divider)      /* #d8dad6 — separates peers */
--border-ink       1px solid var(--text)         /* #16181a — nav underline, section closer, table head */
--border-row       1px solid var(--neutral-200)  /* #e6e7e4 — table rows */
--border-plate     2px solid var(--text)         /* the one ink-framed block per page */

--shadow-none      none        /* there is no elevation in this system */

--focus-outline    2px solid var(--accent-600)
--focus-offset     2px
```

Focus is **always** `outline: 2px solid #8c1d2f; outline-offset: 2px`. Never the browser default; never `outline: none` without a `:focus-visible` replacement.

### Layout

```
--page-max        960px       --page-max-wide   1180px
--page-pad-x      27.6px      --page-pad-y      36.8px
--grid-min-ledger 260px       --grid-min-wide   380px
--nav-pad-y       13.8px      --nav-pad-x       27.6px      --nav-blur 6px
--target-desktop  1440px      --target-tablet   1024px      --target-mobile 390px
--bp-mobile       768px       --tap-min         44px        --drawer-row-h  52px
--drawer-index-w  26px
```

**Almost no media queries.** The source project has zero `@media` in its global stylesheet and one breakpoint prefix in all of `src/`. Reflow through two mechanisms instead:

```jsx
// 1. auto-fit grid — column count follows container width
className="grid grid-cols-[repeat(auto-fit,minmax(260px,1fr))]"

// 2. flex-wrap with a flex-basis floor
style={{ flex: '1 1 380px', minWidth: 'min(100%, 380px)' }}
```

Target widths: desktop 1440, tablet 1024 / 768, mobile 390.

**The single media query.** Mobile is the one exception to the no-media-query rule, and it is expressed as a *token override*, not as component branches:

```css
@media (max-width:767px){
  :root{
    --page-pad-x:var(--space-4);   /* 18.4px */
    --page-pad-y:var(--space-6);   /* 27.6px */
    --nav-pad-x:var(--space-4);
    --nav-pad-y:var(--space-3);
    --column-gap:var(--space-4);
    --grid-min-ledger:100%;
    --grid-min-wide:100%;
  }
}
```

Because every auto-fit grid reads `--grid-min-*`, and every container reads `--page-pad-*`, the whole site collapses to one column with no component change. Port this block verbatim; do not scatter `sm:` prefixes through components to reproduce it.

### Motion

Two things move, and nothing else:

1. Hover / active **colour** changes on buttons, links and table rows.
2. The live pulse dot:

```css
@keyframes ds-pulse {
  0%, 100% { opacity: .25; transform: scale(.8); }
  50%      { opacity: 1;   transform: scale(1.25); }
}
/* 1.4s ease-in-out infinite */
```

No slide-ins, no card lifts, no shadow transitions, no page transitions. The sticky nav's `backdrop-filter: blur(6px)` is the only blur.

---

## Components

19 exports across three groups. Each has a `.d.ts` (the props contract — treat it as the spec) and a `.prompt.md` (when and how to use it).

### `components/core/`

| Component | Spec |
| --- | --- |
| **Button** | `variant: primary \| secondary \| ghost`. Zero radius, 1px border (width+style always set so variants only change colour), `font-size 12px`, `weight 500`, `line-height 1.2`, padding `9.2px 16.56px` (ghost: `9.2px 4.6px`), `gap 6px`, `white-space: nowrap`, `svg { display: block }`. Disabled `opacity .45`. **primary:** bg `#8c1d2f` / text `#fff`; hover `#7a1926`; active `#5e1420`. **secondary:** bg `#eeeeec`, border `#d8dad6`; hover `color-mix(in srgb, var(--text) 7%, transparent)`; active 14%. **ghost:** transparent, no border, text `--accent-600`; hover accent at 10%; active 18%. `block` → full width + `margin-top: 9.2px`. Renders `<a>` when `href` is given, styled identically. |
| **Input** | `as: input \| textarea \| select`. `font: inherit`, `width: 100%`, radius 0, `min-height 36px` (textarea 90px, `resize: vertical`), border `1px solid #d8dad6`, bg `#fff`, padding `0 9.2px`, `font-size 13px` (**never larger than its own label**), `caret-color: var(--accent-600)`. Hover border → `color-mix(in srgb, var(--text) 45%, transparent)`; focus border → `--accent-600`. Optional `label` (12px, `--neutral-700`) and `hint` (mono 11px, `--neutral-600`) in a `flex column` with `gap 9.2px`. |
| **Tag** | Square, mono, `font-size 9.5px`, `letter-spacing .1em`, uppercase, padding `2px 6px`, radius 0. `tone: accent` (bg `--accent-100`, text `--accent-800`) · `neutral` (bg `#e6e7e4`, text `#3f4a56`) · `outline` (transparent, 1px `--accent-600` border, accent text) · `brand` (bg `--brand-200`, text `--brand-800`). |
| **Kicker** | Mono uppercase micro-label. `size: sm` 9.5px / `md` 11px, `letter-spacing .14em`, weight 500. `tone: accent` (`--accent-700`) · `neutral` (`--neutral-600`) · `faint` (`--text-faint`). **`cjk`** → sans, 12px, `.08em`, `text-transform: none`. |
| **Hairline** | `<hr>`, `height 1px`, `border: 0`, `margin: 18.4px 0`. `tone: divider` `#d8dad6` · `ink` `#16181a` at `opacity .85` · `row` `#e6e7e4`. **The system's only elevation device.** |
| **InkPanel** | `border: 2px solid #16181a`, bg `#fff`, `padding: 27.6px`. Optional `kicker` (md, accent) on the first line with `margin-bottom: 13.8px`. **Maximum one per page** — if a page has two, it has none. |
| **PageShell** | `margin: 0 auto`, `width: 100%`, `max-width: 960px` (`width="wide"` → 1180px), `padding: 36.8px 27.6px`. |
| **Prose** | Flex column, `gap 13.8px`. Latin: `max-width 64ch`, 13.5px (or 14px `size="lede"`), `line-height 1.55`, justified + hyphenated. **`cjk`** → `max-width 38em`, 14px, `line-height 1.8`, `text-align: left` (never justified), `gap 18.4px`. Colour `--text-secondary`. |
| **PulseDot** | Inline flex, `gap 9.2px`. Dot `7px` square (prop `size`), `border-radius 50%`, bg `--accent-600` (`tone="brand"` → `--brand-500`), `animation: ds-pulse 1.4s ease-in-out infinite`. Optional mono 9.5px uppercase `.14em` `--neutral-600` label. |

### `components/navigation/`

| Component | Spec |
| --- | --- |
| **SiteNav** | `position: sticky; top: 0; z-index: 10`, bg `color-mix(in srgb, var(--bg) 92%, transparent)`, `backdrop-filter: blur(6px)`, `border-bottom: 1px solid #16181a`, padding `13.8px 27.6px`, flex with `gap 27.6px`. Left: optional 30px-tall logo + two-line brand block — line 1 `20px/500`, `letter-spacing -0.02em`, `line-height 1.1`; line 2 mono 9.5px uppercase `.18em` `--neutral-600`, `margin-top 2px`. Right (`margin-left: auto`, `gap 18.4px`): links at 13.5px, `--text-secondary`, `padding-bottom 2px`, `border-bottom: 1px solid transparent` → `--accent-600` on hover; active link is `--accent-600` and sets `aria-current="page"`. `right` slot for the locale toggle / status dot. **`cjk`** → tagline becomes sans 12px `.08em`, no uppercasing. |
| **Masthead** | `kicker` (md, accent) → `Hairline tone="ink"` with `margin: 9.2px 0 18.4px` → `<h1>` (`--text-h1`, or `--text-h1-hero` with `hero`) `line-height 1.1` → `subtitle` mono 11px uppercase `.14em` `--neutral-600`, `margin-top 9.2px` → `lede` `margin-top 18.4px`, `max-width 64ch`, 14px, justified + hyphenated, `--text-secondary`. **`cjk`** → title `line-height 1.3`, subtitle sans 12px `.08em` no uppercasing, lede `max-width 38em` / `line-height 1.8` / left-aligned. |
| **Footer** | `border-top: 1px solid #16181a`, padding `27.6px 27.6px`. `label` kicker (sm, neutral — default `"Colophon"`, **always localise**), then `lines` in a flex column `gap 4.6px`, each mono 12px `--text-meta` with `tabular-nums`. Optional `note` in sans 12px `--text-faint`, `margin-top 13.8px`. **`cjk`** forwards to the label. |

### `components/content/`

| Component | Spec |
| --- | --- |
| **Ledger** | **The replacement for cards.** `display: grid`, `grid-template-columns: repeat(auto-fit, minmax(260px, 1fr))` (prop `min`, commonly `380px` for wide items), `border-top: 1px solid #d8dad6`. No fill, ever. |
| **LedgerItem** | `border-bottom: 1px solid #d8dad6`, padding `18.4px 27.6px 18.4px 0`, flex column `gap 9.2px`. Order: mono accent `index` → `<h4>` 16px `line-height 1.3` → optional hairline-bordered image → body 13.5px `--text-secondary` → `tags` row (`gap 4.6px`, wrapping) → mono 11px `--text-meta` `meta` line with `tabular-nums` → link at 12px accent, `margin-top: auto`, `padding-top 9.2px`, **always ending in ` →`**. **`cjk`** → title `line-height 1.5`, body 14px / 1.8, never justified. |
| **DataTable** | `width: 100%`, `border-collapse: collapse`, `font-size 14px`, `tabular-nums`. `<th>`: mono 9.5px, `letter-spacing .12em`, uppercase, weight 500, padding `9.2px`, `border-bottom: 1px solid #16181a` (ink rule = section boundary). `<td>`: 12.5px, padding `9.2px`, `border-bottom: 1px solid #e6e7e4`, `vertical-align: top`, `--text-secondary`. Row hover → bg `--neutral-100`. That is the entire interaction. |
| **ColophonTable** | Label/value spec table. `<th>` fixed `width: 34%`, `vertical-align: top`, mono 9.5px uppercase `.12em`, `--neutral-600`. `<td>` 12.5px `--text-secondary`. Both padded `9.2px` with `border-bottom: 1px solid #e6e7e4`. Whole table `tabular-nums`. |
| **ArticleFlow** | `columns: 2` (prop), `column-gap: 36.8px`, `column-rule: 1px solid #d8dad6`, 14px / 1.55, justified + hyphenated. Reads more like a journal than side-by-side flex columns. Keep it for Latin prose — long Chinese paragraphs belong in a single `Prose` column. |

### Deliberately NOT built — do not add them

The source handoff listed two components that were never implemented, and adding them would produce empty shells:

- **`.seg`** — an A/B layout switcher that stayed a prototype.
- **`.card`** — superseded entirely by hairlines and `Ledger`.

---

## Screens

All five live in `ui_kits/lab_site/`. Every screen is wrapped in `PageShell width="wide"` (1180px) and opens with a `Masthead`.

### 1. Overview (`OverviewScreen.jsx`)

**Purpose:** the landing page — who the lab is, what it works on, and how to join.

**Layout, top to bottom:**
1. `Masthead hero` — kicker `NTU CSIE · Est. 2006`, title, PI + department subtitle, justified lede.
2. `Hairline` (`margin-top: 36.8px`) → `Kicker md` "Two research pillars" → `Ledger` with two `LedgerItem`s (indices `I`, `II`), each with a meta line and a `Research →` link.
3. `Hairline` → `Kicker md` "Lab record" → flex row `gap 36.8px`, wrapping: left `flex: 1 1 380px` a `Prose size="lede"` of two paragraphs; right `flex: 1 1 320px` a `ColophonTable` of five facts (Director, Affiliation, Platforms, Public tools, Alumni).
4. `margin-top: 36.8px` → the page's single `InkPanel`, kicker "Now recruiting", body 14px with a `mailto:` link.

### 2. Research (`ResearchScreen.jsx`)

**Purpose:** representative publications.

`Masthead` → `Hairline` → `Kicker md` "Papers" → `Ledger min="var(--grid-min-wide)"` (380px floor, so two wide columns at desktop) of five `LedgerItem`s. Each: roman-numeral index, full paper title, one-paragraph summary, a `Tag tone="brand"` topic, a mono meta line (`journal · year · doi`), and a `Publisher →` link. Two entries carry hairline-framed figures (`research.png`, `research_2.png`).

### 3. Tools (`ToolsScreen.jsx`)

**Purpose:** catalogue of the lab's eight public services.

`Masthead` → `Hairline` → `Kicker md` "Catalogue" → `Ledger` (260px floor) of eight `LedgerItem`s: tool name as title, one-sentence description, screenshot, mono meta line `host · kind`, a `Tag tone="brand"`, and an `Open →` link to the live service. Then `Hairline tone="ink"` → `Kicker md` "Access" → a `ColophonTable` (max-width 640px) of four rows.

Tools, with live URLs: Virtual Rat `virtualrat.cmdm.tw` · CypRules `cyprules.cmdm.tw` · Lipidpedia `lipidpedia.cmdm.tw` · 3Omics `3omics.cmdm.tw` · GC2MS `gc2ms.cmdm.tw` · PITracer `pitracer.cmdm.tw` · Chromaligner `chromaligner.cmdm.tw` · MetaCore `web.cmdm.tw/metacore_portal/`.

### 4. People (`PeopleScreen.jsx`)

**Purpose:** the roster.

`Masthead` → `Hairline tone="ink"` → `Kicker md` "Principal investigator" → flex row: a `flex: 0 0 200px` white plate with a 1px hairline and `9.2px` padding holding the PI photo, then `flex: 1 1 380px` with `<h3>` name, bio paragraph, and a three-row `ColophonTable` (Email, Telephone, Office). Then `Hairline` + `Kicker md` + `Ledger` for **Postdoctoral researchers** (2) and **Doctoral students** (4) — title = name, body = research interests, meta = email. Then **Master's students** as a two-column `DataTable` (10 rows). Then `Hairline tone="ink"` + **Alumni** as a four-column `DataTable` (Year 10% / Name 20% / Degree 16% / Thesis).

Emails render with `[at]` in place of `@` — the lab's own scraping convention. Keep it.

### 5. Publications (`PublicationsScreen.jsx`)

**Purpose:** filterable publication record.

`Masthead` → `Hairline` → a filter row (`flex`, `gap 9.2px`, `align-items: flex-end`, wrapping): `Input label="Filter"` at `flex: 1 1 320px`, a secondary "Clear" button, a primary "Export BibTeX" button. Then `margin-top: 27.6px` → `Kicker md` showing `"{n} of {total} entries"` → a five-column `DataTable` (Year 8% / Title / Venue 22% / Authors 16% / Topic 14%). Year, Venue and Authors cells are mono; Topic is a `Tag tone="brand"`.

**Filter behaviour:** case-insensitive substring match across `title + venue + authors + year + localised topic`. Empty result shows `"No entry matches that filter."` in 12px `--text-faint`. "Export BibTeX" is not wired up in the prototype — implement or remove it.

---

## Mobile (< 768px)

One breakpoint. There is no tablet tier — the 960px column already fits 1024px with its own padding.

**Layout.** Token override above; nothing else changes. Type ramp is **not** scaled per breakpoint — 13.5px body holds on a phone, and shrinking it breaks the tabular alignment the tables depend on. CJK prose keeps 14px / 1.8 / ragged-right; its 38em measure is already wider than any phone.

**Nav.** `SiteNav` detects the breakpoint (`useNarrow()`, `matchMedia`) and renders `MobileNav` itself — consumers pass one extra prop, `menuLabel`, so the hamburger is localised ("Menu" / "選單"). `collapse={false}` opts out.

`MobileNav` spec:

| Part | Spec |
| --- | --- |
| Bar | Sticky, `z-index 20`, `color-mix(in srgb, var(--bg) 92%, transparent)` + `blur(6px)`, `border-bottom: 1px solid #16181a`, padding `13.8px 18.4px`. Logo 26px, brand **17px/500**, mono tagline at `--text-kicker-sm` / 0.14em, `text-overflow: ellipsis` — the tagline truncates, never wraps. |
| Hamburger | `44 × 44`, 1px hairline border, radius 0, three 18×1px ink bars at 5px gaps. Open state: bars 1/3 rotate ±45° and translate 6px, bar 2 fades — 120ms linear, the only transition in the component. Background `--neutral-100` while open. `aria-expanded`, `aria-label={menuLabel}`. |
| Drawer | `position: absolute; top: 100%`, `height: calc(100dvh - 100%)`, **solid `--bg`** — no scrim, no sheet, no radius, no shadow. `border-bottom: 1px solid #16181a`. `role="dialog"`. |
| Rows | `min-height: 52px` (above the 44px floor), padding `0 var(--page-pad-x)`, `border-bottom: 1px solid --rule-row`. Two-digit mono ordinal (`01`…) in a 26px gutter at `--text-kicker-sm` / 0.14em, then the label at `--text-lede`. Active row: label **and** ordinal in `--accent-600`. Pressed: `--neutral-100`. No left accent bar, no fill, no chevron. |
| `right` slot | Pinned to the drawer's bottom (`margin-top: auto`) above a `1px solid #16181a` rule, padding `18.4px var(--page-pad-x)` — status dot and language toggle live there. |
| Behaviour | Selecting a row closes the drawer, then fires `onSelect`. Body scroll locks while open. Escape closes. One level only — no nested menus, no search field. |

**Tables.** `DataTable` stops being a table below 768px: each row becomes a stacked record — mono uppercase column label in a `minmax(88px,32%)` column, value beside it, `4.6px` gap between fields, row hairline between records, `13.8px` vertical padding. **Never horizontally scroll a five-column table on a phone.** `stackOnMobile={false}` only for a genuinely narrow numeric table.

**Targets.** `--tap-min: 44px` is a floor, not a target. Ghost buttons (which are visually padding-light) need a 44px hit box on touch; give them `min-height: var(--tap-min)` in the real implementation.

**Off-limits on mobile:** bottom tab bar, scrim/overlay dimming, bottom sheets, sheet corner radius, elevation, icon-only navigation, hiding the tagline entirely, a hamburger without a visible border.

Reference cards: `guidelines/mobile.html` (specs + both nav states) and `ui_kits/lab_site/mobile.html` (all five screens live at 390px).

## Bilingual behaviour

The lab is bilingual, so **Chinese is a first-class case, not a fallback.**

**Mechanism in the prototype:** `ui_kits/lab_site/messages.js` holds UI strings per locale (flat keys, symmetrical key sets — add a test that fails on asymmetry). `ui_kits/lab_site/data.js` holds content, with only translatable fields split into `{en, zh}`; a helper `window.L(value, locale)` picks the right one and passes plain strings through. Locale lives in React state, persists to `localStorage` under `cmdm-kit-locale`, and syncs `document.documentElement.lang` to `en` / `zh-Hant`.

**In production**, replace this with the codebase's real i18n. The source project used a lightweight `LocaleContext` + `useT()` with `{name}` interpolation and flat `messages/{zh,en}.ts` dictionaries. If the site needs SEO-friendly localised routes, use `next-intl` or an App Router `[locale]` segment instead. Either way the token layer is unaffected.

### CJK typography rules

| | Latin | 中文 |
| --- | --- | --- |
| Body size / leading | 13.5px / 1.55 | **14px / 1.8** |
| Measure | 64ch | **38em** (~38 characters) |
| Alignment | justified + hyphenated | **ragged right, never justified** |
| Kicker | 9.5–11px mono, UPPERCASE, `.14em` | **12px sans, no case change, `.08em`** |
| Heading leading | 1.1–1.3 | **1.3–1.5** |

Why: Chinese has no case, so `text-transform: uppercase` does nothing while `.14em` tracking pulls glyphs apart; justification stretches inter-character spacing and breaks technical tokens; dense Hanzi needs more leading than 1.55. **Numbers, identifiers and filenames stay in IBM Plex Mono in both locales.**

`Masthead`, `Prose`, `LedgerItem`, `Kicker`, `SiteNav` and `Footer` each take a `cjk` boolean that applies these. In a real implementation, derive it from the active locale rather than threading a prop — a `useIsCJK()` hook or a `lang`-scoped CSS block is cleaner.

**Keep in the original language on the Chinese page:** paper titles, journal names, tool names, degree codes (`PhD, BEBI`), and thesis titles. That is correct academic practice, not an omission.

---

## Content & copy rules

The lab's voice, to follow when writing any new copy:

- **Institutional academic, first-person plural.** "We develop algorithms and tools to…" — the lab is "we"/"our" and never addresses the reader as "you". No marketing register, no imperative CTAs.
- **Third person for people, always with title.** "Professor Y. Jane Tseng was invited to…" — never a first name, never a bare pronoun as sentence subject.
- **News is dated then declarative:** `2018, ` + one full sentence + bracketed sources: `[TechNews]`, `[NTU Spotlight]`, `[CNN health news]`. Square brackets, title-cased outlet, at the end of the sentence.
- **Links end in `→`**, never a verb phrase. `Publisher →`, `Open →`, `Research →`. Nothing says "Click here" or "Get started".
- **Casing:** sentence case for prose; Title Case for nav items and page titles; mono UPPERCASE for kickers, table heads and tags. Tool names keep their own capitalisation exactly: `Lipidpedia`, `3Omics`, `GC2MS`, `PITracer`, `CypRules`, `MetaCore`, `Virtual Rat`.
- **Vocabulary is technical and unabbreviated:** LC/QTOF-MS, GCxGC/TOF-MS, ADMET, QSAR, hERG, 1D ¹H-NMR, CYP2D6. Acronyms expand on first use.
- **Emails are obfuscated:** `yjtseng[at]csie.ntu.edu.tw`.
- **Chinese items keep 「corner brackets」** for talk titles even inside English sentences.
- **No emoji anywhere. No exclamation marks** in body copy (only inside quoted talk titles).
- **Blanks stay blank.** A member with no photo gets no placeholder; an alumnus with no thesis title gets an empty cell. Do not pad.

---

## State management

The prototype needs very little; a real implementation needs less.

| State | Owner | Notes |
| --- | --- | --- |
| `locale` | app root | `'en' \| 'zh'`; persisted; drives `<html lang>`. Replace with the framework's i18n. |
| `page` | app root | Prototype-only — becomes real routes (`/`, `/research`, `/tools`, `/people`, `/publications`, each locale-prefixed if you use localised routing). |
| `q` (publication filter) | Publications screen | Client-side substring filter. Consider a URL query param so filtered views are shareable. |
| hover / active / focus | each component | Local. In production prefer CSS `:hover` / `:active` / `:focus-visible` over React state — the prototype uses state only because it is inline-styled. |

No data fetching exists in the prototype; all content is static. If the lab wants publications and members editable without a deploy, those two are the natural candidates for a CMS or a checked-in data file.

---

## Assets

All in `assets/`, all imported from the lab's own repository (`CMDM-Lab/CMDM-Lab.github.io@master`) — none generated.

| Asset | Use |
| --- | --- |
| `logo.png` | Compact lockup — correct for the sticky nav (native 150×60, rendered at 30px tall) |
| `banner.png` | Full-width lockup — brand specimen, print, letterheads |
| `logo_big2.png`, `logo_original.svg`, `banner_v1–v4.svg` | Variants |
| `cmdm_illustration.png`, `molecule.png` | Lab illustration |
| `favicon.ico` | Favicon |
| `professor.png` | PI portrait |
| `research.png`, `research_2.png` | Paper figures |
| `virtual_rat.png`, `cyprules_1.png`, `cyprules_2.png`, `pitracer.png`, `GC2MSlogo.png`, `LipidPedia.png`, `3omics.png`, `3omics_logo.jpg`, `chromaligner.png`, `metacore.png`, `metacore1.png` | Tool screenshots |
| `IMG_0935.JPG`, `2017_future_tech.jpg` | Group and event photos |
| `font-awesome/` | **Legacy only.** The old site's icon font. Do not use in new work. |

**Logo rule:** the mark is black on transparent and only ever sits on white. **It does not read on the accent red** — never place it there.

**Figure rule:** scientific figures always sit on a **white plate inside a 1px hairline**, with a mono 11px caption. Nothing bleeds off the page; there is no hero imagery in this system.

### Fonts

IBM Plex Sans, IBM Plex Mono and Noto Sans TC. The prototype loads them from Google Fonts. In production use the framework's font pipeline (`next/font/google`, or self-hosted files if the lab needs intranet delivery) — but **keep the CSS variable names** `--font-plex-sans` / `--font-plex-mono` / `--font-noto-tc` so the `@theme` block needs no change.

### Icons — a flagged substitution

**No icon set came with either source.** **Lucide** is the substitution: 1.5px stroke, square caps, no fills, no rounded terminals — the only common family that matches this system's geometry. 16px inside buttons, 18px standalone, stroke `currentColor`.

**No emoji. No filled glyphs. No unicode dingbats.** The only glyph used iconographically is the literal `→` at the end of a link.

**Confirm this choice with the lab before building a large icon surface.** If they have a set, it replaces Lucide.

---

## Files in this bundle

The whole design-system project is the bundle — these are paths from its root.

```
HANDOFF.md                      This document
readme.md                       The full design guide — read this second
_ds_bundle.js                   Prebuilt browser bundle of all 19 components,
                                so every index.html below opens with no build step
styles.css                      Entry point; @imports every token file
tokens/
  fonts.css                     Font loading + family strings
  colors.css                    Semantic five, three ramps, aliases
  typography.css                Type scale, weights, tracking, measures
  spacing.css                   The six-step 1.15× scale
  borders.css                   Radii (all 0), the 1px rule set, focus ring
  layout.css                    Container widths, auto-fit floors, nav metrics
  base.css                      @layer ds-base reset + the ds-pulse keyframe
components/
  core/         Button · Input · Tag · Kicker · Hairline · InkPanel · PageShell · Prose · PulseDot
  navigation/   SiteNav · MobileNav · Masthead · Footer
  content/      Ledger · LedgerItem · DataTable · ColophonTable · ArticleFlow
                (each: .jsx implementation, .d.ts props contract, .prompt.md usage note,
                 plus one *.card.html showcase per directory)
ui_kits/lab_site/
  index.html                    Entry — open this to see the whole thing
  LabSite.jsx                   Shell: locale + page state, nav, footer
  OverviewScreen.jsx            Screens 1–5
  ResearchScreen.jsx
  ToolsScreen.jsx
  PeopleScreen.jsx
  PublicationsScreen.jsx
  messages.js                   UI strings, both locales
  data.js                       Content, translatable fields split per locale
  mobile.html                   All five screens at 390px, live
  README.md                     Kit-level notes and fidelity caveats
guidelines/                     17 foundation specimen cards (colours, type, spacing, brand,
                                CJK setting, mobile rules)
templates/lab-page/             A single-page starting template in this language
assets/                         Logos, figures, tool screenshots, legacy icon font
SKILL.md                        Agent Skills front-matter, if you use Claude Code skills
```

`index.html` files open directly in a browser — no build step, no server. They load `_ds_bundle.js`, which the design-system compiler generates from the `.jsx` sources; if you edit a component, that bundle is stale until it is regenerated, so treat the `.jsx` files as the truth.

`_ds_manifest.json` and `_adherence.oxlintrc.json` are also generated — the latter is a machine-readable list of every token and its kind, which may be useful if you port the adherence tests.

## Known gaps and caveats

1. **Icons are a substitution** (Lucide). Confirm with the lab.
2. **The accent `#8c1d2f` is inherited from MetaboMAIA**, not chosen for CMDM. If the lab wants a different signal colour it changes in one token and the whole system follows.
3. **`#B4D6E0` is deliberately narrow.** It could reasonably expand to the data-visualisation primary and chart-grid colour if the lab wants its identity more present. Ask before widening.
4. **Content is abridged.** Publications show 8 of roughly 200 entries; the member roster and alumni table are representative, not complete. The real lists live in the source repo (`contents/publication.html`, `contents/honor.html`, `contents/member.html`).
5. **"Export BibTeX" is not implemented.** Wire it up or drop the button.
6. **The Honor page from the original site is not rebuilt** — it is a flat 33 KB chronological list of ~200 items. Decide whether it becomes part of Publications or a separate view.
7. **No responsive work below 768px.** Target widths were 1440 / 1024 / 768. Mobile layouts are unspecified — the auto-fit grids degrade gracefully to one column, but the nav and the wide tables will need real design decisions.
8. **No dark mode, by design.** Do not add one.
9. **Mobile is nav + tables + token overrides.** The five screens were designed desktop-first and verified at 390px; if a future screen introduces a genuinely wide artefact (a spectrum viewer, a wide heatmap), it needs its own mobile treatment — the token override will not save it.

## Upstream

Content and assets: https://github.com/CMDM-Lab/CMDM-Lab.github.io (branch `master`). See `github.md` for the sync record and a screen→source map. Note that the **visual language does not come from that repo** — it is a deliberate replacement of the old Bootstrap 3 / crimson site. A future sync should pull content and assets only, never re-derive styling from `css/main.css`.
